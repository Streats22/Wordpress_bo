

DROP TABLE IF EXISTS `webtoffee_actionscheduler_actions` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scheduled_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_520_ci,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_attempt_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook` (`hook`),
  KEY `status` (`status`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id` (`claim_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_actionscheduler_actions VALUES
("8","action_scheduler/migration_hook","complete","2021-06-01 15:52:25","2021-06-01 15:52:25","[]","O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1622562745;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1622562745;}","1","1","2021-06-01 15:53:22","2021-06-01 15:53:22","0",""),
("9","action_scheduler/migration_hook","complete","2021-06-01 16:06:27","2021-06-01 16:06:27","[]","O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1622563587;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1622563587;}","1","1","2021-06-01 16:06:51","2021-06-01 16:06:51","0",""),
("10","action_scheduler/migration_hook","complete","2021-06-01 16:16:32","2021-06-01 16:16:32","[]","O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1622564192;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1622564192;}","1","1","2021-06-01 16:16:38","2021-06-01 16:16:38","0","");/*END*/




DROP TABLE IF EXISTS `webtoffee_actionscheduler_claims` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_actionscheduler_claims` (
  `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`claim_id`),
  KEY `date_created_gmt` (`date_created_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_actionscheduler_groups` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_actionscheduler_groups VALUES
("1","action-scheduler-migration");/*END*/




DROP TABLE IF EXISTS `webtoffee_actionscheduler_logs` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_actionscheduler_logs VALUES
("7","8","actie aangemaakt","2021-06-01 15:51:25","2021-06-01 15:51:25"),
("8","8","actie gestart via WP Cron","2021-06-01 15:53:22","2021-06-01 15:53:22"),
("9","8","actie voltooid via WP Cron","2021-06-01 15:53:22","2021-06-01 15:53:22"),
("10","9","actie aangemaakt","2021-06-01 16:05:27","2021-06-01 16:05:27"),
("11","9","actie gestart via Async Request","2021-06-01 16:06:51","2021-06-01 16:06:51"),
("12","9","actie voltooid via Async Request","2021-06-01 16:06:51","2021-06-01 16:06:51"),
("13","10","actie aangemaakt","2021-06-01 16:15:32","2021-06-01 16:15:32"),
("14","10","actie gestart via WP Cron","2021-06-01 16:16:38","2021-06-01 16:16:38"),
("15","10","actie voltooid via WP Cron","2021-06-01 16:16:38","2021-06-01 16:16:38");/*END*/




DROP TABLE IF EXISTS `webtoffee_commentmeta` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_comments` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_comments VALUES
("1","1","Een WordPress commentator","wapuu@wordpress.example","https://wordpress.org/","","2021-04-29 08:54:41","2021-04-29 08:54:41","Hoi, dit is een reactie.
Om te beginnen met beheren, bewerken en verwijderen van reacties, ga je naar het Reacties scherm op het dashboard.
Avatars van auteurs komen van <a href=\"https://gravatar.com\">Gravatar</a>.","0","1","","comment","0","0");/*END*/




DROP TABLE IF EXISTS `webtoffee_links` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_mollie_pending_payment` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_mollie_pending_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) NOT NULL,
  `expired_time` int(11) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/*END*/






DROP TABLE IF EXISTS `webtoffee_options` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=827 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_options VALUES
("1","siteurl","http://localhost:8888","yes"),
("2","home","http://localhost:8888","yes"),
("3","blogname","DISBRANDED CLOTHING","yes"),
("4","blogdescription","","yes"),
("5","users_can_register","0","yes"),
("6","admin_email","24046@ma-web.nl","yes"),
("7","start_of_week","1","yes"),
("8","use_balanceTags","0","yes"),
("9","use_smilies","1","yes"),
("10","require_name_email","1","yes"),
("11","comments_notify","1","yes"),
("12","posts_per_rss","10","yes"),
("13","rss_use_excerpt","0","yes"),
("14","mailserver_url","mail.example.com","yes"),
("15","mailserver_login","login@example.com","yes"),
("16","mailserver_pass","password","yes"),
("17","mailserver_port","110","yes"),
("18","default_category","1","yes"),
("19","default_comment_status","open","yes"),
("20","default_ping_status","open","yes"),
("21","default_pingback_flag","1","yes"),
("22","posts_per_page","10","yes"),
("23","date_format","j F Y","yes"),
("24","time_format","H:i","yes"),
("25","links_updated_date_format","j F Y H:i","yes"),
("26","comment_moderation","0","yes"),
("27","moderation_notify","1","yes"),
("28","permalink_structure","/%year%/%monthnum%/%day%/%postname%/","yes"),
("30","hack_file","0","yes"),
("31","blog_charset","UTF-8","yes"),
("32","moderation_keys","","no"),
("33","active_plugins","a:11:{i:0;s:53:\"apparelcuts-spreadshirt/spreadshirt-for-wordpress.php\";i:1;s:9:\"hello.php\";i:2;s:63:\"limit-login-attempts-reloaded/limit-login-attempts-reloaded.php\";i:3;s:67:\"mollie-payments-for-woocommerce/mollie-payments-for-woocommerce.php\";i:4;s:55:\"printful-shipping-for-woocommerce/printful-shipping.php\";i:5;s:43:\"siteground-migrator/siteground-migrator.php\";i:6;s:67:\"woo-single-page-checkout/rg108-woocommerce-single-page-checkout.php\";i:7;s:41:\"woo-smart-wishlist/wpc-smart-wishlist.php\";i:8;s:27:\"woocommerce/woocommerce.php\";i:9;s:24:\"wordpress-seo/wp-seo.php\";i:10;s:51:\"wp-migration-duplicator/wp-migration-duplicator.php\";}","yes"),
("34","category_base","","yes"),
("35","ping_sites","http://rpc.pingomatic.com/","yes"),
("36","comment_max_links","2","yes"),
("37","gmt_offset","0","yes"),
("38","default_email_category","1","yes"),
("39","recently_edited","","no"),
("40","template","neve","yes"),
("41","stylesheet","neve","yes"),
("42","comment_registration","0","yes"),
("43","html_type","text/html","yes"),
("44","use_trackback","0","yes"),
("45","default_role","subscriber","yes"),
("46","db_version","49752","yes"),
("47","uploads_use_yearmonth_folders","1","yes"),
("48","upload_path","","yes"),
("49","blog_public","1","yes"),
("50","default_link_category","2","yes"),
("51","show_on_front","posts","yes"),
("52","tag_base","","yes"),
("53","show_avatars","1","yes"),
("54","avatar_rating","G","yes"),
("55","upload_url_path","","yes"),
("56","thumbnail_size_w","150","yes"),
("57","thumbnail_size_h","150","yes"),
("58","thumbnail_crop","1","yes"),
("59","medium_size_w","300","yes"),
("60","medium_size_h","300","yes"),
("61","avatar_default","mystery","yes"),
("62","large_size_w","1024","yes"),
("63","large_size_h","1024","yes"),
("64","image_default_link_type","none","yes"),
("65","image_default_size","","yes"),
("66","image_default_align","","yes"),
("67","close_comments_for_old_posts","0","yes"),
("68","close_comments_days_old","14","yes"),
("69","thread_comments","1","yes"),
("70","thread_comments_depth","5","yes"),
("71","page_comments","0","yes"),
("72","comments_per_page","50","yes"),
("73","default_comments_page","newest","yes"),
("74","comment_order","asc","yes"),
("75","sticky_posts","a:0:{}","yes"),
("76","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes"),
("77","widget_text","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes"),
("78","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes"),
("79","uninstall_plugins","a:0:{}","no"),
("80","timezone_string","","yes"),
("81","page_for_posts","0","yes"),
("82","page_on_front","0","yes"),
("83","default_post_format","0","yes"),
("84","link_manager_enabled","0","yes"),
("85","finished_splitting_shared_terms","1","yes"),
("86","site_icon","21","yes"),
("87","medium_large_size_w","768","yes"),
("88","medium_large_size_h","0","yes"),
("89","wp_page_for_privacy_policy","3","yes"),
("90","show_comments_cookies_opt_in","1","yes"),
("91","admin_email_lifespan","1635238481","yes"),
("92","disallowed_keys","","no"),
("93","comment_previously_approved","1","yes"),
("94","auto_plugin_theme_update_emails","a:0:{}","no"),
("95","auto_update_core_dev","enabled","yes"),
("96","auto_update_core_minor","enabled","yes"),
("97","auto_update_core_major","enabled","yes"),
("98","initial_db_version","49752","yes"),
("99","webtoffee_user_roles","a:9:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:115:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:35:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:92:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"edit_theme_options\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}s:13:\"wpseo_manager\";a:2:{s:4:\"name\";s:11:\"SEO Manager\";s:12:\"capabilities\";a:38:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;s:20:\"wpseo_manage_options\";b:1;s:23:\"view_site_health_checks\";b:1;}}s:12:\"wpseo_editor\";a:2:{s:4:\"name\";s:10:\"SEO Editor\";s:12:\"capabilities\";a:36:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;}}}","yes"),
("100","fresh_site","0","yes"),
("101","WPLANG","nl_NL","yes");/*END*/
INSERT INTO webtoffee_options VALUES
("102","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes"),
("103","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes"),
("104","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes"),
("105","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes"),
("106","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes"),
("107","sidebars_widgets","a:8:{s:19:\"wp_inactive_widgets\";a:0:{}s:12:\"blog-sidebar\";a:0:{}s:12:\"shop-sidebar\";a:0:{}s:18:\"footer-one-widgets\";a:0:{}s:18:\"footer-two-widgets\";a:0:{}s:20:\"footer-three-widgets\";a:0:{}s:19:\"footer-four-widgets\";a:0:{}s:13:\"array_version\";i:3;}","yes"),
("108","cron","a:21:{i:1622564415;a:1:{s:26:\"action_scheduler_run_queue\";a:1:{s:32:\"0d04ed39571b55704c122d726248bbac\";a:3:{s:8:\"schedule\";s:12:\"every_minute\";s:4:\"args\";a:1:{i:0;s:7:\"WP Cron\";}s:8:\"interval\";i:60;}}}i:1622565148;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1622566482;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1622566999;a:1:{s:33:\"wc_admin_process_orders_milestone\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1622567098;a:1:{s:29:\"wc_admin_unsnooze_admin_notes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1622580882;a:4:{s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1622592000;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1622604571;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1622624082;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1622624095;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1622624097;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1622624598;a:2:{s:13:\"wpseo-reindex\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:31:\"wpseo_permalink_structure_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1622624599;a:1:{s:14:\"wc_admin_daily\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1622624605;a:1:{s:33:\"woocommerce_cleanup_personal_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1622626181;a:2:{s:33:\"woocommerce_cleanup_personal_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:30:\"woocommerce_tracker_send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1622636971;a:1:{s:24:\"woocommerce_cleanup_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1622648013;a:1:{s:21:\"ai1wm_storage_cleanup\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1622710998;a:1:{s:16:\"wpseo_ryte_fetch\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1622796882;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1623835831;a:1:{s:25:\"woocommerce_geoip_updater\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:11:\"fifteendays\";s:4:\"args\";a:0:{}s:8:\"interval\";i:1296000;}}}s:7:\"version\";i:2;}","yes"),
("109","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("110","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("111","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("112","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("113","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("114","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("115","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("116","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("117","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("119","recovery_keys","a:0:{}","yes"),
("120","https_detection_errors","a:1:{s:20:\"https_request_failed\";a:1:{i:0;s:23:\"HTTPS aanvraag mislukt.\";}}","yes"),
("123","theme_mods_twentytwentyone","a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1619687852;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}}}}","yes"),
("142","can_compress_scripts","1","no"),
("151","finished_updating_comment_type","1","yes"),
("159","recently_activated","a:2:{s:51:\"all-in-one-wp-migration/all-in-one-wp-migration.php\";i:1622564131;s:25:\"duplicator/duplicator.php\";i:1622563526;}","yes"),
("177","action_scheduler_hybrid_store_demarkation","5","yes"),
("178","schema-ActionScheduler_StoreSchema","3.0.1619686995","yes"),
("179","schema-ActionScheduler_LoggerSchema","2.0.1619686995","yes"),
("182","woocommerce_schema_version","430","yes"),
("183","woocommerce_store_address","Dorpstraat 538","yes"),
("184","woocommerce_store_address_2","","yes"),
("185","woocommerce_store_city","Noord Scharwoude","yes"),
("186","woocommerce_default_country","NL","yes"),
("187","woocommerce_store_postcode","1723HH","yes"),
("188","woocommerce_allowed_countries","all","yes"),
("189","woocommerce_all_except_countries","a:0:{}","yes"),
("190","woocommerce_specific_allowed_countries","a:0:{}","yes"),
("191","woocommerce_ship_to_countries","","yes"),
("192","woocommerce_specific_ship_to_countries","a:0:{}","yes"),
("193","woocommerce_default_customer_address","base","yes"),
("194","woocommerce_calc_taxes","no","yes"),
("195","woocommerce_enable_coupons","yes","yes"),
("196","woocommerce_calc_discounts_sequentially","no","no"),
("197","woocommerce_currency","EUR","yes"),
("198","woocommerce_currency_pos","left","yes"),
("199","woocommerce_price_thousand_sep",",","yes"),
("200","woocommerce_price_decimal_sep",".","yes"),
("201","woocommerce_price_num_decimals","2","yes"),
("202","woocommerce_shop_page_id","6","yes"),
("203","woocommerce_cart_redirect_after_add","no","yes"),
("204","woocommerce_enable_ajax_add_to_cart","yes","yes"),
("205","woocommerce_placeholder_image","5","yes"),
("206","woocommerce_weight_unit","kg","yes"),
("207","woocommerce_dimension_unit","cm","yes"),
("208","woocommerce_enable_reviews","yes","yes"),
("209","woocommerce_review_rating_verification_label","yes","no"),
("210","woocommerce_review_rating_verification_required","yes","no"),
("211","woocommerce_enable_review_rating","yes","yes"),
("212","woocommerce_review_rating_required","yes","no"),
("213","woocommerce_manage_stock","yes","yes"),
("214","woocommerce_hold_stock_minutes","60","no"),
("215","woocommerce_notify_low_stock","yes","no"),
("216","woocommerce_notify_no_stock","yes","no"),
("217","woocommerce_stock_email_recipient","24046@ma-web.nl","no"),
("218","woocommerce_notify_low_stock_amount","2","no"),
("219","woocommerce_notify_no_stock_amount","0","yes"),
("220","woocommerce_hide_out_of_stock_items","no","yes"),
("221","woocommerce_stock_format","","yes"),
("222","woocommerce_file_download_method","force","no"),
("223","woocommerce_downloads_require_login","no","no"),
("224","woocommerce_downloads_grant_access_after_payment","yes","no"),
("225","woocommerce_downloads_add_hash_to_filename","yes","yes"),
("226","woocommerce_prices_include_tax","no","yes"),
("227","woocommerce_tax_based_on","shipping","yes"),
("228","woocommerce_shipping_tax_class","inherit","yes"),
("229","woocommerce_tax_round_at_subtotal","no","yes"),
("230","woocommerce_tax_classes","","yes"),
("231","woocommerce_tax_display_shop","excl","yes"),
("232","woocommerce_tax_display_cart","excl","yes"),
("233","woocommerce_price_display_suffix","","yes"),
("234","woocommerce_tax_total_display","itemized","no"),
("235","woocommerce_enable_shipping_calc","yes","no"),
("236","woocommerce_shipping_cost_requires_address","no","yes"),
("237","woocommerce_ship_to_destination","billing","no"),
("238","woocommerce_shipping_debug_mode","no","yes"),
("239","woocommerce_enable_guest_checkout","yes","no"),
("240","woocommerce_enable_checkout_login_reminder","yes","no"),
("241","woocommerce_enable_signup_and_login_from_checkout","yes","no"),
("242","woocommerce_enable_myaccount_registration","no","no"),
("243","woocommerce_registration_generate_username","yes","no"),
("244","woocommerce_registration_generate_password","yes","no"),
("245","woocommerce_erasure_request_removes_order_data","yes","no"),
("246","woocommerce_erasure_request_removes_download_data","no","no"),
("247","woocommerce_allow_bulk_remove_personal_data","no","no"),
("248","woocommerce_registration_privacy_policy_text","Je persoonlijke gegevens worden gebruikt om je ervaring op deze site te ondersteunen, om toegang tot je account te beheren en voor andere doeleinden zoals omschreven in ons [privacy_policy].","yes"),
("249","woocommerce_checkout_privacy_policy_text","Je persoonlijke gegevens zullen worden gebruikt om je bestelling te verwerken, om je beleving op deze site te optimaliseren en voor andere doeleinden zoals beschreven in onze [privacy_policy].","yes"),
("250","woocommerce_delete_inactive_accounts","a:2:{s:6:\"number\";i:5;s:4:\"unit\";s:5:\"years\";}","no"),
("251","woocommerce_trash_pending_orders","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:4:\"days\";}","no"),
("252","woocommerce_trash_failed_orders","a:2:{s:6:\"number\";i:6;s:4:\"unit\";s:6:\"months\";}","no"),
("253","woocommerce_trash_cancelled_orders","a:2:{s:6:\"number\";i:12;s:4:\"unit\";s:6:\"months\";}","no"),
("254","woocommerce_anonymize_completed_orders","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}","no"),
("255","woocommerce_email_from_name","DISBRANDED CLOTHING","no"),
("256","woocommerce_email_from_address","24046@ma-web.nl","no");/*END*/
INSERT INTO webtoffee_options VALUES
("257","woocommerce_email_header_image","","no"),
("258","woocommerce_email_footer_text","{site_title} &mdash; Built with {WooCommerce}","no"),
("259","woocommerce_email_base_color","#96588a","no"),
("260","woocommerce_email_background_color","#f7f7f7","no"),
("261","woocommerce_email_body_background_color","#ffffff","no"),
("262","woocommerce_email_text_color","#3c3c3c","no"),
("263","woocommerce_merchant_email_notifications","no","no"),
("264","woocommerce_cart_page_id","7","no"),
("265","woocommerce_checkout_page_id","8","no"),
("266","woocommerce_myaccount_page_id","9","no"),
("267","woocommerce_terms_page_id","","no"),
("268","woocommerce_force_ssl_checkout","no","yes"),
("269","woocommerce_unforce_ssl_checkout","no","yes"),
("270","woocommerce_checkout_pay_endpoint","order-pay","yes"),
("271","woocommerce_checkout_order_received_endpoint","order-received","yes"),
("272","woocommerce_myaccount_add_payment_method_endpoint","add-payment-method","yes"),
("273","woocommerce_myaccount_delete_payment_method_endpoint","delete-payment-method","yes"),
("274","woocommerce_myaccount_set_default_payment_method_endpoint","set-default-payment-method","yes"),
("275","woocommerce_myaccount_orders_endpoint","orders","yes"),
("276","woocommerce_myaccount_view_order_endpoint","view-order","yes"),
("277","woocommerce_myaccount_downloads_endpoint","downloads","yes"),
("278","woocommerce_myaccount_edit_account_endpoint","edit-account","yes"),
("279","woocommerce_myaccount_edit_address_endpoint","edit-address","yes"),
("280","woocommerce_myaccount_payment_methods_endpoint","payment-methods","yes"),
("281","woocommerce_myaccount_lost_password_endpoint","lost-password","yes"),
("282","woocommerce_logout_endpoint","customer-logout","yes"),
("283","woocommerce_api_enabled","no","yes"),
("284","woocommerce_allow_tracking","no","no"),
("285","woocommerce_show_marketplace_suggestions","yes","no"),
("286","woocommerce_single_image_width","600","yes"),
("287","woocommerce_thumbnail_image_width","300","yes"),
("288","woocommerce_checkout_highlight_required_fields","yes","yes"),
("289","woocommerce_demo_store","no","no"),
("290","woocommerce_permalinks","a:5:{s:12:\"product_base\";s:7:\"product\";s:13:\"category_base\";s:17:\"product-categorie\";s:8:\"tag_base\";s:11:\"product-tag\";s:14:\"attribute_base\";s:0:\"\";s:22:\"use_verbose_page_rules\";b:0;}","yes"),
("291","current_theme_supports_woocommerce","yes","yes"),
("292","woocommerce_queue_flush_rewrite_rules","no","yes"),
("294","product_cat_children","a:0:{}","yes"),
("295","default_product_cat","15","yes"),
("298","woocommerce_version","5.3.0","yes"),
("299","woocommerce_db_version","5.3.0","yes"),
("303","yoast_migrations_free","a:1:{s:7:\"version\";s:4:\"16.4\";}","yes"),
("304","wpseo","a:44:{s:8:\"tracking\";b:0;s:22:\"license_server_version\";b:0;s:15:\"ms_defaults_set\";b:0;s:40:\"ignore_search_engines_discouraged_notice\";b:0;s:19:\"indexing_first_time\";b:1;s:16:\"indexing_started\";b:0;s:15:\"indexing_reason\";s:26:\"permalink_settings_changed\";s:29:\"indexables_indexing_completed\";b:1;s:7:\"version\";s:4:\"16.4\";s:16:\"previous_version\";s:4:\"16.2\";s:20:\"disableadvanced_meta\";b:1;s:30:\"enable_headless_rest_endpoints\";b:1;s:17:\"ryte_indexability\";b:1;s:11:\"baiduverify\";s:0:\"\";s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:0:\"\";s:20:\"has_multiple_authors\";s:0:\"\";s:16:\"environment_type\";s:0:\"\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:26:\"enable_cornerstone_content\";b:1;s:18:\"enable_xml_sitemap\";b:1;s:24:\"enable_text_link_counter\";b:1;s:22:\"show_onboarding_notice\";b:1;s:18:\"first_activated_on\";i:1619686998;s:13:\"myyoast-oauth\";b:0;s:26:\"semrush_integration_active\";b:1;s:14:\"semrush_tokens\";a:0:{}s:20:\"semrush_country_code\";s:2:\"us\";s:19:\"permalink_structure\";s:36:\"/%year%/%monthnum%/%day%/%postname%/\";s:8:\"home_url\";s:21:\"http://localhost:8888\";s:18:\"dynamic_permalinks\";b:0;s:17:\"category_base_url\";s:0:\"\";s:12:\"tag_base_url\";s:0:\"\";s:21:\"custom_taxonomy_slugs\";a:5:{s:12:\"product_type\";s:12:\"product_type\";s:18:\"product_visibility\";s:18:\"product_visibility\";s:11:\"product_cat\";s:17:\"product-categorie\";s:11:\"product_tag\";s:11:\"product-tag\";s:22:\"product_shipping_class\";s:22:\"product_shipping_class\";}s:29:\"enable_enhanced_slack_sharing\";b:1;s:25:\"zapier_integration_active\";b:0;s:19:\"zapier_subscription\";a:0:{}s:14:\"zapier_api_key\";s:0:\"\";s:23:\"enable_metabox_insights\";b:1;s:23:\"enable_link_suggestions\";b:1;}","yes"),
("305","wpseo_titles","a:153:{s:17:\"forcerewritetitle\";b:0;s:9:\"separator\";s:7:\"sc-dash\";s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:41:\"%%name%%, auteur op %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:67:\"Je hebt gezocht naar %%searchphrase%% %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:41:\"Pagina niet gevonden %%sep%% %%sitename%%\";s:25:\"social-title-author-wpseo\";s:9:\"%%title%%\";s:26:\"social-title-archive-wpseo\";s:9:\"%%title%%\";s:31:\"social-description-author-wpseo\";s:11:\"%%excerpt%%\";s:32:\"social-description-archive-wpseo\";s:11:\"%%excerpt%%\";s:29:\"social-image-url-author-wpseo\";s:0:\"\";s:30:\"social-image-url-archive-wpseo\";s:0:\"\";s:28:\"social-image-id-author-wpseo\";s:0:\"\";s:29:\"social-image-id-archive-wpseo\";s:0:\"\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:57:\"Het bericht %%POSTLINK%% verscheen eerst op %%BLOGLINK%%.\";s:20:\"noindex-author-wpseo\";b:0;s:28:\"noindex-author-noposts-wpseo\";b:1;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:0;s:12:\"disable-date\";b:0;s:19:\"disable-post_format\";b:0;s:18:\"disable-attachment\";b:1;s:23:\"is-media-purge-relevant\";b:0;s:20:\"breadcrumbs-404crumb\";s:30:\"404-fout: pagina niet gevonden\";s:29:\"breadcrumbs-display-blog-page\";b:1;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:14:\"Archieven voor\";s:18:\"breadcrumbs-enable\";b:1;s:16:\"breadcrumbs-home\";s:4:\"Home\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:13:\"Je zocht naar\";s:15:\"breadcrumbs-sep\";s:7:\"&raquo;\";s:12:\"website_name\";s:0:\"\";s:11:\"person_name\";s:0:\"\";s:11:\"person_logo\";s:0:\"\";s:22:\"alternate_website_name\";s:0:\"\";s:12:\"company_logo\";s:0:\"\";s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:7:\"company\";s:25:\"company_or_person_user_id\";b:0;s:17:\"stripcategorybase\";b:0;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:23:\"display-metabox-pt-post\";b:1;s:23:\"post_types-post-maintax\";i:0;s:21:\"schema-page-type-post\";s:7:\"WebPage\";s:24:\"schema-article-type-post\";s:7:\"Article\";s:17:\"social-title-post\";s:9:\"%%title%%\";s:23:\"social-description-post\";s:11:\"%%excerpt%%\";s:21:\"social-image-url-post\";s:0:\"\";s:20:\"social-image-id-post\";s:0:\"\";s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:23:\"display-metabox-pt-page\";b:1;s:23:\"post_types-page-maintax\";i:0;s:21:\"schema-page-type-page\";s:7:\"WebPage\";s:24:\"schema-article-type-page\";s:4:\"None\";s:17:\"social-title-page\";s:9:\"%%title%%\";s:23:\"social-description-page\";s:11:\"%%excerpt%%\";s:21:\"social-image-url-page\";s:0:\"\";s:20:\"social-image-id-page\";s:0:\"\";s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:29:\"display-metabox-pt-attachment\";b:1;s:29:\"post_types-attachment-maintax\";i:0;s:27:\"schema-page-type-attachment\";s:7:\"WebPage\";s:30:\"schema-article-type-attachment\";s:4:\"None\";s:23:\"social-title-attachment\";s:9:\"%%title%%\";s:29:\"social-description-attachment\";s:11:\"%%excerpt%%\";s:27:\"social-image-url-attachment\";s:0:\"\";s:26:\"social-image-id-attachment\";s:0:\"\";s:13:\"title-product\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:16:\"metadesc-product\";s:0:\"\";s:15:\"noindex-product\";b:0;s:26:\"display-metabox-pt-product\";b:1;s:26:\"post_types-product-maintax\";i:0;s:24:\"schema-page-type-product\";s:7:\"WebPage\";s:27:\"schema-article-type-product\";s:4:\"None\";s:20:\"social-title-product\";s:9:\"%%title%%\";s:26:\"social-description-product\";s:11:\"%%excerpt%%\";s:24:\"social-image-url-product\";s:0:\"\";s:23:\"social-image-id-product\";s:0:\"\";s:23:\"title-ptarchive-product\";s:51:\"Archief %%pt_plural%% %%page%% %%sep%% %%sitename%%\";s:26:\"metadesc-ptarchive-product\";s:0:\"\";s:25:\"bctitle-ptarchive-product\";s:0:\"\";s:25:\"noindex-ptarchive-product\";b:0;s:30:\"social-title-ptarchive-product\";s:9:\"%%title%%\";s:36:\"social-description-ptarchive-product\";s:11:\"%%excerpt%%\";s:34:\"social-image-url-ptarchive-product\";s:0:\"\";s:33:\"social-image-id-ptarchive-product\";s:0:\"\";s:18:\"title-tax-category\";s:54:\"%%term_title%% Archieven %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:28:\"display-metabox-tax-category\";b:1;s:20:\"noindex-tax-category\";b:0;s:25:\"social-title-tax-category\";s:9:\"%%title%%\";s:31:\"social-description-tax-category\";s:11:\"%%excerpt%%\";s:29:\"social-image-url-tax-category\";s:0:\"\";s:28:\"social-image-id-tax-category\";s:0:\"\";s:18:\"title-tax-post_tag\";s:54:\"%%term_title%% Archieven %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:28:\"display-metabox-tax-post_tag\";b:1;s:20:\"noindex-tax-post_tag\";b:0;s:25:\"social-title-tax-post_tag\";s:9:\"%%title%%\";s:31:\"social-description-tax-post_tag\";s:11:\"%%excerpt%%\";s:29:\"social-image-url-tax-post_tag\";s:0:\"\";s:28:\"social-image-id-tax-post_tag\";s:0:\"\";s:21:\"title-tax-post_format\";s:54:\"%%term_title%% Archieven %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:31:\"display-metabox-tax-post_format\";b:1;s:23:\"noindex-tax-post_format\";b:1;s:28:\"social-title-tax-post_format\";s:9:\"%%title%%\";s:34:\"social-description-tax-post_format\";s:11:\"%%excerpt%%\";s:32:\"social-image-url-tax-post_format\";s:0:\"\";s:31:\"social-image-id-tax-post_format\";s:0:\"\";s:21:\"title-tax-product_cat\";s:54:\"%%term_title%% Archieven %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-product_cat\";s:0:\"\";s:31:\"display-metabox-tax-product_cat\";b:1;s:23:\"noindex-tax-product_cat\";b:0;s:28:\"social-title-tax-product_cat\";s:9:\"%%title%%\";s:34:\"social-description-tax-product_cat\";s:11:\"%%excerpt%%\";s:32:\"social-image-url-tax-product_cat\";s:0:\"\";s:31:\"social-image-id-tax-product_cat\";s:0:\"\";s:29:\"taxonomy-product_cat-ptparent\";i:0;s:21:\"title-tax-product_tag\";s:54:\"%%term_title%% Archieven %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-product_tag\";s:0:\"\";s:31:\"display-metabox-tax-product_tag\";b:1;s:23:\"noindex-tax-product_tag\";b:0;s:28:\"social-title-tax-product_tag\";s:9:\"%%title%%\";s:34:\"social-description-tax-product_tag\";s:11:\"%%excerpt%%\";s:32:\"social-image-url-tax-product_tag\";s:0:\"\";s:31:\"social-image-id-tax-product_tag\";s:0:\"\";s:29:\"taxonomy-product_tag-ptparent\";i:0;s:32:\"title-tax-product_shipping_class\";s:54:\"%%term_title%% Archieven %%page%% %%sep%% %%sitename%%\";s:35:\"metadesc-tax-product_shipping_class\";s:0:\"\";s:42:\"display-metabox-tax-product_shipping_class\";b:1;s:34:\"noindex-tax-product_shipping_class\";b:0;s:39:\"social-title-tax-product_shipping_class\";s:9:\"%%title%%\";s:45:\"social-description-tax-product_shipping_class\";s:11:\"%%excerpt%%\";s:43:\"social-image-url-tax-product_shipping_class\";s:0:\"\";s:42:\"social-image-id-tax-product_shipping_class\";s:0:\"\";s:40:\"taxonomy-product_shipping_class-ptparent\";i:0;s:14:\"person_logo_id\";i:0;s:15:\"company_logo_id\";i:0;s:17:\"company_logo_meta\";b:0;s:16:\"person_logo_meta\";b:0;}","yes"),
("306","wpseo_social","a:18:{s:13:\"facebook_site\";s:0:\"\";s:13:\"instagram_url\";s:0:\"\";s:12:\"linkedin_url\";s:0:\"\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:19:\"og_default_image_id\";s:0:\"\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:21:\"og_frontpage_image_id\";s:0:\"\";s:9:\"opengraph\";b:1;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:19:\"summary_large_image\";s:11:\"youtube_url\";s:0:\"\";s:13:\"wikipedia_url\";s:0:\"\";}","yes"),
("307","_transient_jetpack_autoloader_plugin_paths","a:1:{i:0;s:29:\"{{WP_PLUGIN_DIR}}/woocommerce\";}","yes"),
("308","action_scheduler_lock_async-request-runner","1622564440","yes"),
("309","woocommerce_admin_notices","a:1:{i:0;s:20:\"no_secure_connection\";}","yes"),
("311","woocommerce_maxmind_geolocation_settings","a:1:{s:15:\"database_prefix\";s:32:\"LZFLqGX4sGbojsag3s2Gxw6IgRPF4Rsq\";}","yes"),
("312","_transient_woocommerce_webhook_ids_status_active","a:0:{}","yes"),
("313","widget_akismet_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("314","widget_woocommerce_widget_cart","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("315","widget_woocommerce_layered_nav_filters","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("316","widget_woocommerce_layered_nav","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("317","widget_woocommerce_price_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("318","widget_woocommerce_product_categories","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("319","widget_woocommerce_product_search","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("320","widget_woocommerce_product_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("321","widget_woocommerce_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("322","widget_woocommerce_recently_viewed_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("323","widget_woocommerce_top_rated_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("324","widget_woocommerce_recent_reviews","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("325","widget_woocommerce_rating_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("329","woocommerce_admin_install_timestamp","1619686999","yes"),
("332","mollie-db-version","1.0","yes"),
("333","woosw_page_id","10","yes"),
("335","_transient_wc_count_comments","O:8:\"stdClass\":7:{s:14:\"total_comments\";i:1;s:3:\"all\";i:1;s:8:\"approved\";s:1:\"1\";s:9:\"moderated\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}","yes"),
("336","wc_blocks_db_schema_version","260","yes"),
("337","wc_remote_inbox_notifications_stored_state","O:8:\"stdClass\":2:{s:22:\"there_were_no_products\";b:1;s:22:\"there_are_now_products\";b:0;}","yes"),
("348","woocommerce_meta_box_errors","a:0:{}","yes"),
("349","wpseo_ryte","a:2:{s:6:\"status\";i:-1;s:10:\"last_fetch\";i:1622539783;}","yes"),
("350","wc_remote_inbox_notifications_specs","a:19:{s:20:\"paypal_ppcp_gtm_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:20:\"paypal_ppcp_gtm_2021\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:38:\"Offer more options with the new PayPal\";s:7:\"content\";s:113:\"Get the latest PayPal extension for a full suite of payment methods with extensive currency and country coverage.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:36:\"open_wc_paypal_payments_product_page\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:61:\"https://woocommerce.com/products/woocommerce-paypal-payments/\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-04-05 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2021-04-21 00:00:00\";}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:7:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:43:\"woocommerce-gateway-paypal-express-checkout\";}}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:30:\"woocommerce-gateway-paypal-pro\";}}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:37:\"woocommerce-gateway-paypal-pro-hosted\";}}i:3;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:35:\"woocommerce-gateway-paypal-advanced\";}}i:4;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:40:\"woocommerce-gateway-paypal-digital-goods\";}}i:5;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:31:\"woocommerce-paypal-here-gateway\";}}i:6;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:44:\"woocommerce-gateway-paypal-adaptive-payments\";}}}}i:3;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:27:\"woocommerce-paypal-payments\";}}}}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:27:\"woocommerce-paypal-payments\";s:7:\"version\";s:5:\"1.2.1\";s:8:\"operator\";s:1:\"<\";}}}}}s:23:\"facebook_pixel_api_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:23:\"facebook_pixel_api_2021\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:44:\"Improve the performance of your Facebook ads\";s:7:\"content\";s:152:\"Enable Facebook Pixel and Conversions API through the latest version of Facebook for WooCommerce for improved measurement and ad targeting capabilities.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:30:\"upgrade_now_facebook_pixel_api\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:11:\"Upgrade now\";}}s:3:\"url\";s:67:\"plugin-install.php?tab=plugin-information&plugin=&section=changelog\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-05-17 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2021-06-14 00:00:00\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:24:\"facebook-for-woocommerce\";s:7:\"version\";s:5:\"2.4.0\";s:8:\"operator\";s:2:\"<=\";}}}s:16:\"facebook_ec_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:16:\"facebook_ec_2021\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:59:\"Sync your product catalog with Facebook to help boost sales\";s:7:\"content\";s:170:\"A single click adds all products to your Facebook Business Page shop. Product changes are automatically synced, with the flexibility to control which products are listed.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:22:\"learn_more_facebook_ec\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:42:\"https://woocommerce.com/products/facebook/\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-03-01 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2021-03-15 00:00:00\";}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:24:\"facebook-for-woocommerce\";}}}}s:37:\"ecomm-need-help-setting-up-your-store\";O:8:\"stdClass\":8:{s:4:\"slug\";s:37:\"ecomm-need-help-setting-up-your-store\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:32:\"Need help setting up your Store?\";s:7:\"content\";s:350:\"Schedule a free 30-min <a href=\"https://wordpress.com/support/concierge-support/\">quick start session</a> and get help from our specialists. We’re happy to walk through setup steps, show you around the WordPress.com dashboard, troubleshoot any issues you may have, and help you the find the features you need to accomplish your goals for your site.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:16:\"set-up-concierge\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:21:\"Schedule free session\";}}s:3:\"url\";s:34:\"https://wordpress.com/me/concierge\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:3:{i:0;s:35:\"woocommerce-shipping-australia-post\";i:1;s:32:\"woocommerce-shipping-canada-post\";i:2;s:30:\"woocommerce-shipping-royalmail\";}}}}s:20:\"woocommerce-services\";O:8:\"stdClass\":8:{s:4:\"slug\";s:20:\"woocommerce-services\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:26:\"WooCommerce Shipping & Tax\";s:7:\"content\";s:255:\"WooCommerce Shipping & Tax helps get your store “ready to sell” as quickly as possible. You create your products. We take care of tax calculation, payment processing, and shipping label printing! Learn more about the extension that you just installed.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:84:\"https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:20:\"woocommerce-services\";}}i:1;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\"<\";s:4:\"days\";i:2;}}}s:32:\"ecomm-unique-shopping-experience\";O:8:\"stdClass\":8:{s:4:\"slug\";s:32:\"ecomm-unique-shopping-experience\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:53:\"For a shopping experience as unique as your customers\";s:7:\"content\";s:274:\"Product Add-Ons allow your customers to personalize products while they’re shopping on your online store. No more follow-up email requests—customers get what they want, before they’re done checking out. Learn more about this extension that comes included in your plan.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:43:\"learn-more-ecomm-unique-shopping-experience\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:71:\"https://docs.woocommerce.com/document/product-add-ons/?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:3:{i:0;s:35:\"woocommerce-shipping-australia-post\";i:1;s:32:\"woocommerce-shipping-canada-post\";i:2;s:30:\"woocommerce-shipping-royalmail\";}}i:1;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\"<\";s:4:\"days\";i:2;}}}s:37:\"wc-admin-getting-started-in-ecommerce\";O:8:\"stdClass\":8:{s:4:\"slug\";s:37:\"wc-admin-getting-started-in-ecommerce\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:38:\"Getting Started in eCommerce - webinar\";s:7:\"content\";s:174:\"We want to make eCommerce and this process of getting started as easy as possible for you. Watch this webinar to get tips on how to have our store up and running in a breeze.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:17:\"watch-the-webinar\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:17:\"Watch the webinar\";}}s:3:\"url\";s:28:\"https://youtu.be/V_2XtCOyZ7o\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:12:\"setup_client\";s:9:\"operation\";s:2:\"!=\";s:5:\"value\";b:1;}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:3:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:13:\"product_count\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:1:\"0\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:7:\"revenue\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:4:\"none\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:7:\"revenue\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:10:\"up-to-2500\";}}}}}s:18:\"your-first-product\";O:8:\"stdClass\":8:{s:4:\"slug\";s:18:\"your-first-product\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:18:\"Your first product\";s:7:\"content\";s:461:\"That\'s huge! You\'re well on your way to building a successful online store — now it’s time to think about how you\'ll fulfill your orders.<br/><br/>Read our shipping guide to learn best practices and options for putting together your shipping strategy. And for WooCommerce stores in the United States, you can print discounted shipping labels via USPS with <a href=\"https://href.li/?https://woocommerce.com/shipping\" target=\"_blank\">WooCommerce Shipping</a>.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:82:\"https://woocommerce.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:12:\"stored_state\";s:5:\"index\";s:22:\"there_were_no_products\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";b:1;}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:12:\"stored_state\";s:5:\"index\";s:22:\"there_are_now_products\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";b:1;}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:13:\"product_count\";s:9:\"operation\";s:2:\">=\";s:5:\"value\";i:1;}i:3;O:8:\"stdClass\":5:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:13:\"product_types\";s:9:\"operation\";s:8:\"contains\";s:5:\"value\";s:8:\"physical\";s:7:\"default\";a:0:{}}}}s:31:\"wc-square-apple-pay-boost-sales\";O:8:\"stdClass\":8:{s:4:\"slug\";s:31:\"wc-square-apple-pay-boost-sales\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:26:\"Boost sales with Apple Pay\";s:7:\"content\";s:191:\"Now that you accept Apple Pay® with Square you can increase conversion rates by letting your customers know that Apple Pay® is available. Here’s a marketing guide to help you get started.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:27:\"boost-sales-marketing-guide\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:19:\"See marketing guide\";}}s:3:\"url\";s:97:\"https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=square-boost-sales\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:9:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.8\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:18:\"woocommerce-square\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"2.3\";}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:27:\"wc_square_apple_pay_enabled\";s:5:\"value\";i:1;s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:38:\"wc-square-apple-pay-grow-your-business\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:4;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:38:\"wc-square-apple-pay-grow-your-business\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}i:5;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:27:\"wcpay-apple-pay-boost-sales\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:27:\"wcpay-apple-pay-boost-sales\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}i:7;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:34:\"wcpay-apple-pay-grow-your-business\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:34:\"wcpay-apple-pay-grow-your-business\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}}}s:38:\"wc-square-apple-pay-grow-your-business\";O:8:\"stdClass\":8:{s:4:\"slug\";s:38:\"wc-square-apple-pay-grow-your-business\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:45:\"Grow your business with Square and Apple Pay \";s:7:\"content\";s:178:\"Now more than ever, shoppers want a fast, simple, and secure online checkout experience. Increase conversion rates by letting your customers know that you now accept Apple Pay®.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:34:\"grow-your-business-marketing-guide\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:19:\"See marketing guide\";}}s:3:\"url\";s:104:\"https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=square-grow-your-business\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:9:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.8\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:18:\"woocommerce-square\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"2.3\";}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:27:\"wc_square_apple_pay_enabled\";s:5:\"value\";i:2;s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:31:\"wc-square-apple-pay-boost-sales\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:4;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:31:\"wc-square-apple-pay-boost-sales\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}i:5;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:27:\"wcpay-apple-pay-boost-sales\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:27:\"wcpay-apple-pay-boost-sales\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}i:7;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:34:\"wcpay-apple-pay-grow-your-business\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:34:\"wcpay-apple-pay-grow-your-business\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}}}s:32:\"wcpay-apple-pay-is-now-available\";O:8:\"stdClass\":8:{s:4:\"slug\";s:32:\"wcpay-apple-pay-is-now-available\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:53:\"Apple Pay is now available with WooCommerce Payments!\";s:7:\"content\";s:397:\"Increase your conversion rate by offering a fast and secure checkout with <a href=\"https://woocommerce.com/apple-pay/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_applepay\" target=\"_blank\">Apple Pay</a>®. It’s free to get started with <a href=\"https://woocommerce.com/payments/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_applepay\" target=\"_blank\">WooCommerce Payments</a>.\";}}s:7:\"actions\";a:2:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:13:\"add-apple-pay\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:13:\"Add Apple Pay\";}}s:3:\"url\";s:69:\"/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}i:1;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:121:\"https://docs.woocommerce.com/document/payments/apple-pay/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_applepay\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.8\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:20:\"woocommerce-payments\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:5:\"2.3.0\";}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:26:\"wcpay_is_apple_pay_enabled\";s:5:\"value\";b:0;s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}}}s:27:\"wcpay-apple-pay-boost-sales\";O:8:\"stdClass\":8:{s:4:\"slug\";s:27:\"wcpay-apple-pay-boost-sales\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:26:\"Boost sales with Apple Pay\";s:7:\"content\";s:205:\"Now that you accept Apple Pay® with WooCommerce Payments you can increase conversion rates by letting your customers know that Apple Pay® is available. Here’s a marketing guide to help you get started.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:27:\"boost-sales-marketing-guide\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:19:\"See marketing guide\";}}s:3:\"url\";s:96:\"https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=wcpay-boost-sales\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.8\";}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:26:\"wcpay_is_apple_pay_enabled\";s:5:\"value\";i:1;s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:34:\"wcpay-apple-pay-grow-your-business\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:34:\"wcpay-apple-pay-grow-your-business\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}}}s:34:\"wcpay-apple-pay-grow-your-business\";O:8:\"stdClass\":8:{s:4:\"slug\";s:34:\"wcpay-apple-pay-grow-your-business\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:58:\"Grow your business with WooCommerce Payments and Apple Pay\";s:7:\"content\";s:178:\"Now more than ever, shoppers want a fast, simple, and secure online checkout experience. Increase conversion rates by letting your customers know that you now accept Apple Pay®.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:34:\"grow-your-business-marketing-guide\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:19:\"See marketing guide\";}}s:3:\"url\";s:103:\"https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=wcpay-grow-your-business\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.8\";}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:26:\"wcpay_is_apple_pay_enabled\";s:5:\"value\";i:2;s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:27:\"wcpay-apple-pay-boost-sales\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:27:\"wcpay-apple-pay-boost-sales\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}}}s:37:\"wc-admin-optimizing-the-checkout-flow\";O:8:\"stdClass\":8:{s:4:\"slug\";s:37:\"wc-admin-optimizing-the-checkout-flow\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:28:\"Optimizing the checkout flow\";s:7:\"content\";s:171:\"It\'s crucial to get your store\'s checkout as smooth as possible to avoid losing sales. Let\'s take a look at how you can optimize the checkout experience for your shoppers.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:28:\"optimizing-the-checkout-flow\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:78:\"https://woocommerce.com/posts/optimizing-woocommerce-checkout?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\">\";s:4:\"days\";i:3;}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:45:\"woocommerce_task_list_tracked_completed_tasks\";s:9:\"operation\";s:8:\"contains\";s:5:\"value\";s:8:\"payments\";s:7:\"default\";a:0:{}}}}s:39:\"wc-admin-first-five-things-to-customize\";O:8:\"stdClass\":8:{s:4:\"slug\";s:39:\"wc-admin-first-five-things-to-customize\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:45:\"The first 5 things to customize in your store\";s:7:\"content\";s:173:\"Deciding what to start with first is tricky. To help you properly prioritize, we\'ve put together this short list of the first few things you should customize in WooCommerce.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:82:\"https://woocommerce.com/posts/first-things-customize-woocommerce/?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\">\";s:4:\"days\";i:2;}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:45:\"woocommerce_task_list_tracked_completed_tasks\";s:5:\"value\";s:9:\"NOT EMPTY\";s:7:\"default\";s:9:\"NOT EMPTY\";s:9:\"operation\";s:2:\"!=\";}}}s:32:\"wc-payments-qualitative-feedback\";O:8:\"stdClass\":8:{s:4:\"slug\";s:32:\"wc-payments-qualitative-feedback\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:55:\"WooCommerce Payments setup - let us know what you think\";s:7:\"content\";s:146:\"Congrats on enabling WooCommerce Payments for your store. Please share your feedback in this 2 minute survey to help us improve the setup process.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:35:\"qualitative-feedback-from-new-users\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:14:\"Share feedback\";}}s:3:\"url\";s:39:\"https://automattic.survey.fm/wc-pay-new\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:1:{i:0;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:45:\"woocommerce_task_list_tracked_completed_tasks\";s:9:\"operation\";s:8:\"contains\";s:5:\"value\";s:20:\"woocommerce-payments\";s:7:\"default\";a:0:{}}}}s:29:\"share-your-feedback-on-paypal\";O:8:\"stdClass\":8:{s:4:\"slug\";s:29:\"share-your-feedback-on-paypal\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:29:\"Share your feedback on PayPal\";s:7:\"content\";s:127:\"Share your feedback in this 2 minute survey about how we can make the process of accepting payments more useful for your store.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:14:\"share-feedback\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:14:\"Share feedback\";}}s:3:\"url\";s:43:\"http://automattic.survey.fm/paypal-feedback\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:26:\"woocommerce-gateway-stripe\";}}}}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:43:\"woocommerce-gateway-paypal-express-checkout\";}}}}s:31:\"wcpay_instant_deposits_gtm_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:31:\"wcpay_instant_deposits_gtm_2021\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:69:\"Get paid within minutes – Instant Deposits for WooCommerce Payments\";s:7:\"content\";s:384:\"Stay flexible with immediate access to your funds when you need them – including nights, weekends, and holidays. With <a href=\"https://woocommerce.com/products/woocommerce-payments/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_instant_deposits\">WooCommerce Payments\'</a> new Instant Deposits feature, you’re able to transfer your earnings to a debit card within minutes.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:40:\"Learn about Instant Deposits eligibility\";}}s:3:\"url\";s:136:\"https://docs.woocommerce.com/document/payments/instant-deposits/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_instant_deposits\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-05-18 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2021-06-01 00:00:00\";}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:5:\"value\";s:2:\"US\";s:9:\"operation\";s:1:\"=\";}i:3;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:20:\"woocommerce-payments\";}}}}s:39:\"wc-subscriptions-security-update-3-0-15\";O:8:\"stdClass\":8:{s:4:\"slug\";s:39:\"wc-subscriptions-security-update-3-0-15\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:42:\"WooCommerce Subscriptions security update!\";s:7:\"content\";s:736:\"We recently released an important security update to WooCommerce Subscriptions. To ensure your site\'s data is protected, please upgrade <strong>WooCommerce Subscriptions to version 3.0.15</strong> or later.<br/><br/>Click the button below to view and update to the latest Subscriptions version, or log in to <a href=\"https://woocommerce.com/my-dashboard\">WooCommerce.com Dashboard</a> and navigate to your <strong>Downloads</strong> page.<br/><br/>We recommend always using the latest version of WooCommerce Subscriptions, and other software running on your site, to ensure maximum security.<br/><br/>If you have any questions we are here to help — just <a href=\"https://woocommerce.com/my-account/create-a-ticket/\">open a ticket</a>.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:30:\"update-wc-subscriptions-3-0-15\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:19:\"View latest version\";}}s:3:\"url\";s:30:\"&page=wc-addons&section=helper\";s:18:\"url_is_admin_query\";b:1;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:1:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:25:\"woocommerce-subscriptions\";s:8:\"operator\";s:1:\"<\";s:7:\"version\";s:6:\"3.0.15\";}}}}","yes"),
("357","_transient_woocommerce_reports-transient-version","1619687030","yes"),
("363","mollie-payments-for-woocommerce_profile_merchant_id","pfl_Aa7grdeUDJ","yes"),
("364","mollie-payments-for-woocommerce_live_api_key","live_rUDD5psQvxE3ePxuz4zCMQQcsRQsjw","yes"),
("365","mollie-payments-for-woocommerce_test_mode_enabled","yes","yes"),
("366","mollie-payments-for-woocommerce_test_api_key","test_8hFGcksV8AKtgdbMyehwFRGgsAxU5g","yes"),
("367","mollie-payments-for-woocommerce_debug","yes","yes"),
("373","woocommerce_task_list_hidden","yes","yes"),
("400","auto_update_plugins","a:13:{i:0;s:19:\"akismet/akismet.php\";i:1;s:9:\"hello.php\";i:2;s:67:\"mollie-payments-for-woocommerce/mollie-payments-for-woocommerce.php\";i:3;s:27:\"woocommerce/woocommerce.php\";i:4;s:67:\"woo-single-page-checkout/rg108-woocommerce-single-page-checkout.php\";i:5;s:41:\"woo-smart-wishlist/wpc-smart-wishlist.php\";i:6;s:24:\"wordpress-seo/wp-seo.php\";i:7;s:40:\"wordpress-seo-premium/wp-seo-premium.php\";i:8;s:25:\"wpseo-video/video-seo.php\";i:9;s:25:\"wpseo-local/local-seo.php\";i:10;s:39:\"wpseo-woocommerce/wpseo-woocommerce.php\";i:11;s:25:\"wpseo-news/wpseo-news.php\";i:12;s:57:\"acf-content-analysis-for-yoast-seo/yoast-acf-analysis.php\";}","no"),
("402","storefront_nux_fresh_site","0","yes"),
("403","storefront_nux_guided_tour","1","yes"),
("406","theme_mods_storefront","a:1:{s:18:\"custom_css_post_id\";i:-1;}","yes"),
("409","theme_mods_oceanwp","a:1:{s:18:\"custom_css_post_id\";i:-1;}","yes"),
("426","current_theme","Neve","yes"),
("427","theme_mods_neve","a:39:{i:0;b:0;s:24:\"neve_migrated_hfg_colors\";b:1;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:16;}s:13:\"ti_prev_theme\";s:15:\"twentytwentyone\";s:18:\"custom_css_post_id\";i:-1;s:11:\"custom_logo\";i:18;s:17:\"logo_show_tagline\";i:0;s:15:\"logo_show_title\";i:0;s:14:\"logo_max_width\";s:41:\"{\"mobile\":120,\"tablet\":204,\"desktop\":229}\";s:33:\"hfg_header_layout_main_background\";a:8:{s:4:\"type\";s:5:\"image\";s:8:\"imageUrl\";s:0:\"\";s:10:\"focusPoint\";a:2:{s:1:\"x\";d:0.5;s:1:\"y\";d:0.5;}s:10:\"colorValue\";s:17:\"var(--nv-site-bg)\";s:17:\"overlayColorValue\";s:0:\"\";s:14:\"overlayOpacity\";i:50;s:5:\"fixed\";b:0;s:11:\"useFeatured\";b:0;}s:17:\"hfg_header_layout\";s:351:\"{\"desktop\":{\"top\":[],\"main\":[{\"x\":0,\"y\":1,\"width\":4,\"height\":1,\"id\":\"logo\"},{\"x\":4,\"y\":1,\"width\":8,\"height\":1,\"id\":\"primary-menu\"}],\"bottom\":[]},\"mobile\":{\"top\":[{\"x\":0,\"y\":1,\"width\":8,\"height\":1,\"id\":\"logo\"},{\"x\":8,\"y\":1,\"width\":4,\"height\":1,\"id\":\"nav-icon\"}],\"main\":[],\"bottom\":[],\"sidebar\":[{\"x\":0,\"y\":1,\"width\":8,\"height\":1,\"id\":\"primary-menu\"}]}}\";s:34:\"header_cart_icon_component_padding\";a:6:{s:6:\"mobile\";a:4:{s:3:\"top\";i:0;s:5:\"right\";i:10;s:6:\"bottom\";i:0;s:4:\"left\";i:10;}s:6:\"tablet\";a:4:{s:3:\"top\";s:1:\"0\";s:5:\"right\";s:2:\"10\";s:6:\"bottom\";s:1:\"8\";s:4:\"left\";s:2:\"39\";}s:7:\"desktop\";a:4:{s:3:\"top\";i:0;s:5:\"right\";i:10;s:6:\"bottom\";i:0;s:4:\"left\";i:10;}s:11:\"mobile-unit\";s:2:\"px\";s:11:\"tablet-unit\";s:2:\"px\";s:12:\"desktop-unit\";s:2:\"px\";}s:20:\"logo_component_align\";a:3:{s:6:\"mobile\";s:5:\"right\";s:6:\"tablet\";s:5:\"right\";s:7:\"desktop\";s:4:\"left\";}s:32:\"header_cart_icon_component_align\";a:3:{s:7:\"desktop\";s:4:\"left\";s:6:\"tablet\";s:4:\"left\";s:6:\"mobile\";s:4:\"left\";}s:22:\"logo_component_padding\";a:6:{s:6:\"mobile\";a:4:{s:3:\"top\";i:10;s:5:\"right\";i:0;s:6:\"bottom\";i:10;s:4:\"left\";i:0;}s:6:\"tablet\";a:4:{s:3:\"top\";s:2:\"10\";s:5:\"right\";i:0;s:6:\"bottom\";s:1:\"2\";s:4:\"left\";i:0;}s:7:\"desktop\";a:4:{s:3:\"top\";i:10;s:5:\"right\";i:0;s:6:\"bottom\";i:10;s:4:\"left\";i:0;}s:11:\"mobile-unit\";s:2:\"px\";s:11:\"tablet-unit\";s:2:\"px\";s:12:\"desktop-unit\";s:2:\"px\";}s:26:\"nav-icon_component_padding\";a:6:{s:6:\"mobile\";a:4:{s:3:\"top\";i:10;s:5:\"right\";i:15;s:6:\"bottom\";i:10;s:4:\"left\";i:15;}s:6:\"tablet\";a:4:{s:3:\"top\";i:10;s:5:\"right\";i:15;s:6:\"bottom\";i:10;s:4:\"left\";i:15;}s:7:\"desktop\";a:4:{s:3:\"top\";i:10;s:5:\"right\";i:15;s:6:\"bottom\";i:10;s:4:\"left\";i:15;}s:11:\"mobile-unit\";s:2:\"px\";s:11:\"tablet-unit\";s:2:\"px\";s:12:\"desktop-unit\";s:2:\"px\";}s:25:\"nav-icon_component_margin\";a:6:{s:6:\"mobile\";a:4:{s:3:\"top\";i:0;s:5:\"right\";i:0;s:6:\"bottom\";i:0;s:4:\"left\";i:0;}s:6:\"tablet\";a:4:{s:3:\"top\";s:2:\"10\";s:5:\"right\";s:2:\"10\";s:6:\"bottom\";s:2:\"10\";s:4:\"left\";s:2:\"10\";}s:7:\"desktop\";a:4:{s:3:\"top\";i:0;s:5:\"right\";i:0;s:6:\"bottom\";i:0;s:4:\"left\";i:0;}s:11:\"mobile-unit\";s:2:\"px\";s:11:\"tablet-unit\";s:2:\"px\";s:12:\"desktop-unit\";s:2:\"px\";}s:21:\"logo_component_margin\";a:6:{s:6:\"mobile\";a:4:{s:3:\"top\";i:0;s:5:\"right\";i:0;s:6:\"bottom\";i:0;s:4:\"left\";i:0;}s:6:\"tablet\";a:4:{s:3:\"top\";s:1:\"3\";s:5:\"right\";s:1:\"3\";s:6:\"bottom\";s:1:\"3\";s:4:\"left\";s:1:\"3\";}s:7:\"desktop\";a:4:{s:3:\"top\";i:0;s:5:\"right\";i:0;s:6:\"bottom\";i:0;s:4:\"left\";i:0;}s:11:\"mobile-unit\";s:2:\"px\";s:11:\"tablet-unit\";s:2:\"px\";s:12:\"desktop-unit\";s:2:\"px\";}s:24:\"nav-icon_component_align\";a:3:{s:6:\"mobile\";s:5:\"right\";s:6:\"tablet\";s:5:\"right\";s:7:\"desktop\";s:5:\"right\";}s:33:\"header_cart_icon_component_margin\";a:6:{s:6:\"mobile\";a:4:{s:3:\"top\";i:0;s:5:\"right\";i:0;s:6:\"bottom\";i:0;s:4:\"left\";i:0;}s:6:\"tablet\";a:4:{s:3:\"top\";s:1:\"1\";s:5:\"right\";s:1:\"1\";s:6:\"bottom\";s:1:\"1\";s:4:\"left\";s:1:\"1\";}s:7:\"desktop\";a:4:{s:3:\"top\";i:0;s:5:\"right\";i:0;s:6:\"bottom\";i:0;s:4:\"left\";i:0;}s:11:\"mobile-unit\";s:2:\"px\";s:11:\"tablet-unit\";s:2:\"px\";s:12:\"desktop-unit\";s:2:\"px\";}s:34:\"header_search_responsive_open_type\";s:7:\"minimal\";s:40:\"header_search_responsive_component_align\";a:3:{s:7:\"desktop\";s:4:\"left\";s:6:\"tablet\";s:5:\"right\";s:6:\"mobile\";s:4:\"left\";}s:42:\"header_search_responsive_component_padding\";a:6:{s:6:\"mobile\";a:4:{s:3:\"top\";i:0;s:5:\"right\";i:10;s:6:\"bottom\";i:0;s:4:\"left\";i:10;}s:6:\"tablet\";a:4:{s:3:\"top\";i:0;s:5:\"right\";s:2:\"10\";s:6:\"bottom\";i:0;s:4:\"left\";s:2:\"30\";}s:7:\"desktop\";a:4:{s:3:\"top\";i:0;s:5:\"right\";i:10;s:6:\"bottom\";i:0;s:4:\"left\";i:10;}s:11:\"mobile-unit\";s:2:\"px\";s:11:\"tablet-unit\";s:2:\"px\";s:12:\"desktop-unit\";s:2:\"px\";}s:41:\"header_search_responsive_component_margin\";a:6:{s:6:\"mobile\";a:4:{s:3:\"top\";i:0;s:5:\"right\";i:0;s:6:\"bottom\";i:0;s:4:\"left\";i:0;}s:6:\"tablet\";a:4:{s:3:\"top\";s:1:\"5\";s:5:\"right\";s:1:\"5\";s:6:\"bottom\";s:1:\"5\";s:4:\"left\";s:1:\"5\";}s:7:\"desktop\";a:4:{s:3:\"top\";i:0;s:5:\"right\";i:0;s:6:\"bottom\";i:0;s:4:\"left\";i:0;}s:11:\"mobile-unit\";s:2:\"px\";s:11:\"tablet-unit\";s:2:\"px\";s:12:\"desktop-unit\";s:2:\"px\";}s:17:\"hfg_footer_layout\";s:93:\"{\"desktop\":{\"top\":[],\"bottom\":[{\"x\":0,\"y\":1,\"width\":12,\"height\":1,\"id\":\"footer_copyright\"}]}}\";s:31:\"hfg_footer_layout_bottom_layout\";s:16:\"layout-fullwidth\";s:24:\"footer_copyright_content\";s:84:\"<p>Design by <a href=\"http://streatsdesign.com\" rel=\"nofollow\">StreatsDesign</a></p>\";s:35:\"hfg_footer_layout_bottom_background\";a:8:{s:4:\"type\";s:5:\"color\";s:8:\"imageUrl\";s:0:\"\";s:10:\"focusPoint\";a:2:{s:1:\"x\";d:0.5;s:1:\"y\";d:0.5;}s:10:\"colorValue\";s:7:\"#000000\";s:17:\"overlayColorValue\";s:0:\"\";s:14:\"overlayOpacity\";i:50;s:5:\"fixed\";b:0;s:11:\"useFeatured\";b:0;}s:39:\"hfg_footer_layout_bottom_new_text_color\";s:7:\"#ffffff\";s:24:\"neve_form_fields_spacing\";i:3;s:24:\"neve_form_fields_padding\";a:5:{s:3:\"top\";s:1:\"2\";s:5:\"right\";s:2:\"12\";s:6:\"bottom\";s:1:\"7\";s:4:\"left\";s:1:\"8\";s:4:\"unit\";s:2:\"px\";}s:29:\"neve_form_fields_border_width\";a:5:{s:3:\"top\";s:1:\"0\";s:5:\"right\";s:1:\"1\";s:4:\"left\";s:1:\"1\";s:6:\"bottom\";s:1:\"1\";s:4:\"unit\";s:2:\"px\";}s:30:\"neve_form_fields_border_radius\";a:5:{s:3:\"top\";s:1:\"5\";s:5:\"right\";s:1:\"5\";s:4:\"left\";s:1:\"5\";s:6:\"bottom\";s:1:\"5\";s:4:\"unit\";s:2:\"px\";}s:18:\"neve_label_spacing\";i:11;s:21:\"neve_form_button_type\";s:9:\"secondary\";s:19:\"neve_label_typeface\";a:3:{s:13:\"textTransform\";s:10:\"capitalize\";s:4:\"flag\";b:1;s:10:\"lineHeight\";a:4:{s:6:\"suffix\";a:3:{s:6:\"mobile\";s:2:\"em\";s:6:\"tablet\";s:2:\"em\";s:7:\"desktop\";s:2:\"em\";}s:6:\"mobile\";s:0:\"\";s:6:\"tablet\";s:0:\"\";s:7:\"desktop\";s:0:\"\";}}s:22:\"neve_button_appearance\";a:7:{s:12:\"borderRadius\";a:4:{s:3:\"top\";i:3;s:5:\"right\";i:3;s:6:\"bottom\";i:3;s:4:\"left\";i:3;}s:11:\"borderWidth\";a:4:{s:3:\"top\";i:1;s:5:\"right\";i:1;s:6:\"bottom\";i:1;s:4:\"left\";i:1;}s:4:\"type\";s:4:\"fill\";s:10:\"background\";s:16:\"rgba(0, 0, 0, 0)\";s:15:\"backgroundHover\";s:7:\"#ffffff\";s:4:\"text\";s:7:\"#000000\";s:9:\"textHover\";s:7:\"#000000\";}s:19:\"neve_button_padding\";a:6:{s:6:\"mobile\";a:4:{s:3:\"top\";s:1:\"5\";s:5:\"right\";i:12;s:6:\"bottom\";i:8;s:4:\"left\";i:12;}s:6:\"tablet\";a:4:{s:3:\"top\";i:8;s:5:\"right\";i:12;s:6:\"bottom\";i:8;s:4:\"left\";i:12;}s:7:\"desktop\";a:4:{s:3:\"top\";i:8;s:5:\"right\";i:12;s:6:\"bottom\";i:8;s:4:\"left\";i:12;}s:11:\"mobile-unit\";s:2:\"px\";s:11:\"tablet-unit\";s:2:\"px\";s:12:\"desktop-unit\";s:2:\"px\";}s:20:\"neve_button_typeface\";a:3:{s:13:\"textTransform\";s:9:\"uppercase\";s:4:\"flag\";b:0;s:10:\"lineHeight\";a:4:{s:6:\"suffix\";a:3:{s:6:\"mobile\";s:2:\"em\";s:6:\"tablet\";s:2:\"em\";s:7:\"desktop\";s:2:\"em\";}s:6:\"mobile\";d:1.6;s:6:\"tablet\";d:1.6;s:7:\"desktop\";d:1.6;}}}","yes"),
("428","theme_switched","","yes"),
("429","neve_install","1619687853","yes"),
("432","neve_user_check_time","1619687854","yes"),
("433","neve_new_user","yes","yes"),
("434","woocommerce_catalog_rows","4","yes"),
("435","woocommerce_catalog_columns","3","yes"),
("436","woocommerce_maybe_regenerate_images_hash","991b1ca641921cf0f5baf7a2fe85861b","yes"),
("448","neve_notice_dismissed","yes","yes"),
("450","_transient_product_query-transient-version","1622543932","yes"),
("451","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes"),
("492","_transient_health-check-site-status-result","{\"good\":\"13\",\"recommended\":\"7\",\"critical\":\"0\"}","yes"),
("513","_transient_timeout_neve_all_languages","1623144517","no"),
("514","_transient_neve_all_languages","a:1:{s:12:\"translations\";a:47:{i:0;a:7:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2021-05-05 11:03:14\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}}i:1;a:7:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-02-26 11:24:11\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}}i:2;a:7:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2021-04-12 16:18:52\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}}i:3;a:7:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2019-08-13 23:17:18\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}}i:4;a:7:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-03-01 16:20:02\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:80:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}}i:5;a:7:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-03-01 16:19:31\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}}i:6;a:7:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-12-18 21:05:56\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}}i:7;a:7:{s:8:\"language\";s:5:\"de_AT\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-03-01 16:19:05\";s:12:\"english_name\";s:16:\"German (Austria)\";s:11:\"native_name\";s:21:\"Deutsch (Österreich)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/de_AT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}}i:8;a:7:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-12-19 00:39:41\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}}i:9;a:7:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2021-04-09 18:16:14\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}}i:10;a:7:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-10-19 09:09:49\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}}i:11;a:7:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2021-03-17 08:47:45\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}}i:12;a:7:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-02-06 23:41:00\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}}i:13;a:7:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2021-03-18 11:09:04\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}}i:14;a:7:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-02-06 23:43:20\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}}i:15;a:7:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2021-04-29 13:22:55\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}}i:16;a:7:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2021-04-29 09:13:30\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}}i:17;a:7:{s:8:\"language\";s:5:\"es_EC\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2021-04-29 09:13:56\";s:12:\"english_name\";s:17:\"Spanish (Ecuador)\";s:11:\"native_name\";s:19:\"Español de Ecuador\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/es_EC.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}}i:18;a:7:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2019-03-11 19:34:24\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}}i:19;a:7:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2021-02-10 17:03:11\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}}i:20;a:7:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2021-04-29 09:14:50\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}}i:21;a:7:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2019-11-15 15:58:27\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}}i:22;a:7:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2019-10-01 07:48:32\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}}i:23;a:7:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-10-04 17:56:01\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}}i:24;a:7:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-02-25 09:28:19\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}}i:25;a:7:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-07-17 11:43:22\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}}i:26;a:7:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-02-11 17:54:34\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}}i:27;a:7:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2019-03-19 02:54:37\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}}i:28;a:7:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2021-03-25 21:30:04\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}}i:29;a:7:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2021-04-16 14:28:49\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}}i:30;a:7:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-11-10 01:25:37\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}}i:31;a:7:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2021-05-04 22:35:26\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}}i:32;a:7:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2018-12-13 07:28:20\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}}i:33;a:7:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-08-22 15:27:50\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}}i:34;a:7:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2021-04-29 09:32:40\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}}i:35;a:7:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2019-01-18 07:26:33\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}}i:36;a:7:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-07-07 01:57:43\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}}i:37;a:7:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2021-03-16 17:52:07\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}}i:38;a:7:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2021-04-11 13:34:38\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}}i:39;a:7:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2021-03-24 06:57:16\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}}i:40;a:7:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-02-27 15:47:53\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}}i:41;a:7:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2019-08-18 13:12:55\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}}i:42;a:7:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2021-05-08 18:04:57\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}}i:43;a:7:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-02-06 20:51:43\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}}i:44;a:7:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2019-10-01 16:09:45\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}}i:45;a:7:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-03-04 23:38:45\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}}i:46;a:7:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:6:\"2.11.2\";s:7:\"updated\";s:19:\"2020-06-29 21:40:09\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/theme/neve/2.11.2/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}}}}","no"),
("520","_transient_timeout__woocommerce_helper_updates","1622582918","no"),
("521","_transient__woocommerce_helper_updates","a:4:{s:4:\"hash\";s:32:\"d751713988987e9331980363e24189ce\";s:7:\"updated\";i:1622539718;s:8:\"products\";a:0:{}s:6:\"errors\";a:1:{i:0;s:10:\"http-error\";}}","no");/*END*/
INSERT INTO webtoffee_options VALUES
("525","_transient_timeout__woocommerce_upload_directory_status","1622626171","no"),
("526","_transient__woocommerce_upload_directory_status","protected","no"),
("527","woocommerce_onboarding_profile","a:1:{s:9:\"completed\";b:1;}","yes"),
("530","woocommerce_admin_version","2.2.6","yes"),
("531","wc_remote_inbox_notifications_wca_updated","","yes"),
("539","auto_core_update_notified","a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:15:\"24046@ma-web.nl\";s:7:\"version\";s:5:\"5.7.2\";s:9:\"timestamp\";i:1622539780;}","no"),
("541","_transient_wc_attribute_taxonomies","a:0:{}","yes"),
("542","_transient_timeout_wpseo_total_unindexed_posts","1622626183","no"),
("543","_transient_wpseo_total_unindexed_posts","0","no"),
("544","_transient_timeout_wpseo_total_unindexed_terms","1622626183","no"),
("545","_transient_wpseo_total_unindexed_terms","0","no"),
("546","_transient_timeout_wpseo_total_unindexed_post_type_archives","1622626183","no"),
("547","_transient_wpseo_total_unindexed_post_type_archives","0","no"),
("548","_transient_timeout_wpseo_unindexed_post_link_count","1622626183","no"),
("549","_transient_wpseo_unindexed_post_link_count","0","no"),
("550","_transient_timeout_wpseo_unindexed_term_link_count","1622626183","no"),
("551","_transient_wpseo_unindexed_term_link_count","0","no"),
("554","rewrite_rules","a:168:{s:24:\"^wc-auth/v([1]{1})/(.*)?\";s:63:\"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]\";s:22:\"^wc-api/v([1-3]{1})/?$\";s:51:\"index.php?wc-api-version=$matches[1]&wc-api-route=/\";s:24:\"^wc-api/v([1-3]{1})(.*)?\";s:61:\"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]\";s:19:\"sitemap_index\\.xml$\";s:19:\"index.php?sitemap=1\";s:31:\"([^/]+?)-sitemap([0-9]+)?\\.xml$\";s:51:\"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]\";s:24:\"([a-z]+)?-?sitemap\\.xsl$\";s:39:\"index.php?yoast-sitemap-xsl=$matches[1]\";s:9:\"winkel/?$\";s:27:\"index.php?post_type=product\";s:39:\"winkel/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:34:\"winkel/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:26:\"winkel/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=product&paged=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:59:\"^.well-known/apple-developer-merchantid-domain-association$\";s:35:\"index.php?appleparam=applepaydirect\";s:19:\"^wishlist/([\\w]+)/?\";s:41:\"index.php?page_id=10&woosw_id=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:32:\"category/(.+?)/wc-api(/(.*))?/?$\";s:54:\"index.php?category_name=$matches[1]&wc-api=$matches[3]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:29:\"tag/([^/]+)/wc-api(/(.*))?/?$\";s:44:\"index.php?tag=$matches[1]&wc-api=$matches[3]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:56:\"product-categorie/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:51:\"product-categorie/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:32:\"product-categorie/(.+?)/embed/?$\";s:44:\"index.php?product_cat=$matches[1]&embed=true\";s:44:\"product-categorie/(.+?)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_cat=$matches[1]&paged=$matches[2]\";s:26:\"product-categorie/(.+?)/?$\";s:33:\"index.php?product_cat=$matches[1]\";s:52:\"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:47:\"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:28:\"product-tag/([^/]+)/embed/?$\";s:44:\"index.php?product_tag=$matches[1]&embed=true\";s:40:\"product-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_tag=$matches[1]&paged=$matches[2]\";s:22:\"product-tag/([^/]+)/?$\";s:33:\"index.php?product_tag=$matches[1]\";s:35:\"product/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"product/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"product/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"product/([^/]+)/embed/?$\";s:40:\"index.php?product=$matches[1]&embed=true\";s:28:\"product/([^/]+)/trackback/?$\";s:34:\"index.php?product=$matches[1]&tb=1\";s:48:\"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:43:\"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:36:\"product/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&paged=$matches[2]\";s:43:\"product/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&cpage=$matches[2]\";s:33:\"product/([^/]+)/wc-api(/(.*))?/?$\";s:48:\"index.php?product=$matches[1]&wc-api=$matches[3]\";s:39:\"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:50:\"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:32:\"product/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?product=$matches[1]&page=$matches[2]\";s:24:\"product/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"product/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"product/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:13:\"favicon\\.ico$\";s:19:\"index.php?favicon=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:17:\"wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:26:\"comments/wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:29:\"search/(.+)/wc-api(/(.*))?/?$\";s:42:\"index.php?s=$matches[1]&wc-api=$matches[3]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:32:\"author/([^/]+)/wc-api(/(.*))?/?$\";s:52:\"index.php?author_name=$matches[1]&wc-api=$matches[3]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:54:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:82:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:41:\"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:66:\"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:28:\"([0-9]{4})/wc-api(/(.*))?/?$\";s:45:\"index.php?year=$matches[1]&wc-api=$matches[3]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:62:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/wc-api(/(.*))?/?$\";s:99:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&wc-api=$matches[6]\";s:62:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:73:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:25:\"(.?.+?)/wc-api(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&wc-api=$matches[3]\";s:28:\"(.?.+?)/order-pay(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&order-pay=$matches[3]\";s:33:\"(.?.+?)/order-received(/(.*))?/?$\";s:57:\"index.php?pagename=$matches[1]&order-received=$matches[3]\";s:25:\"(.?.+?)/orders(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&orders=$matches[3]\";s:29:\"(.?.+?)/view-order(/(.*))?/?$\";s:53:\"index.php?pagename=$matches[1]&view-order=$matches[3]\";s:28:\"(.?.+?)/downloads(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&downloads=$matches[3]\";s:31:\"(.?.+?)/edit-account(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-account=$matches[3]\";s:31:\"(.?.+?)/edit-address(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-address=$matches[3]\";s:34:\"(.?.+?)/payment-methods(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&payment-methods=$matches[3]\";s:32:\"(.?.+?)/lost-password(/(.*))?/?$\";s:56:\"index.php?pagename=$matches[1]&lost-password=$matches[3]\";s:34:\"(.?.+?)/customer-logout(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&customer-logout=$matches[3]\";s:37:\"(.?.+?)/add-payment-method(/(.*))?/?$\";s:61:\"index.php?pagename=$matches[1]&add-payment-method=$matches[3]\";s:40:\"(.?.+?)/delete-payment-method(/(.*))?/?$\";s:64:\"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]\";s:45:\"(.?.+?)/set-default-payment-method(/(.*))?/?$\";s:69:\"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]\";s:31:\".?.+?/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}","yes"),
("555","_site_transient_timeout_php_check_9dfe9c1407d8720f2aa82fbeb25ecdd3","1623144583","no"),
("556","_site_transient_php_check_9dfe9c1407d8720f2aa82fbeb25ecdd3","a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}","no"),
("557","_transient_timeout_wc_onboarding_product_data","1622626184","no"),
("558","_transient_wc_onboarding_product_data","a:6:{s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:18:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Tue, 01 Jun 2021 09:29:44 GMT\";s:12:\"content-type\";s:31:\"application/json; charset=UTF-8\";s:14:\"content-length\";s:5:\"11636\";s:12:\"x-robots-tag\";s:7:\"noindex\";s:4:\"link\";s:60:\"<https://woocommerce.com/wp-json/>; rel=\"https://api.w.org/\"\";s:22:\"x-content-type-options\";s:7:\"nosniff\";s:29:\"access-control-expose-headers\";s:33:\"X-WP-Total, X-WP-TotalPages, Link\";s:28:\"access-control-allow-headers\";s:73:\"Authorization, X-WP-Nonce, Content-Disposition, Content-MD5, Content-Type\";s:13:\"x-wccom-cache\";s:3:\"HIT\";s:13:\"cache-control\";s:10:\"max-age=60\";s:5:\"allow\";s:3:\"GET\";s:16:\"content-encoding\";s:4:\"gzip\";s:4:\"x-rq\";s:16:\"ams5 85 167 3131\";s:3:\"age\";s:2:\"27\";s:7:\"x-cache\";s:3:\"hit\";s:4:\"vary\";s:23:\"Accept-Encoding, Origin\";s:13:\"accept-ranges\";s:5:\"bytes\";}}s:4:\"body\";s:48310:\"{\"products\":[{\"title\":\"WooCommerce Google Analytics\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/GA-Dark.png\",\"excerpt\":\"Understand your customers and increase revenue with world\\u2019s leading analytics platform - integrated with WooCommerce for free.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-google-analytics\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"2d21f7de14dfb8e9885a4622be701ddf\",\"slug\":\"woocommerce-google-analytics-integration\",\"id\":1442927},{\"title\":\"WooCommerce Tax\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Tax-Dark.png\",\"excerpt\":\"Automatically calculate how much sales tax should be collected for WooCommerce orders - by city, country, or state - at checkout.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/tax\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"f31b3b9273cce188cc2b27f7849d02dd\",\"slug\":\"woocommerce-services\",\"id\":3220291},{\"title\":\"Stripe\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Stripe-Dark-1.png\",\"excerpt\":\"Accept all major debit and credit cards as well as local payment methods with Stripe.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/stripe\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"50bb7a985c691bb943a9da4d2c8b5efd\",\"slug\":\"woocommerce-gateway-stripe\",\"id\":18627},{\"title\":\"Jetpack\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Jetpack-Dark.png\",\"excerpt\":\"Power up and protect your store with Jetpack\\r\\n\\r\\nFor free security, insights and monitoring, connect to Jetpack. It\'s everything you need for a strong, secure start.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/jetpack\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"d5bfef9700b62b2b132c74c74c3193eb\",\"slug\":\"jetpack\",\"id\":2725249},{\"title\":\"Facebook for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Facebook-Dark.png\",\"excerpt\":\"Get the Official Facebook for WooCommerce plugin for three powerful ways to help grow your business.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/facebook\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"0ea4fe4c2d7ca6338f8a322fb3e4e187\",\"slug\":\"facebook-for-woocommerce\",\"id\":2127297},{\"title\":\"Amazon Pay\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Amazon-Pay-Dark.png\",\"excerpt\":\"Amazon Pay is embedded in your WooCommerce store. Transactions take place via\\u00a0Amazon widgets, so the buyer never leaves your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/pay-with-amazon\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"9865e043bbbe4f8c9735af31cb509b53\",\"slug\":\"woocommerce-gateway-amazon-payments-advanced\",\"id\":238816},{\"title\":\"Square for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Square-Dark.png\",\"excerpt\":\"Accepting payments is easy with Square. Clear rates, fast deposits (1-2 business days). Sell online and in person, and sync all payments, items and inventory.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/square\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"e907be8b86d7df0c8f8e0d0020b52638\",\"slug\":\"woocommerce-square\",\"id\":1770503},{\"title\":\"WooCommerce Shipping\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Ship-Dark-1.png\",\"excerpt\":\"Print USPS and DHL labels right from your WooCommerce dashboard and instantly save up to 90%. WooCommerce Shipping is free to use and saves you time and money.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"f31b3b9273cce188cc2b27f7849d02dd\",\"slug\":\"woocommerce-services\",\"id\":2165910},{\"title\":\"WooCommerce Payments\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Pay-Dark.png\",\"excerpt\":\"Securely accept payments, track cash flow, and manage recurring revenue from your dashboard \\u2014 all without setup costs or monthly fees.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"8c6319ca-8f41-4e69-be63-6b15ee37773b\",\"slug\":\"woocommerce-payments\",\"id\":5278104},{\"title\":\"Mailchimp for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/09\\/logo-mailchimp-dark-v2.png\",\"excerpt\":\"Increase traffic, drive repeat purchases, and personalize your marketing when you connect to Mailchimp.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/mailchimp-for-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"b4481616ebece8b1ff68fc59b90c1a91\",\"slug\":\"mailchimp-for-woocommerce\",\"id\":2545166},{\"title\":\"PayPal Checkout\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Paypal-Dark.png\",\"excerpt\":\"PayPal Checkout now with Smart Payment Buttons\\u2122, dynamically displays, PayPal, Venmo, PayPal Credit, or other local payment options in a single stack giving customers the choice to pay with their preferred option.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-paypal-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"69e6cba62ac4021df9e117cc3f716d07\",\"slug\":\"woocommerce-gateway-paypal-express-checkout\",\"id\":1597922},{\"title\":\"WooCommerce Subscriptions\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Subscriptions-Dark.png\",\"excerpt\":\"Let customers subscribe to your products or services and pay on a weekly, monthly or annual basis.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-subscriptions\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;199.00\",\"hash\":\"6115e6d7e297b623a169fdcf5728b224\",\"slug\":\"woocommerce-subscriptions\",\"id\":27147},{\"title\":\"ShipStation Integration\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Shipstation-Dark.png\",\"excerpt\":\"Fulfill all your Woo orders (and wherever else you sell) quickly and easily using ShipStation. Try it free for 30 days today!\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipstation-integration\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"9de8640767ba64237808ed7f245a49bb\",\"slug\":\"woocommerce-shipstation-integration\",\"id\":18734},{\"title\":\"Product Add-Ons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Product-Add-Ons-Dark.png\",\"excerpt\":\"Offer add-ons like gift wrapping, special messages or other special options for your products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"147d0077e591e16db9d0d67daeb8c484\",\"slug\":\"woocommerce-product-addons\",\"id\":18618},{\"title\":\"PayFast Payment Gateway\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Payfast-Dark-1.png\",\"excerpt\":\"Take payments on your WooCommerce store via PayFast (redirect method).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/payfast-payment-gateway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"557bf07293ad916f20c207c6c9cd15ff\",\"slug\":\"woocommerce-payfast-gateway\",\"id\":18596},{\"title\":\"Google Ads &amp; Marketing by Kliken\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2019\\/02\\/GA-for-Woo-Logo-374x192px-qu3duk.png\",\"excerpt\":\"Get in front of shoppers and drive traffic to your store so you can grow your business with Smart Shopping Campaigns and free listings.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/google-ads-and-marketing\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"bf66e173-a220-4da7-9512-b5728c20fc16\",\"slug\":\"kliken-marketing-for-google\",\"id\":3866145},{\"title\":\"USPS Shipping Method\",\"image\":\"\",\"excerpt\":\"Get shipping rates from the USPS API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/usps-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"83d1524e8f5f1913e58889f83d442c32\",\"slug\":\"woocommerce-shipping-usps\",\"id\":18657},{\"title\":\"UPS Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/UPS-Shipping-Method-Dark.png\",\"excerpt\":\"Get shipping rates from the UPS API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/ups-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8dae58502913bac0fbcdcaba515ea998\",\"slug\":\"woocommerce-shipping-ups\",\"id\":18665},{\"title\":\"Shipment Tracking\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Ship-Tracking-Dark-1.png\",\"excerpt\":\"Add shipment tracking information to your orders.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipment-tracking\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"1968e199038a8a001c9f9966fd06bf88\",\"slug\":\"woocommerce-shipment-tracking\",\"id\":18693},{\"title\":\"Braintree for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/02\\/braintree-black-copy.png\",\"excerpt\":\"Accept PayPal, credit cards and debit cards with a single payment gateway solution \\u2014 PayPal Powered by Braintree.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-paypal-powered-by-braintree\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"27f010c8e34ca65b205ddec88ad14536\",\"slug\":\"woocommerce-gateway-paypal-powered-by-braintree\",\"id\":1489837},{\"title\":\"Table Rate Shipping\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Product-Table-Rate-Shipping-Dark.png\",\"excerpt\":\"Advanced, flexible shipping. Define multiple shipping rates based on location, price, weight, shipping class or item count.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/table-rate-shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"3034ed8aff427b0f635fe4c86bbf008a\",\"slug\":\"woocommerce-table-rate-shipping\",\"id\":18718},{\"title\":\"Checkout Field Editor\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Checkout-Field-Editor-Dark.png\",\"excerpt\":\"Optimize your checkout process by adding, removing or editing fields to suit your needs.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-checkout-field-editor\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"2b8029f0d7cdd1118f4d843eb3ab43ff\",\"slug\":\"woocommerce-checkout-field-editor\",\"id\":184594},{\"title\":\"WooCommerce Memberships\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2015\\/06\\/Thumbnail-Memberships-updated.png\",\"excerpt\":\"Give members access to restricted content or products, for a fee or for free.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-memberships\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;199.00\",\"hash\":\"9288e7609ad0b487b81ef6232efa5cfc\",\"slug\":\"woocommerce-memberships\",\"id\":958589},{\"title\":\"WooCommerce Bookings\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Bookings-Dark.png\",\"excerpt\":\"Allow customers to book appointments, make reservations or rent equipment without leaving your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-bookings\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/themes.woocommerce.com\\/hotel\\/\",\"price\":\"&#36;249.00\",\"hash\":\"911c438934af094c2b38d5560b9f50f3\",\"slug\":\"WooCommerce Bookings\",\"id\":390890},{\"title\":\"Product Bundles\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-PB.png?v=1\",\"excerpt\":\"Offer personalized product bundles, bulk discount packages, and assembled\\u00a0products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-bundles\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"aa2518b5-ab19-4b75-bde9-60ca51e20f28\",\"slug\":\"woocommerce-product-bundles\",\"id\":18716},{\"title\":\"Multichannel for WooCommerce: Google, Amazon, eBay &amp; Walmart Integration\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2018\\/10\\/Woo-Extension-Store-Logo-v2.png\",\"excerpt\":\"Get the official Google, Amazon, eBay and Walmart extension and create, sync and manage multichannel listings directly from WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/amazon-ebay-integration\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"e4000666-9275-4c71-8619-be61fb41c9f9\",\"slug\":\"woocommerce-amazon-ebay-integration\",\"id\":3545890},{\"title\":\"Min\\/Max Quantities\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Min-Max-Qua-Dark.png\",\"excerpt\":\"Specify minimum and maximum allowed product quantities for orders to be completed.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/minmax-quantities\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"2b5188d90baecfb781a5aa2d6abb900a\",\"slug\":\"woocommerce-min-max-quantities\",\"id\":18616},{\"title\":\"FedEx Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/01\\/FedEx_Logo_Wallpaper.jpeg\",\"excerpt\":\"Get shipping rates from the FedEx API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/fedex-shipping-module\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1a48b598b47a81559baadef15e320f64\",\"slug\":\"woocommerce-shipping-fedex\",\"id\":18620},{\"title\":\"LiveChat for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2015\\/11\\/LC_woo_regular-zmiaym.png\",\"excerpt\":\"Live Chat and messaging platform for sales and support -- increase average order value and overall sales through live conversations.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/livechat\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.livechat.com\\/livechat-for-ecommerce\\/?a=woocommerce&amp;utm_source=woocommerce.com&amp;utm_medium=integration&amp;utm_campaign=woocommerce.com\",\"price\":\"&#36;0.00\",\"hash\":\"5344cc1f-ed4a-4d00-beff-9d67f6d372f3\",\"slug\":\"livechat-woocommerce\",\"id\":1348888},{\"title\":\"Authorize.Net\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2013\\/04\\/Thumbnail-Authorize.net-updated.png\",\"excerpt\":\"Authorize.Net gateway with support for pre-orders and subscriptions.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/authorize-net\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8b61524fe53add7fdd1a8d1b00b9327d\",\"slug\":\"woocommerce-gateway-authorize-net-cim\",\"id\":178481},{\"title\":\"Product CSV Import Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Product-CSV-Import-Dark.png\",\"excerpt\":\"Import, merge, and export products and variations to and from WooCommerce using a CSV file.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-csv-import-suite\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"7ac9b00a1fe980fb61d28ab54d167d0d\",\"slug\":\"woocommerce-product-csv-import-suite\",\"id\":18680},{\"title\":\"Follow-Ups\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Follow-Ups-Dark.png\",\"excerpt\":\"Automatically contact customers after purchase - be it everyone, your most loyal or your biggest spenders - and keep your store top-of-mind.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/follow-up-emails\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"05ece68fe94558e65278fe54d9ec84d2\",\"slug\":\"woocommerce-follow-up-emails\",\"id\":18686},{\"title\":\"WooCommerce Customer \\/ Order \\/ Coupon Export\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/02\\/Thumbnail-Customer-Order-Coupon-Export-updated.png\",\"excerpt\":\"Export customers, orders, and coupons from WooCommerce manually or on an automated schedule.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/ordercustomer-csv-export\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"914de15813a903c767b55445608bf290\",\"slug\":\"woocommerce-customer-order-csv-export\",\"id\":18652},{\"title\":\"Australia Post Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/australia-post.gif\",\"excerpt\":\"Get shipping rates for your WooCommerce store from the Australia Post API, which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/australia-post-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1dbd4dc6bd91a9cda1bd6b9e7a5e4f43\",\"slug\":\"woocommerce-shipping-australia-post\",\"id\":18622},{\"title\":\"Canada Post Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/canada-post.png\",\"excerpt\":\"Get shipping rates from the Canada Post Ratings API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/canada-post-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"ac029cdf3daba20b20c7b9be7dc00e0e\",\"slug\":\"woocommerce-shipping-canada-post\",\"id\":18623},{\"title\":\"Product Vendors\",\"image\":\"\",\"excerpt\":\"Turn your store into a multi-vendor marketplace\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-vendors\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"a97d99fccd651bbdd728f4d67d492c31\",\"slug\":\"woocommerce-product-vendors\",\"id\":219982},{\"title\":\"WooCommerce Accommodation Bookings\",\"image\":\"\",\"excerpt\":\"Book accommodation using WooCommerce and the WooCommerce Bookings extension.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-accommodation-bookings\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"99b2a7a4af90b6cefd2a733b3b1f78e7\",\"slug\":\"woocommerce-accommodation-bookings\",\"id\":1412069},{\"title\":\"Smart Coupons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/10\\/wc-product-smart-coupons.png\",\"excerpt\":\"Everything you need for discounts, coupons, credits, gift cards, product giveaways, offers, and promotions. Most popular and complete coupons plugin for WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/smart-coupons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/demo.storeapps.org\\/?demo=sc\",\"price\":\"&#36;99.00\",\"hash\":\"05c45f2aa466106a466de4402fff9dde\",\"slug\":\"woocommerce-smart-coupons\",\"id\":18729},{\"title\":\"WooCommerce Brands\",\"image\":\"\",\"excerpt\":\"Create, assign and list brands for products, and allow customers to view by brand.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/brands\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"8a88c7cbd2f1e73636c331c7a86f818c\",\"slug\":\"woocommerce-brands\",\"id\":18737},{\"title\":\"Xero\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/08\\/xero2.png\",\"excerpt\":\"Save time with automated sync between WooCommerce and your Xero account.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/xero\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"f0dd29d338d3c67cf6cee88eddf6869b\",\"slug\":\"woocommerce-xero\",\"id\":18733},{\"title\":\"Royal Mail\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/04\\/royalmail.png\",\"excerpt\":\"Offer Royal Mail shipping rates to your customers\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/royal-mail\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"03839cca1a16c4488fcb669aeb91a056\",\"slug\":\"woocommerce-shipping-royalmail\",\"id\":182719},{\"title\":\"AutomateWoo\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-AutomateWoo-Dark-1.png\",\"excerpt\":\"Powerful marketing automation for WooCommerce. AutomateWoo has the tools you need to grow your store and make more money.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/automatewoo\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"ba9299b8-1dba-4aa0-a313-28bc1755cb88\",\"slug\":\"automatewoo\",\"id\":4652610},{\"title\":\"WooCommerce Zapier\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/woocommerce-zapier-logo.png\",\"excerpt\":\"Integrate with 3000+ cloud apps and services today.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-zapier\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;59.00\",\"hash\":\"0782bdbe932c00f4978850268c6cfe40\",\"slug\":\"woocommerce-zapier\",\"id\":243589},{\"title\":\"Advanced Notifications\",\"image\":\"\",\"excerpt\":\"Easily setup \\\"new order\\\" and stock email notifications for multiple recipients of your choosing.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/advanced-notifications\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"112372c44b002fea2640bd6bfafbca27\",\"slug\":\"woocommerce-advanced-notifications\",\"id\":18740},{\"title\":\"Dynamic Pricing\",\"image\":\"\",\"excerpt\":\"Bulk discounts, role-based pricing and much more\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/dynamic-pricing\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"9a41775bb33843f52c93c922b0053986\",\"slug\":\"woocommerce-dynamic-pricing\",\"id\":18643},{\"title\":\"WooCommerce Points and Rewards\",\"image\":\"\",\"excerpt\":\"Reward your customers for purchases and other actions with points which can be redeemed for discounts.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-points-and-rewards\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"1649b6cca5da8b923b01ca56b5cdd246\",\"slug\":\"woocommerce-points-and-rewards\",\"id\":210259},{\"title\":\"Name Your Price\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/09\\/nyp-icon-dark-v83owf.png\",\"excerpt\":\"Allow customers to define the product price. Also useful for accepting user-set donations.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/name-your-price\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"31b4e11696cd99a3c0572975a84f1c08\",\"slug\":\"woocommerce-name-your-price\",\"id\":18738},{\"title\":\"WooCommerce Print Invoices &amp; Packing lists\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/03\\/Thumbnail-Print-Invoices-Packing-lists-updated.png\",\"excerpt\":\"Generate invoices, packing slips, and pick lists for your WooCommerce orders.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/print-invoices-packing-lists\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"465de1126817cdfb42d97ebca7eea717\",\"slug\":\"woocommerce-pip\",\"id\":18666},{\"title\":\"WooCommerce Pre-Orders\",\"image\":\"\",\"excerpt\":\"Allow customers to order products before they are available.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-pre-orders\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"b2dc75e7d55e6f5bbfaccb59830f66b7\",\"slug\":\"woocommerce-pre-orders\",\"id\":178477},{\"title\":\"WooCommerce Subscription Downloads\",\"image\":\"\",\"excerpt\":\"Offer additional downloads to your subscribers, via downloadable products listed in your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-subscription-downloads\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"5be9e21c13953253e4406d2a700382ec\",\"slug\":\"woocommerce-subscription-downloads\",\"id\":420458},{\"title\":\"WooCommerce Additional Variation Images\",\"image\":\"\",\"excerpt\":\"Add gallery images per variation on variable products within WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-additional-variation-images\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/themes.woocommerce.com\\/storefront\\/product\\/woo-single-1\\/\",\"price\":\"&#36;49.00\",\"hash\":\"c61dd6de57dcecb32bd7358866de4539\",\"slug\":\"woocommerce-additional-variation-images\",\"id\":477384},{\"title\":\"WooCommerce Deposits\",\"image\":\"\",\"excerpt\":\"Enable customers to pay for products using a deposit or a payment plan.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-deposits\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;179.00\",\"hash\":\"de192a6cf12c4fd803248da5db700762\",\"slug\":\"woocommerce-deposits\",\"id\":977087},{\"title\":\"Google Product Feed\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2011\\/11\\/logo-regular-lscryp.png\",\"excerpt\":\"Feed product data to Google Merchant Center for setting up Google product listings &amp; product ads.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/google-product-feed\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"d55b4f852872025741312839f142447e\",\"slug\":\"woocommerce-product-feeds\",\"id\":18619},{\"title\":\"Amazon S3 Storage\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/amazon.png\",\"excerpt\":\"Serve digital products via Amazon S3\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/amazon-s3-storage\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"473bf6f221b865eff165c97881b473bb\",\"slug\":\"woocommerce-amazon-s3-storage\",\"id\":18663},{\"title\":\"Cart Add-ons\",\"image\":\"\",\"excerpt\":\"A powerful tool for driving incremental and impulse purchases by customers once they are in the shopping cart\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/cart-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"3a8ef25334396206f5da4cf208adeda3\",\"slug\":\"woocommerce-cart-add-ons\",\"id\":18717},{\"title\":\"Shipping Multiple Addresses\",\"image\":\"\",\"excerpt\":\"Allow your customers to ship individual items in a single order to multiple addresses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipping-multiple-addresses\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"aa0eb6f777846d329952d5b891d6f8cc\",\"slug\":\"woocommerce-shipping-multiple-addresses\",\"id\":18741},{\"title\":\"WooCommerce AvaTax\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/01\\/Thumbnail-Avalara-updated.png\",\"excerpt\":\"Get 100% accurate sales tax calculations and on time tax return filing. No more tracking sales tax rates, rules, or jurisdictional boundaries.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-avatax\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"57077a4b28ba71cacf692bcf4a1a7f60\",\"slug\":\"woocommerce-avatax\",\"id\":1389326},{\"title\":\"PayPal Payments Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Paypal-Payments-Pro-Dark.png\",\"excerpt\":\"Take credit card payments directly on your checkout using PayPal Pro.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/paypal-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6d23ba7f0e0198937c0029f9e865b40e\",\"slug\":\"woocommerce-gateway-paypal-pro\",\"id\":18594},{\"title\":\"Klarna Checkout\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2018\\/01\\/Partner_marketing_Klarna_Checkout_Black-1.png\",\"excerpt\":\"Klarna Checkout is a full checkout experience embedded on your site that includes all popular payment methods (Pay Now, Pay Later, Financing, Installments).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/klarna-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/demo.krokedil.se\\/klarnacheckout\\/\",\"price\":\"&#36;0.00\",\"hash\":\"90f8ce584e785fcd8c2d739fd4f40d78\",\"slug\":\"klarna-checkout-for-woocommerce\",\"id\":2754152},{\"title\":\"Gravity Forms Product Add-ons\",\"image\":\"\",\"excerpt\":\"Powerful product add-ons, Gravity style\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/gravity-forms-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/gravity-forms\\/\",\"price\":\"&#36;99.00\",\"hash\":\"a6ac0ab1a1536e3a357ccf24c0650ed0\",\"slug\":\"woocommerce-gravityforms-product-addons\",\"id\":18633},{\"title\":\"Bulk Stock Management\",\"image\":\"\",\"excerpt\":\"Edit product and variation stock levels in bulk via this handy interface\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/bulk-stock-management\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"02f4328d52f324ebe06a78eaaae7934f\",\"slug\":\"woocommerce-bulk-stock-management\",\"id\":18670},{\"title\":\"Composite Products\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-CP.png?v=1\",\"excerpt\":\"Create product kit builders and custom product configurators using existing products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/composite-products\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"0343e0115bbcb97ccd98442b8326a0af\",\"slug\":\"woocommerce-composite-products\",\"id\":216836},{\"title\":\"WooCommerce Email Customizer\",\"image\":\"\",\"excerpt\":\"Connect with your customers with each email you send by visually modifying your email templates via the WordPress Customizer.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-email-customizer\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"bd909fa97874d431f203b5336c7e8873\",\"slug\":\"woocommerce-email-customizer\",\"id\":853277},{\"title\":\"TaxJar\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/10\\/taxjar-logotype.png\",\"excerpt\":\"Save hours every month by putting your sales tax on autopilot. Automated, multi-state sales tax calculation, reporting, and filing for your WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/taxjar\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"12072d8e-e933-4561-97b1-9db3c7eeed91\",\"slug\":\"taxjar-simplified-taxes-for-woocommerce\",\"id\":514914},{\"title\":\"Force Sells\",\"image\":\"\",\"excerpt\":\"Force products to be added to the cart\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/force-sells\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"3ebddfc491ca168a4ea4800b893302b0\",\"slug\":\"woocommerce-force-sells\",\"id\":18678},{\"title\":\"WooCommerce Quick View\",\"image\":\"\",\"excerpt\":\"Show a quick-view button to view product details and add to cart via lightbox popup\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-quick-view\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"619c6e57ce72c49c4b57e15b06eddb65\",\"slug\":\"woocommerce-quick-view\",\"id\":187509},{\"title\":\"WooCommerce Purchase Order Gateway\",\"image\":\"\",\"excerpt\":\"Receive purchase orders via your WooCommerce-powered online store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-purchase-order\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"573a92318244ece5facb449d63e74874\",\"slug\":\"woocommerce-gateway-purchase-order\",\"id\":478542},{\"title\":\"Returns and Warranty Requests\",\"image\":\"\",\"excerpt\":\"Manage the RMA process, add warranties to products &amp; let customers request &amp; manage returns \\/ exchanges from their account.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/warranty-requests\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"9b4c41102e6b61ea5f558e16f9b63e25\",\"slug\":\"woocommerce-warranty\",\"id\":228315},{\"title\":\"Product Enquiry Form\",\"image\":\"\",\"excerpt\":\"Allow visitors to contact you directly from the product details page via a reCAPTCHA protected form to enquire about a product.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-enquiry-form\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"5a0f5d72519a8ffcc86669f042296937\",\"slug\":\"woocommerce-product-enquiry-form\",\"id\":18601},{\"title\":\"WooCommerce Box Office\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-BO-Dark.png\",\"excerpt\":\"Sell tickets for your next event, concert, function, fundraiser or conference directly on your own site\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-box-office\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"e704c9160de318216a8fa657404b9131\",\"slug\":\"woocommerce-box-office\",\"id\":1628717},{\"title\":\"WooCommerce Order Barcodes\",\"image\":\"\",\"excerpt\":\"Generates a unique barcode for each order on your site - perfect for e-tickets, packing slips, reservations and a variety of other uses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-barcodes\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"889835bb29ee3400923653e1e44a3779\",\"slug\":\"woocommerce-order-barcodes\",\"id\":391708},{\"title\":\"WooCommerce Paid Courses\",\"image\":\"\",\"excerpt\":\"Sell your online courses using the most popular eCommerce platform on the web \\u2013 WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-paid-courses\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"bad2a02a063555b7e2bee59924690763\",\"slug\":\"woothemes-sensei\",\"id\":152116},{\"title\":\"WooCommerce 360\\u00ba Image\",\"image\":\"\",\"excerpt\":\"An easy way to add a dynamic, controllable 360\\u00ba image rotation to your WooCommerce site, by adding a group of images to a product\\u2019s gallery.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-360-image\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"24eb2cfa3738a66bf3b2587876668cd2\",\"slug\":\"woocommerce-360-image\",\"id\":512186},{\"title\":\"WooCommerce Photography\",\"image\":\"\",\"excerpt\":\"Sell photos in the blink of an eye using this simple as dragging &amp; dropping interface.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-photography\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"ee76e8b9daf1d97ca4d3874cc9e35687\",\"slug\":\"woocommerce-photography\",\"id\":583602},{\"title\":\"WooCommerce Bookings Availability\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Bookings-Aval-Dark.png\",\"excerpt\":\"Sell more bookings by presenting a calendar or schedule of available slots in a page or post.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/bookings-availability\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"30770d2a-e392-4e82-baaa-76cfc7d02ae3\",\"slug\":\"woocommerce-bookings-availability\",\"id\":4228225},{\"title\":\"Software Add-on\",\"image\":\"\",\"excerpt\":\"Sell License Keys for Software\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/software-add-on\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"79f6dbfe1f1d3a56a86f0509b6d6b04b\",\"slug\":\"woocommerce-software-add-on\",\"id\":18683},{\"title\":\"WooCommerce Products Compare\",\"image\":\"\",\"excerpt\":\"WooCommerce Products Compare will allow your potential customers to easily compare products within your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-products-compare\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"c3ba0a4a3199a0cc7a6112eb24414548\",\"slug\":\"woocommerce-products-compare\",\"id\":853117},{\"title\":\"WooCommerce Store Catalog PDF Download\",\"image\":\"\",\"excerpt\":\"Offer your customers a PDF download of your product catalog, generated by WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-store-catalog-pdf-download\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"79ca7aadafe706364e2d738b7c1090c4\",\"slug\":\"woocommerce-store-catalog-pdf-download\",\"id\":675790},{\"title\":\"eWAY\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2011\\/10\\/eway-logo-3000-2000.jpg\",\"excerpt\":\"Take credit card payments securely via eWay (SG, MY, HK, AU, and NZ) keeping customers on your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/eway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"2c497769d98d025e0d340cd0b5ea5da1\",\"slug\":\"woocommerce-gateway-eway\",\"id\":18604},{\"title\":\"Catalog Visibility Options\",\"image\":\"\",\"excerpt\":\"Transform WooCommerce into an online catalog by removing eCommerce functionality\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/catalog-visibility-options\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"12e791110365fdbb5865c8658907967e\",\"slug\":\"woocommerce-catalog-visibility-options\",\"id\":18648},{\"title\":\"WooCommerce Blocks\",\"image\":\"\",\"excerpt\":\"WooCommerce Blocks offers a range of Gutenberg blocks you can use to build and customise your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gutenberg-products-block\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"c2e9f13a-f90c-4ffe-a8a5-b432399ec263\",\"slug\":\"woo-gutenberg-products-block\",\"id\":3076677},{\"title\":\"Sequential Order Numbers Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/05\\/Thumbnail-Sequential-Order-Numbers-Pro-updated.png\",\"excerpt\":\"Tame your order numbers! Advanced &amp; sequential order numbers with optional prefixes \\/ suffixes\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/sequential-order-numbers-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"0b18a2816e016ba9988b93b1cd8fe766\",\"slug\":\"woocommerce-sequential-order-numbers-pro\",\"id\":18688},{\"title\":\"Conditional Shipping and Payments\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-CSP.png?v=1\",\"excerpt\":\"Use conditional logic to restrict the shipping and payment options available on your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/conditional-shipping-and-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1f56ff002fa830b77017b0107505211a\",\"slug\":\"woocommerce-conditional-shipping-and-payments\",\"id\":680253},{\"title\":\"WooCommerce Order Status Manager\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2015\\/02\\/Thumbnail-Order-Status-Manager-updated.png\",\"excerpt\":\"Create, edit, and delete completely custom order statuses and integrate them seamlessly into your order management flow.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-status-manager\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"51fd9ab45394b4cad5a0ebf58d012342\",\"slug\":\"woocommerce-order-status-manager\",\"id\":588398},{\"title\":\"WooCommerce Checkout Add-Ons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/07\\/Thumbnail-Checkout-Add-Ons-updated.png\",\"excerpt\":\"Highlight relevant products, offers like free shipping and other up-sells during checkout.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-checkout-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8fdca00b4000b7a8cc26371d0e470a8f\",\"slug\":\"woocommerce-checkout-add-ons\",\"id\":466854},{\"title\":\"WooCommerce Google Analytics Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/01\\/Thumbnail-GAPro-updated.png\",\"excerpt\":\"Add advanced event tracking and enhanced eCommerce tracking to your WooCommerce site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-google-analytics-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"d8aed8b7306b509eec1589e59abe319f\",\"slug\":\"woocommerce-google-analytics-pro\",\"id\":1312497},{\"title\":\"QuickBooks Sync for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2019\\/04\\/woocommerce-com-logo-1-hyhzbh.png\",\"excerpt\":\"Automatic two-way sync for orders, customers, products, inventory and more between WooCommerce and QuickBooks (Online, Desktop, or POS).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/quickbooks-sync-for-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"c5e32e20-7c1f-4585-8b15-d930c2d842ac\",\"slug\":\"myworks-woo-sync-for-quickbooks-online\",\"id\":4065824},{\"title\":\"WooCommerce One Page Checkout\",\"image\":\"\",\"excerpt\":\"Create special pages where customers can choose products, checkout &amp; pay all on the one page.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-one-page-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"c9ba8f8352cd71b5508af5161268619a\",\"slug\":\"woocommerce-one-page-checkout\",\"id\":527886},{\"title\":\"WooCommerce Product Search\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2014\\/10\\/woocommerce-product-search-product-image-1870x960-1-jvsljj.png\",\"excerpt\":\"The perfect search engine helps customers to find and buy products quickly \\u2013 essential for every WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-product-search\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/demo.itthinx.com\\/wps\\/\",\"price\":\"&#36;49.00\",\"hash\":\"c84cc8ca16ddac3408e6b6c5871133a8\",\"slug\":\"woocommerce-product-search\",\"id\":512174},{\"title\":\"First Data\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/02\\/Thumbnail-FirstData-updated.png\",\"excerpt\":\"FirstData gateway for WooCommerce\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/firstdata\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"eb3e32663ec0810592eaf0d097796230\",\"slug\":\"woocommerce-gateway-firstdata\",\"id\":18645},{\"title\":\"WooSlider\",\"image\":\"\",\"excerpt\":\"WooSlider is the ultimate responsive slideshow WordPress slider plugin\\r\\n\\r\\n\\u00a0\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/wooslider\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/www.wooslider.com\\/\",\"price\":\"&#36;49.00\",\"hash\":\"209d98f3ccde6cc3de7e8732a2b20b6a\",\"slug\":\"wooslider\",\"id\":46506},{\"title\":\"WooCommerce Social Login\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/08\\/Thumbnail-Social-Login-updated.png\",\"excerpt\":\"Enable Social Login for seamless checkout and account creation.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-social-login\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/demos.skyverge.com\\/woocommerce-social-login\\/\",\"price\":\"&#36;79.00\",\"hash\":\"b231cd6367a79cc8a53b7d992d77525d\",\"slug\":\"woocommerce-social-login\",\"id\":473617},{\"title\":\"Coupon Shortcodes\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/09\\/woocommerce-coupon-shortcodes-product-image-1870x960-1-vc5gux.png\",\"excerpt\":\"Show coupon discount info using shortcodes. Allows to render coupon information and content conditionally, based on the validity of coupons.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/coupon-shortcodes\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"ac5d9d51-70b2-4d8f-8b89-24200eea1394\",\"slug\":\"woocommerce-coupon-shortcodes\",\"id\":244762},{\"title\":\"WooCommerce Order Status Control\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/06\\/Thumbnail-Order-Status-Control-updated.png\",\"excerpt\":\"Use this extension to automatically change the order status to \\\"completed\\\" after successful payment.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-status-control\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"32400e509c7c36dcc1cd368e8267d981\",\"slug\":\"woocommerce-order-status-control\",\"id\":439037},{\"title\":\"Variation Swatches and Photos\",\"image\":\"\",\"excerpt\":\"Show color and image swatches instead of dropdowns for variable products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/variation-swatches-and-photos\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/swatches-and-photos\\/\",\"price\":\"&#36;99.00\",\"hash\":\"37bea8d549df279c8278878d081b062f\",\"slug\":\"woocommerce-variation-swatches-and-photos\",\"id\":18697},{\"title\":\"Jilt\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2017\\/12\\/Thumbnail-Jilt-updated.png\",\"excerpt\":\"All-in-one email marketing platform built for WooCommerce stores. Send newsletters, abandoned cart reminders, win-backs, welcome automations, and more.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/jilt\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"b53aafb64dca33835e41ee06de7e9816\",\"slug\":\"jilt-for-woocommerce\",\"id\":2754876},{\"title\":\"Opayo Payment Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2011\\/10\\/Opayo_logo_RGB.png\",\"excerpt\":\"Take payments on your WooCommerce store via Opayo (formally SagePay).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/sage-pay-form\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6bc0cca47d0274d8ef9b164f6fbec1cc\",\"slug\":\"woocommerce-gateway-sagepay-form\",\"id\":18599},{\"title\":\"EU VAT Number\",\"image\":\"\",\"excerpt\":\"Collect VAT numbers at checkout and remove the VAT charge for eligible EU businesses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/eu-vat-number\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"d2720c4b4bb8d6908e530355b7a2d734\",\"slug\":\"woocommerce-eu-vat-number\",\"id\":18592},{\"title\":\"PayPal\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2020\\/10\\/PPCP-Tile-PayPal-Logo-and-Cart-Art-2x-2-uozwz8.jpg\",\"excerpt\":\"PayPal\\u2019s latest, most complete payment processing solution. Accept PayPal exclusives, credit\\/debit cards and local payment methods. Turn on only PayPal options or process a full suite of payment methods. Enable global transactions with extensive currency and country coverage. Built and supported by WooCommerce and PayPal.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-paypal-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"934115ab-e3f3-4435-9580-345b1ce21899\",\"slug\":\"woocommerce-paypal-payments\",\"id\":6410731},{\"title\":\"QuickBooks Commerce (formerly TradeGecko)\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2013\\/09\\/qbo-mark.png\",\"excerpt\":\"Get a wholesale and multichannel inventory &amp; order management platform for your WooCommerce store with QuickBooks Commerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-tradegecko\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"21da7811f7fc1f13ee19daa7415f0ff3\",\"slug\":\"woocommerce-tradegecko\",\"id\":245960}]}\";s:8:\"response\";a:2:{s:4:\"code\";i:200;s:7:\"message\";s:2:\"OK\";}s:7:\"cookies\";a:0:{}s:8:\"filename\";N;s:13:\"http_response\";O:25:\"WP_HTTP_Requests_Response\":5:{s:11:\"\0*\0response\";O:17:\"Requests_Response\":10:{s:4:\"body\";s:48310:\"{\"products\":[{\"title\":\"WooCommerce Google Analytics\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/GA-Dark.png\",\"excerpt\":\"Understand your customers and increase revenue with world\\u2019s leading analytics platform - integrated with WooCommerce for free.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-google-analytics\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"2d21f7de14dfb8e9885a4622be701ddf\",\"slug\":\"woocommerce-google-analytics-integration\",\"id\":1442927},{\"title\":\"WooCommerce Tax\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Tax-Dark.png\",\"excerpt\":\"Automatically calculate how much sales tax should be collected for WooCommerce orders - by city, country, or state - at checkout.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/tax\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"f31b3b9273cce188cc2b27f7849d02dd\",\"slug\":\"woocommerce-services\",\"id\":3220291},{\"title\":\"Stripe\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Stripe-Dark-1.png\",\"excerpt\":\"Accept all major debit and credit cards as well as local payment methods with Stripe.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/stripe\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"50bb7a985c691bb943a9da4d2c8b5efd\",\"slug\":\"woocommerce-gateway-stripe\",\"id\":18627},{\"title\":\"Jetpack\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Jetpack-Dark.png\",\"excerpt\":\"Power up and protect your store with Jetpack\\r\\n\\r\\nFor free security, insights and monitoring, connect to Jetpack. It\'s everything you need for a strong, secure start.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/jetpack\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"d5bfef9700b62b2b132c74c74c3193eb\",\"slug\":\"jetpack\",\"id\":2725249},{\"title\":\"Facebook for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Facebook-Dark.png\",\"excerpt\":\"Get the Official Facebook for WooCommerce plugin for three powerful ways to help grow your business.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/facebook\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"0ea4fe4c2d7ca6338f8a322fb3e4e187\",\"slug\":\"facebook-for-woocommerce\",\"id\":2127297},{\"title\":\"Amazon Pay\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Amazon-Pay-Dark.png\",\"excerpt\":\"Amazon Pay is embedded in your WooCommerce store. Transactions take place via\\u00a0Amazon widgets, so the buyer never leaves your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/pay-with-amazon\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"9865e043bbbe4f8c9735af31cb509b53\",\"slug\":\"woocommerce-gateway-amazon-payments-advanced\",\"id\":238816},{\"title\":\"Square for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Square-Dark.png\",\"excerpt\":\"Accepting payments is easy with Square. Clear rates, fast deposits (1-2 business days). Sell online and in person, and sync all payments, items and inventory.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/square\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"e907be8b86d7df0c8f8e0d0020b52638\",\"slug\":\"woocommerce-square\",\"id\":1770503},{\"title\":\"WooCommerce Shipping\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Ship-Dark-1.png\",\"excerpt\":\"Print USPS and DHL labels right from your WooCommerce dashboard and instantly save up to 90%. WooCommerce Shipping is free to use and saves you time and money.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"f31b3b9273cce188cc2b27f7849d02dd\",\"slug\":\"woocommerce-services\",\"id\":2165910},{\"title\":\"WooCommerce Payments\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Pay-Dark.png\",\"excerpt\":\"Securely accept payments, track cash flow, and manage recurring revenue from your dashboard \\u2014 all without setup costs or monthly fees.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"8c6319ca-8f41-4e69-be63-6b15ee37773b\",\"slug\":\"woocommerce-payments\",\"id\":5278104},{\"title\":\"Mailchimp for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/09\\/logo-mailchimp-dark-v2.png\",\"excerpt\":\"Increase traffic, drive repeat purchases, and personalize your marketing when you connect to Mailchimp.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/mailchimp-for-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"b4481616ebece8b1ff68fc59b90c1a91\",\"slug\":\"mailchimp-for-woocommerce\",\"id\":2545166},{\"title\":\"PayPal Checkout\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Paypal-Dark.png\",\"excerpt\":\"PayPal Checkout now with Smart Payment Buttons\\u2122, dynamically displays, PayPal, Venmo, PayPal Credit, or other local payment options in a single stack giving customers the choice to pay with their preferred option.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-paypal-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"69e6cba62ac4021df9e117cc3f716d07\",\"slug\":\"woocommerce-gateway-paypal-express-checkout\",\"id\":1597922},{\"title\":\"WooCommerce Subscriptions\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Subscriptions-Dark.png\",\"excerpt\":\"Let customers subscribe to your products or services and pay on a weekly, monthly or annual basis.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-subscriptions\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;199.00\",\"hash\":\"6115e6d7e297b623a169fdcf5728b224\",\"slug\":\"woocommerce-subscriptions\",\"id\":27147},{\"title\":\"ShipStation Integration\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Shipstation-Dark.png\",\"excerpt\":\"Fulfill all your Woo orders (and wherever else you sell) quickly and easily using ShipStation. Try it free for 30 days today!\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipstation-integration\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"9de8640767ba64237808ed7f245a49bb\",\"slug\":\"woocommerce-shipstation-integration\",\"id\":18734},{\"title\":\"Product Add-Ons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Product-Add-Ons-Dark.png\",\"excerpt\":\"Offer add-ons like gift wrapping, special messages or other special options for your products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"147d0077e591e16db9d0d67daeb8c484\",\"slug\":\"woocommerce-product-addons\",\"id\":18618},{\"title\":\"PayFast Payment Gateway\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Payfast-Dark-1.png\",\"excerpt\":\"Take payments on your WooCommerce store via PayFast (redirect method).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/payfast-payment-gateway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"557bf07293ad916f20c207c6c9cd15ff\",\"slug\":\"woocommerce-payfast-gateway\",\"id\":18596},{\"title\":\"Google Ads &amp; Marketing by Kliken\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2019\\/02\\/GA-for-Woo-Logo-374x192px-qu3duk.png\",\"excerpt\":\"Get in front of shoppers and drive traffic to your store so you can grow your business with Smart Shopping Campaigns and free listings.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/google-ads-and-marketing\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"bf66e173-a220-4da7-9512-b5728c20fc16\",\"slug\":\"kliken-marketing-for-google\",\"id\":3866145},{\"title\":\"USPS Shipping Method\",\"image\":\"\",\"excerpt\":\"Get shipping rates from the USPS API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/usps-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"83d1524e8f5f1913e58889f83d442c32\",\"slug\":\"woocommerce-shipping-usps\",\"id\":18657},{\"title\":\"UPS Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/UPS-Shipping-Method-Dark.png\",\"excerpt\":\"Get shipping rates from the UPS API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/ups-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8dae58502913bac0fbcdcaba515ea998\",\"slug\":\"woocommerce-shipping-ups\",\"id\":18665},{\"title\":\"Shipment Tracking\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Ship-Tracking-Dark-1.png\",\"excerpt\":\"Add shipment tracking information to your orders.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipment-tracking\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"1968e199038a8a001c9f9966fd06bf88\",\"slug\":\"woocommerce-shipment-tracking\",\"id\":18693},{\"title\":\"Braintree for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/02\\/braintree-black-copy.png\",\"excerpt\":\"Accept PayPal, credit cards and debit cards with a single payment gateway solution \\u2014 PayPal Powered by Braintree.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-paypal-powered-by-braintree\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"27f010c8e34ca65b205ddec88ad14536\",\"slug\":\"woocommerce-gateway-paypal-powered-by-braintree\",\"id\":1489837},{\"title\":\"Table Rate Shipping\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Product-Table-Rate-Shipping-Dark.png\",\"excerpt\":\"Advanced, flexible shipping. Define multiple shipping rates based on location, price, weight, shipping class or item count.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/table-rate-shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"3034ed8aff427b0f635fe4c86bbf008a\",\"slug\":\"woocommerce-table-rate-shipping\",\"id\":18718},{\"title\":\"Checkout Field Editor\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Checkout-Field-Editor-Dark.png\",\"excerpt\":\"Optimize your checkout process by adding, removing or editing fields to suit your needs.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-checkout-field-editor\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"2b8029f0d7cdd1118f4d843eb3ab43ff\",\"slug\":\"woocommerce-checkout-field-editor\",\"id\":184594},{\"title\":\"WooCommerce Memberships\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2015\\/06\\/Thumbnail-Memberships-updated.png\",\"excerpt\":\"Give members access to restricted content or products, for a fee or for free.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-memberships\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;199.00\",\"hash\":\"9288e7609ad0b487b81ef6232efa5cfc\",\"slug\":\"woocommerce-memberships\",\"id\":958589},{\"title\":\"WooCommerce Bookings\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Bookings-Dark.png\",\"excerpt\":\"Allow customers to book appointments, make reservations or rent equipment without leaving your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-bookings\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/themes.woocommerce.com\\/hotel\\/\",\"price\":\"&#36;249.00\",\"hash\":\"911c438934af094c2b38d5560b9f50f3\",\"slug\":\"WooCommerce Bookings\",\"id\":390890},{\"title\":\"Product Bundles\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-PB.png?v=1\",\"excerpt\":\"Offer personalized product bundles, bulk discount packages, and assembled\\u00a0products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-bundles\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"aa2518b5-ab19-4b75-bde9-60ca51e20f28\",\"slug\":\"woocommerce-product-bundles\",\"id\":18716},{\"title\":\"Multichannel for WooCommerce: Google, Amazon, eBay &amp; Walmart Integration\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2018\\/10\\/Woo-Extension-Store-Logo-v2.png\",\"excerpt\":\"Get the official Google, Amazon, eBay and Walmart extension and create, sync and manage multichannel listings directly from WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/amazon-ebay-integration\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"e4000666-9275-4c71-8619-be61fb41c9f9\",\"slug\":\"woocommerce-amazon-ebay-integration\",\"id\":3545890},{\"title\":\"Min\\/Max Quantities\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Min-Max-Qua-Dark.png\",\"excerpt\":\"Specify minimum and maximum allowed product quantities for orders to be completed.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/minmax-quantities\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"2b5188d90baecfb781a5aa2d6abb900a\",\"slug\":\"woocommerce-min-max-quantities\",\"id\":18616},{\"title\":\"FedEx Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/01\\/FedEx_Logo_Wallpaper.jpeg\",\"excerpt\":\"Get shipping rates from the FedEx API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/fedex-shipping-module\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1a48b598b47a81559baadef15e320f64\",\"slug\":\"woocommerce-shipping-fedex\",\"id\":18620},{\"title\":\"LiveChat for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2015\\/11\\/LC_woo_regular-zmiaym.png\",\"excerpt\":\"Live Chat and messaging platform for sales and support -- increase average order value and overall sales through live conversations.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/livechat\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.livechat.com\\/livechat-for-ecommerce\\/?a=woocommerce&amp;utm_source=woocommerce.com&amp;utm_medium=integration&amp;utm_campaign=woocommerce.com\",\"price\":\"&#36;0.00\",\"hash\":\"5344cc1f-ed4a-4d00-beff-9d67f6d372f3\",\"slug\":\"livechat-woocommerce\",\"id\":1348888},{\"title\":\"Authorize.Net\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2013\\/04\\/Thumbnail-Authorize.net-updated.png\",\"excerpt\":\"Authorize.Net gateway with support for pre-orders and subscriptions.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/authorize-net\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8b61524fe53add7fdd1a8d1b00b9327d\",\"slug\":\"woocommerce-gateway-authorize-net-cim\",\"id\":178481},{\"title\":\"Product CSV Import Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Product-CSV-Import-Dark.png\",\"excerpt\":\"Import, merge, and export products and variations to and from WooCommerce using a CSV file.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-csv-import-suite\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"7ac9b00a1fe980fb61d28ab54d167d0d\",\"slug\":\"woocommerce-product-csv-import-suite\",\"id\":18680},{\"title\":\"Follow-Ups\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Follow-Ups-Dark.png\",\"excerpt\":\"Automatically contact customers after purchase - be it everyone, your most loyal or your biggest spenders - and keep your store top-of-mind.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/follow-up-emails\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"05ece68fe94558e65278fe54d9ec84d2\",\"slug\":\"woocommerce-follow-up-emails\",\"id\":18686},{\"title\":\"WooCommerce Customer \\/ Order \\/ Coupon Export\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/02\\/Thumbnail-Customer-Order-Coupon-Export-updated.png\",\"excerpt\":\"Export customers, orders, and coupons from WooCommerce manually or on an automated schedule.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/ordercustomer-csv-export\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"914de15813a903c767b55445608bf290\",\"slug\":\"woocommerce-customer-order-csv-export\",\"id\":18652},{\"title\":\"Australia Post Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/australia-post.gif\",\"excerpt\":\"Get shipping rates for your WooCommerce store from the Australia Post API, which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/australia-post-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1dbd4dc6bd91a9cda1bd6b9e7a5e4f43\",\"slug\":\"woocommerce-shipping-australia-post\",\"id\":18622},{\"title\":\"Canada Post Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/canada-post.png\",\"excerpt\":\"Get shipping rates from the Canada Post Ratings API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/canada-post-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"ac029cdf3daba20b20c7b9be7dc00e0e\",\"slug\":\"woocommerce-shipping-canada-post\",\"id\":18623},{\"title\":\"Product Vendors\",\"image\":\"\",\"excerpt\":\"Turn your store into a multi-vendor marketplace\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-vendors\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"a97d99fccd651bbdd728f4d67d492c31\",\"slug\":\"woocommerce-product-vendors\",\"id\":219982},{\"title\":\"WooCommerce Accommodation Bookings\",\"image\":\"\",\"excerpt\":\"Book accommodation using WooCommerce and the WooCommerce Bookings extension.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-accommodation-bookings\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"99b2a7a4af90b6cefd2a733b3b1f78e7\",\"slug\":\"woocommerce-accommodation-bookings\",\"id\":1412069},{\"title\":\"Smart Coupons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/10\\/wc-product-smart-coupons.png\",\"excerpt\":\"Everything you need for discounts, coupons, credits, gift cards, product giveaways, offers, and promotions. Most popular and complete coupons plugin for WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/smart-coupons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/demo.storeapps.org\\/?demo=sc\",\"price\":\"&#36;99.00\",\"hash\":\"05c45f2aa466106a466de4402fff9dde\",\"slug\":\"woocommerce-smart-coupons\",\"id\":18729},{\"title\":\"WooCommerce Brands\",\"image\":\"\",\"excerpt\":\"Create, assign and list brands for products, and allow customers to view by brand.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/brands\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"8a88c7cbd2f1e73636c331c7a86f818c\",\"slug\":\"woocommerce-brands\",\"id\":18737},{\"title\":\"Xero\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/08\\/xero2.png\",\"excerpt\":\"Save time with automated sync between WooCommerce and your Xero account.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/xero\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"f0dd29d338d3c67cf6cee88eddf6869b\",\"slug\":\"woocommerce-xero\",\"id\":18733},{\"title\":\"Royal Mail\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/04\\/royalmail.png\",\"excerpt\":\"Offer Royal Mail shipping rates to your customers\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/royal-mail\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"03839cca1a16c4488fcb669aeb91a056\",\"slug\":\"woocommerce-shipping-royalmail\",\"id\":182719},{\"title\":\"AutomateWoo\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-AutomateWoo-Dark-1.png\",\"excerpt\":\"Powerful marketing automation for WooCommerce. AutomateWoo has the tools you need to grow your store and make more money.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/automatewoo\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"ba9299b8-1dba-4aa0-a313-28bc1755cb88\",\"slug\":\"automatewoo\",\"id\":4652610},{\"title\":\"WooCommerce Zapier\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/woocommerce-zapier-logo.png\",\"excerpt\":\"Integrate with 3000+ cloud apps and services today.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-zapier\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;59.00\",\"hash\":\"0782bdbe932c00f4978850268c6cfe40\",\"slug\":\"woocommerce-zapier\",\"id\":243589},{\"title\":\"Advanced Notifications\",\"image\":\"\",\"excerpt\":\"Easily setup \\\"new order\\\" and stock email notifications for multiple recipients of your choosing.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/advanced-notifications\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"112372c44b002fea2640bd6bfafbca27\",\"slug\":\"woocommerce-advanced-notifications\",\"id\":18740},{\"title\":\"Dynamic Pricing\",\"image\":\"\",\"excerpt\":\"Bulk discounts, role-based pricing and much more\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/dynamic-pricing\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"9a41775bb33843f52c93c922b0053986\",\"slug\":\"woocommerce-dynamic-pricing\",\"id\":18643},{\"title\":\"WooCommerce Points and Rewards\",\"image\":\"\",\"excerpt\":\"Reward your customers for purchases and other actions with points which can be redeemed for discounts.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-points-and-rewards\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"1649b6cca5da8b923b01ca56b5cdd246\",\"slug\":\"woocommerce-points-and-rewards\",\"id\":210259},{\"title\":\"Name Your Price\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/09\\/nyp-icon-dark-v83owf.png\",\"excerpt\":\"Allow customers to define the product price. Also useful for accepting user-set donations.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/name-your-price\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"31b4e11696cd99a3c0572975a84f1c08\",\"slug\":\"woocommerce-name-your-price\",\"id\":18738},{\"title\":\"WooCommerce Print Invoices &amp; Packing lists\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/03\\/Thumbnail-Print-Invoices-Packing-lists-updated.png\",\"excerpt\":\"Generate invoices, packing slips, and pick lists for your WooCommerce orders.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/print-invoices-packing-lists\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"465de1126817cdfb42d97ebca7eea717\",\"slug\":\"woocommerce-pip\",\"id\":18666},{\"title\":\"WooCommerce Pre-Orders\",\"image\":\"\",\"excerpt\":\"Allow customers to order products before they are available.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-pre-orders\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"b2dc75e7d55e6f5bbfaccb59830f66b7\",\"slug\":\"woocommerce-pre-orders\",\"id\":178477},{\"title\":\"WooCommerce Subscription Downloads\",\"image\":\"\",\"excerpt\":\"Offer additional downloads to your subscribers, via downloadable products listed in your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-subscription-downloads\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"5be9e21c13953253e4406d2a700382ec\",\"slug\":\"woocommerce-subscription-downloads\",\"id\":420458},{\"title\":\"WooCommerce Additional Variation Images\",\"image\":\"\",\"excerpt\":\"Add gallery images per variation on variable products within WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-additional-variation-images\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/themes.woocommerce.com\\/storefront\\/product\\/woo-single-1\\/\",\"price\":\"&#36;49.00\",\"hash\":\"c61dd6de57dcecb32bd7358866de4539\",\"slug\":\"woocommerce-additional-variation-images\",\"id\":477384},{\"title\":\"WooCommerce Deposits\",\"image\":\"\",\"excerpt\":\"Enable customers to pay for products using a deposit or a payment plan.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-deposits\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;179.00\",\"hash\":\"de192a6cf12c4fd803248da5db700762\",\"slug\":\"woocommerce-deposits\",\"id\":977087},{\"title\":\"Google Product Feed\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2011\\/11\\/logo-regular-lscryp.png\",\"excerpt\":\"Feed product data to Google Merchant Center for setting up Google product listings &amp; product ads.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/google-product-feed\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"d55b4f852872025741312839f142447e\",\"slug\":\"woocommerce-product-feeds\",\"id\":18619},{\"title\":\"Amazon S3 Storage\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/amazon.png\",\"excerpt\":\"Serve digital products via Amazon S3\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/amazon-s3-storage\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"473bf6f221b865eff165c97881b473bb\",\"slug\":\"woocommerce-amazon-s3-storage\",\"id\":18663},{\"title\":\"Cart Add-ons\",\"image\":\"\",\"excerpt\":\"A powerful tool for driving incremental and impulse purchases by customers once they are in the shopping cart\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/cart-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"3a8ef25334396206f5da4cf208adeda3\",\"slug\":\"woocommerce-cart-add-ons\",\"id\":18717},{\"title\":\"Shipping Multiple Addresses\",\"image\":\"\",\"excerpt\":\"Allow your customers to ship individual items in a single order to multiple addresses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipping-multiple-addresses\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"aa0eb6f777846d329952d5b891d6f8cc\",\"slug\":\"woocommerce-shipping-multiple-addresses\",\"id\":18741},{\"title\":\"WooCommerce AvaTax\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/01\\/Thumbnail-Avalara-updated.png\",\"excerpt\":\"Get 100% accurate sales tax calculations and on time tax return filing. No more tracking sales tax rates, rules, or jurisdictional boundaries.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-avatax\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"57077a4b28ba71cacf692bcf4a1a7f60\",\"slug\":\"woocommerce-avatax\",\"id\":1389326},{\"title\":\"PayPal Payments Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Paypal-Payments-Pro-Dark.png\",\"excerpt\":\"Take credit card payments directly on your checkout using PayPal Pro.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/paypal-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6d23ba7f0e0198937c0029f9e865b40e\",\"slug\":\"woocommerce-gateway-paypal-pro\",\"id\":18594},{\"title\":\"Klarna Checkout\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2018\\/01\\/Partner_marketing_Klarna_Checkout_Black-1.png\",\"excerpt\":\"Klarna Checkout is a full checkout experience embedded on your site that includes all popular payment methods (Pay Now, Pay Later, Financing, Installments).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/klarna-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/demo.krokedil.se\\/klarnacheckout\\/\",\"price\":\"&#36;0.00\",\"hash\":\"90f8ce584e785fcd8c2d739fd4f40d78\",\"slug\":\"klarna-checkout-for-woocommerce\",\"id\":2754152},{\"title\":\"Gravity Forms Product Add-ons\",\"image\":\"\",\"excerpt\":\"Powerful product add-ons, Gravity style\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/gravity-forms-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/gravity-forms\\/\",\"price\":\"&#36;99.00\",\"hash\":\"a6ac0ab1a1536e3a357ccf24c0650ed0\",\"slug\":\"woocommerce-gravityforms-product-addons\",\"id\":18633},{\"title\":\"Bulk Stock Management\",\"image\":\"\",\"excerpt\":\"Edit product and variation stock levels in bulk via this handy interface\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/bulk-stock-management\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"02f4328d52f324ebe06a78eaaae7934f\",\"slug\":\"woocommerce-bulk-stock-management\",\"id\":18670},{\"title\":\"Composite Products\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-CP.png?v=1\",\"excerpt\":\"Create product kit builders and custom product configurators using existing products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/composite-products\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"0343e0115bbcb97ccd98442b8326a0af\",\"slug\":\"woocommerce-composite-products\",\"id\":216836},{\"title\":\"WooCommerce Email Customizer\",\"image\":\"\",\"excerpt\":\"Connect with your customers with each email you send by visually modifying your email templates via the WordPress Customizer.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-email-customizer\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"bd909fa97874d431f203b5336c7e8873\",\"slug\":\"woocommerce-email-customizer\",\"id\":853277},{\"title\":\"TaxJar\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/10\\/taxjar-logotype.png\",\"excerpt\":\"Save hours every month by putting your sales tax on autopilot. Automated, multi-state sales tax calculation, reporting, and filing for your WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/taxjar\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"12072d8e-e933-4561-97b1-9db3c7eeed91\",\"slug\":\"taxjar-simplified-taxes-for-woocommerce\",\"id\":514914},{\"title\":\"Force Sells\",\"image\":\"\",\"excerpt\":\"Force products to be added to the cart\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/force-sells\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"3ebddfc491ca168a4ea4800b893302b0\",\"slug\":\"woocommerce-force-sells\",\"id\":18678},{\"title\":\"WooCommerce Quick View\",\"image\":\"\",\"excerpt\":\"Show a quick-view button to view product details and add to cart via lightbox popup\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-quick-view\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"619c6e57ce72c49c4b57e15b06eddb65\",\"slug\":\"woocommerce-quick-view\",\"id\":187509},{\"title\":\"WooCommerce Purchase Order Gateway\",\"image\":\"\",\"excerpt\":\"Receive purchase orders via your WooCommerce-powered online store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-purchase-order\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"573a92318244ece5facb449d63e74874\",\"slug\":\"woocommerce-gateway-purchase-order\",\"id\":478542},{\"title\":\"Returns and Warranty Requests\",\"image\":\"\",\"excerpt\":\"Manage the RMA process, add warranties to products &amp; let customers request &amp; manage returns \\/ exchanges from their account.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/warranty-requests\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"9b4c41102e6b61ea5f558e16f9b63e25\",\"slug\":\"woocommerce-warranty\",\"id\":228315},{\"title\":\"Product Enquiry Form\",\"image\":\"\",\"excerpt\":\"Allow visitors to contact you directly from the product details page via a reCAPTCHA protected form to enquire about a product.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-enquiry-form\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"5a0f5d72519a8ffcc86669f042296937\",\"slug\":\"woocommerce-product-enquiry-form\",\"id\":18601},{\"title\":\"WooCommerce Box Office\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-BO-Dark.png\",\"excerpt\":\"Sell tickets for your next event, concert, function, fundraiser or conference directly on your own site\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-box-office\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"e704c9160de318216a8fa657404b9131\",\"slug\":\"woocommerce-box-office\",\"id\":1628717},{\"title\":\"WooCommerce Order Barcodes\",\"image\":\"\",\"excerpt\":\"Generates a unique barcode for each order on your site - perfect for e-tickets, packing slips, reservations and a variety of other uses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-barcodes\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"889835bb29ee3400923653e1e44a3779\",\"slug\":\"woocommerce-order-barcodes\",\"id\":391708},{\"title\":\"WooCommerce Paid Courses\",\"image\":\"\",\"excerpt\":\"Sell your online courses using the most popular eCommerce platform on the web \\u2013 WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-paid-courses\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"bad2a02a063555b7e2bee59924690763\",\"slug\":\"woothemes-sensei\",\"id\":152116},{\"title\":\"WooCommerce 360\\u00ba Image\",\"image\":\"\",\"excerpt\":\"An easy way to add a dynamic, controllable 360\\u00ba image rotation to your WooCommerce site, by adding a group of images to a product\\u2019s gallery.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-360-image\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"24eb2cfa3738a66bf3b2587876668cd2\",\"slug\":\"woocommerce-360-image\",\"id\":512186},{\"title\":\"WooCommerce Photography\",\"image\":\"\",\"excerpt\":\"Sell photos in the blink of an eye using this simple as dragging &amp; dropping interface.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-photography\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"ee76e8b9daf1d97ca4d3874cc9e35687\",\"slug\":\"woocommerce-photography\",\"id\":583602},{\"title\":\"WooCommerce Bookings Availability\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Bookings-Aval-Dark.png\",\"excerpt\":\"Sell more bookings by presenting a calendar or schedule of available slots in a page or post.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/bookings-availability\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"30770d2a-e392-4e82-baaa-76cfc7d02ae3\",\"slug\":\"woocommerce-bookings-availability\",\"id\":4228225},{\"title\":\"Software Add-on\",\"image\":\"\",\"excerpt\":\"Sell License Keys for Software\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/software-add-on\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"79f6dbfe1f1d3a56a86f0509b6d6b04b\",\"slug\":\"woocommerce-software-add-on\",\"id\":18683},{\"title\":\"WooCommerce Products Compare\",\"image\":\"\",\"excerpt\":\"WooCommerce Products Compare will allow your potential customers to easily compare products within your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-products-compare\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"c3ba0a4a3199a0cc7a6112eb24414548\",\"slug\":\"woocommerce-products-compare\",\"id\":853117},{\"title\":\"WooCommerce Store Catalog PDF Download\",\"image\":\"\",\"excerpt\":\"Offer your customers a PDF download of your product catalog, generated by WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-store-catalog-pdf-download\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"79ca7aadafe706364e2d738b7c1090c4\",\"slug\":\"woocommerce-store-catalog-pdf-download\",\"id\":675790},{\"title\":\"eWAY\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2011\\/10\\/eway-logo-3000-2000.jpg\",\"excerpt\":\"Take credit card payments securely via eWay (SG, MY, HK, AU, and NZ) keeping customers on your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/eway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"2c497769d98d025e0d340cd0b5ea5da1\",\"slug\":\"woocommerce-gateway-eway\",\"id\":18604},{\"title\":\"Catalog Visibility Options\",\"image\":\"\",\"excerpt\":\"Transform WooCommerce into an online catalog by removing eCommerce functionality\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/catalog-visibility-options\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"12e791110365fdbb5865c8658907967e\",\"slug\":\"woocommerce-catalog-visibility-options\",\"id\":18648},{\"title\":\"WooCommerce Blocks\",\"image\":\"\",\"excerpt\":\"WooCommerce Blocks offers a range of Gutenberg blocks you can use to build and customise your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gutenberg-products-block\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"c2e9f13a-f90c-4ffe-a8a5-b432399ec263\",\"slug\":\"woo-gutenberg-products-block\",\"id\":3076677},{\"title\":\"Sequential Order Numbers Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/05\\/Thumbnail-Sequential-Order-Numbers-Pro-updated.png\",\"excerpt\":\"Tame your order numbers! Advanced &amp; sequential order numbers with optional prefixes \\/ suffixes\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/sequential-order-numbers-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"0b18a2816e016ba9988b93b1cd8fe766\",\"slug\":\"woocommerce-sequential-order-numbers-pro\",\"id\":18688},{\"title\":\"Conditional Shipping and Payments\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-CSP.png?v=1\",\"excerpt\":\"Use conditional logic to restrict the shipping and payment options available on your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/conditional-shipping-and-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1f56ff002fa830b77017b0107505211a\",\"slug\":\"woocommerce-conditional-shipping-and-payments\",\"id\":680253},{\"title\":\"WooCommerce Order Status Manager\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2015\\/02\\/Thumbnail-Order-Status-Manager-updated.png\",\"excerpt\":\"Create, edit, and delete completely custom order statuses and integrate them seamlessly into your order management flow.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-status-manager\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"51fd9ab45394b4cad5a0ebf58d012342\",\"slug\":\"woocommerce-order-status-manager\",\"id\":588398},{\"title\":\"WooCommerce Checkout Add-Ons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/07\\/Thumbnail-Checkout-Add-Ons-updated.png\",\"excerpt\":\"Highlight relevant products, offers like free shipping and other up-sells during checkout.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-checkout-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8fdca00b4000b7a8cc26371d0e470a8f\",\"slug\":\"woocommerce-checkout-add-ons\",\"id\":466854},{\"title\":\"WooCommerce Google Analytics Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/01\\/Thumbnail-GAPro-updated.png\",\"excerpt\":\"Add advanced event tracking and enhanced eCommerce tracking to your WooCommerce site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-google-analytics-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"d8aed8b7306b509eec1589e59abe319f\",\"slug\":\"woocommerce-google-analytics-pro\",\"id\":1312497},{\"title\":\"QuickBooks Sync for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2019\\/04\\/woocommerce-com-logo-1-hyhzbh.png\",\"excerpt\":\"Automatic two-way sync for orders, customers, products, inventory and more between WooCommerce and QuickBooks (Online, Desktop, or POS).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/quickbooks-sync-for-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"c5e32e20-7c1f-4585-8b15-d930c2d842ac\",\"slug\":\"myworks-woo-sync-for-quickbooks-online\",\"id\":4065824},{\"title\":\"WooCommerce One Page Checkout\",\"image\":\"\",\"excerpt\":\"Create special pages where customers can choose products, checkout &amp; pay all on the one page.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-one-page-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"c9ba8f8352cd71b5508af5161268619a\",\"slug\":\"woocommerce-one-page-checkout\",\"id\":527886},{\"title\":\"WooCommerce Product Search\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2014\\/10\\/woocommerce-product-search-product-image-1870x960-1-jvsljj.png\",\"excerpt\":\"The perfect search engine helps customers to find and buy products quickly \\u2013 essential for every WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-product-search\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/demo.itthinx.com\\/wps\\/\",\"price\":\"&#36;49.00\",\"hash\":\"c84cc8ca16ddac3408e6b6c5871133a8\",\"slug\":\"woocommerce-product-search\",\"id\":512174},{\"title\":\"First Data\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/02\\/Thumbnail-FirstData-updated.png\",\"excerpt\":\"FirstData gateway for WooCommerce\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/firstdata\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"eb3e32663ec0810592eaf0d097796230\",\"slug\":\"woocommerce-gateway-firstdata\",\"id\":18645},{\"title\":\"WooSlider\",\"image\":\"\",\"excerpt\":\"WooSlider is the ultimate responsive slideshow WordPress slider plugin\\r\\n\\r\\n\\u00a0\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/wooslider\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/www.wooslider.com\\/\",\"price\":\"&#36;49.00\",\"hash\":\"209d98f3ccde6cc3de7e8732a2b20b6a\",\"slug\":\"wooslider\",\"id\":46506},{\"title\":\"WooCommerce Social Login\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/08\\/Thumbnail-Social-Login-updated.png\",\"excerpt\":\"Enable Social Login for seamless checkout and account creation.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-social-login\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/demos.skyverge.com\\/woocommerce-social-login\\/\",\"price\":\"&#36;79.00\",\"hash\":\"b231cd6367a79cc8a53b7d992d77525d\",\"slug\":\"woocommerce-social-login\",\"id\":473617},{\"title\":\"Coupon Shortcodes\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/09\\/woocommerce-coupon-shortcodes-product-image-1870x960-1-vc5gux.png\",\"excerpt\":\"Show coupon discount info using shortcodes. Allows to render coupon information and content conditionally, based on the validity of coupons.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/coupon-shortcodes\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"ac5d9d51-70b2-4d8f-8b89-24200eea1394\",\"slug\":\"woocommerce-coupon-shortcodes\",\"id\":244762},{\"title\":\"WooCommerce Order Status Control\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/06\\/Thumbnail-Order-Status-Control-updated.png\",\"excerpt\":\"Use this extension to automatically change the order status to \\\"completed\\\" after successful payment.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-status-control\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"32400e509c7c36dcc1cd368e8267d981\",\"slug\":\"woocommerce-order-status-control\",\"id\":439037},{\"title\":\"Variation Swatches and Photos\",\"image\":\"\",\"excerpt\":\"Show color and image swatches instead of dropdowns for variable products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/variation-swatches-and-photos\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/swatches-and-photos\\/\",\"price\":\"&#36;99.00\",\"hash\":\"37bea8d549df279c8278878d081b062f\",\"slug\":\"woocommerce-variation-swatches-and-photos\",\"id\":18697},{\"title\":\"Jilt\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2017\\/12\\/Thumbnail-Jilt-updated.png\",\"excerpt\":\"All-in-one email marketing platform built for WooCommerce stores. Send newsletters, abandoned cart reminders, win-backs, welcome automations, and more.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/jilt\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"b53aafb64dca33835e41ee06de7e9816\",\"slug\":\"jilt-for-woocommerce\",\"id\":2754876},{\"title\":\"Opayo Payment Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2011\\/10\\/Opayo_logo_RGB.png\",\"excerpt\":\"Take payments on your WooCommerce store via Opayo (formally SagePay).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/sage-pay-form\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6bc0cca47d0274d8ef9b164f6fbec1cc\",\"slug\":\"woocommerce-gateway-sagepay-form\",\"id\":18599},{\"title\":\"EU VAT Number\",\"image\":\"\",\"excerpt\":\"Collect VAT numbers at checkout and remove the VAT charge for eligible EU businesses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/eu-vat-number\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"d2720c4b4bb8d6908e530355b7a2d734\",\"slug\":\"woocommerce-eu-vat-number\",\"id\":18592},{\"title\":\"PayPal\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2020\\/10\\/PPCP-Tile-PayPal-Logo-and-Cart-Art-2x-2-uozwz8.jpg\",\"excerpt\":\"PayPal\\u2019s latest, most complete payment processing solution. Accept PayPal exclusives, credit\\/debit cards and local payment methods. Turn on only PayPal options or process a full suite of payment methods. Enable global transactions with extensive currency and country coverage. Built and supported by WooCommerce and PayPal.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-paypal-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"934115ab-e3f3-4435-9580-345b1ce21899\",\"slug\":\"woocommerce-paypal-payments\",\"id\":6410731},{\"title\":\"QuickBooks Commerce (formerly TradeGecko)\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2013\\/09\\/qbo-mark.png\",\"excerpt\":\"Get a wholesale and multichannel inventory &amp; order management platform for your WooCommerce store with QuickBooks Commerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-tradegecko\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"21da7811f7fc1f13ee19daa7415f0ff3\",\"slug\":\"woocommerce-tradegecko\",\"id\":245960}]}\";s:3:\"raw\";s:48948:\"HTTP/1.1 200 OK
Server: nginx
Date: Tue, 01 Jun 2021 09:29:44 GMT
Content-Type: application/json; charset=UTF-8
Content-Length: 11636
Connection: close
X-Robots-Tag: noindex
Link: <https://woocommerce.com/wp-json/>; rel=\"https://api.w.org/\"
X-Content-Type-Options: nosniff
Access-Control-Expose-Headers: X-WP-Total, X-WP-TotalPages, Link
Access-Control-Allow-Headers: Authorization, X-WP-Nonce, Content-Disposition, Content-MD5, Content-Type
X-WCCOM-Cache: HIT
Cache-Control: max-age=60
Allow: GET
Content-Encoding: gzip
X-rq: ams5 85 167 3131
Age: 27
X-Cache: hit
Vary: Accept-Encoding, Origin
Accept-Ranges: bytes

{\"products\":[{\"title\":\"WooCommerce Google Analytics\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/GA-Dark.png\",\"excerpt\":\"Understand your customers and increase revenue with world\\u2019s leading analytics platform - integrated with WooCommerce for free.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-google-analytics\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"2d21f7de14dfb8e9885a4622be701ddf\",\"slug\":\"woocommerce-google-analytics-integration\",\"id\":1442927},{\"title\":\"WooCommerce Tax\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Tax-Dark.png\",\"excerpt\":\"Automatically calculate how much sales tax should be collected for WooCommerce orders - by city, country, or state - at checkout.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/tax\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"f31b3b9273cce188cc2b27f7849d02dd\",\"slug\":\"woocommerce-services\",\"id\":3220291},{\"title\":\"Stripe\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Stripe-Dark-1.png\",\"excerpt\":\"Accept all major debit and credit cards as well as local payment methods with Stripe.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/stripe\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"50bb7a985c691bb943a9da4d2c8b5efd\",\"slug\":\"woocommerce-gateway-stripe\",\"id\":18627},{\"title\":\"Jetpack\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Jetpack-Dark.png\",\"excerpt\":\"Power up and protect your store with Jetpack\\r\\n\\r\\nFor free security, insights and monitoring, connect to Jetpack. It\'s everything you need for a strong, secure start.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/jetpack\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"d5bfef9700b62b2b132c74c74c3193eb\",\"slug\":\"jetpack\",\"id\":2725249},{\"title\":\"Facebook for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Facebook-Dark.png\",\"excerpt\":\"Get the Official Facebook for WooCommerce plugin for three powerful ways to help grow your business.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/facebook\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"0ea4fe4c2d7ca6338f8a322fb3e4e187\",\"slug\":\"facebook-for-woocommerce\",\"id\":2127297},{\"title\":\"Amazon Pay\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Amazon-Pay-Dark.png\",\"excerpt\":\"Amazon Pay is embedded in your WooCommerce store. Transactions take place via\\u00a0Amazon widgets, so the buyer never leaves your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/pay-with-amazon\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"9865e043bbbe4f8c9735af31cb509b53\",\"slug\":\"woocommerce-gateway-amazon-payments-advanced\",\"id\":238816},{\"title\":\"Square for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Square-Dark.png\",\"excerpt\":\"Accepting payments is easy with Square. Clear rates, fast deposits (1-2 business days). Sell online and in person, and sync all payments, items and inventory.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/square\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"e907be8b86d7df0c8f8e0d0020b52638\",\"slug\":\"woocommerce-square\",\"id\":1770503},{\"title\":\"WooCommerce Shipping\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Ship-Dark-1.png\",\"excerpt\":\"Print USPS and DHL labels right from your WooCommerce dashboard and instantly save up to 90%. WooCommerce Shipping is free to use and saves you time and money.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"f31b3b9273cce188cc2b27f7849d02dd\",\"slug\":\"woocommerce-services\",\"id\":2165910},{\"title\":\"WooCommerce Payments\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Pay-Dark.png\",\"excerpt\":\"Securely accept payments, track cash flow, and manage recurring revenue from your dashboard \\u2014 all without setup costs or monthly fees.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"8c6319ca-8f41-4e69-be63-6b15ee37773b\",\"slug\":\"woocommerce-payments\",\"id\":5278104},{\"title\":\"Mailchimp for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/09\\/logo-mailchimp-dark-v2.png\",\"excerpt\":\"Increase traffic, drive repeat purchases, and personalize your marketing when you connect to Mailchimp.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/mailchimp-for-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"b4481616ebece8b1ff68fc59b90c1a91\",\"slug\":\"mailchimp-for-woocommerce\",\"id\":2545166},{\"title\":\"PayPal Checkout\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Paypal-Dark.png\",\"excerpt\":\"PayPal Checkout now with Smart Payment Buttons\\u2122, dynamically displays, PayPal, Venmo, PayPal Credit, or other local payment options in a single stack giving customers the choice to pay with their preferred option.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-paypal-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"69e6cba62ac4021df9e117cc3f716d07\",\"slug\":\"woocommerce-gateway-paypal-express-checkout\",\"id\":1597922},{\"title\":\"WooCommerce Subscriptions\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Subscriptions-Dark.png\",\"excerpt\":\"Let customers subscribe to your products or services and pay on a weekly, monthly or annual basis.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-subscriptions\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;199.00\",\"hash\":\"6115e6d7e297b623a169fdcf5728b224\",\"slug\":\"woocommerce-subscriptions\",\"id\":27147},{\"title\":\"ShipStation Integration\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Shipstation-Dark.png\",\"excerpt\":\"Fulfill all your Woo orders (and wherever else you sell) quickly and easily using ShipStation. Try it free for 30 days today!\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipstation-integration\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"9de8640767ba64237808ed7f245a49bb\",\"slug\":\"woocommerce-shipstation-integration\",\"id\":18734},{\"title\":\"Product Add-Ons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Product-Add-Ons-Dark.png\",\"excerpt\":\"Offer add-ons like gift wrapping, special messages or other special options for your products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"147d0077e591e16db9d0d67daeb8c484\",\"slug\":\"woocommerce-product-addons\",\"id\":18618},{\"title\":\"PayFast Payment Gateway\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Payfast-Dark-1.png\",\"excerpt\":\"Take payments on your WooCommerce store via PayFast (redirect method).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/payfast-payment-gateway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"557bf07293ad916f20c207c6c9cd15ff\",\"slug\":\"woocommerce-payfast-gateway\",\"id\":18596},{\"title\":\"Google Ads &amp; Marketing by Kliken\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2019\\/02\\/GA-for-Woo-Logo-374x192px-qu3duk.png\",\"excerpt\":\"Get in front of shoppers and drive traffic to your store so you can grow your business with Smart Shopping Campaigns and free listings.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/google-ads-and-marketing\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"bf66e173-a220-4da7-9512-b5728c20fc16\",\"slug\":\"kliken-marketing-for-google\",\"id\":3866145},{\"title\":\"USPS Shipping Method\",\"image\":\"\",\"excerpt\":\"Get shipping rates from the USPS API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/usps-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"83d1524e8f5f1913e58889f83d442c32\",\"slug\":\"woocommerce-shipping-usps\",\"id\":18657},{\"title\":\"UPS Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/UPS-Shipping-Method-Dark.png\",\"excerpt\":\"Get shipping rates from the UPS API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/ups-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8dae58502913bac0fbcdcaba515ea998\",\"slug\":\"woocommerce-shipping-ups\",\"id\":18665},{\"title\":\"Shipment Tracking\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Ship-Tracking-Dark-1.png\",\"excerpt\":\"Add shipment tracking information to your orders.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipment-tracking\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"1968e199038a8a001c9f9966fd06bf88\",\"slug\":\"woocommerce-shipment-tracking\",\"id\":18693},{\"title\":\"Braintree for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/02\\/braintree-black-copy.png\",\"excerpt\":\"Accept PayPal, credit cards and debit cards with a single payment gateway solution \\u2014 PayPal Powered by Braintree.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-paypal-powered-by-braintree\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"27f010c8e34ca65b205ddec88ad14536\",\"slug\":\"woocommerce-gateway-paypal-powered-by-braintree\",\"id\":1489837},{\"title\":\"Table Rate Shipping\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Product-Table-Rate-Shipping-Dark.png\",\"excerpt\":\"Advanced, flexible shipping. Define multiple shipping rates based on location, price, weight, shipping class or item count.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/table-rate-shipping\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"3034ed8aff427b0f635fe4c86bbf008a\",\"slug\":\"woocommerce-table-rate-shipping\",\"id\":18718},{\"title\":\"Checkout Field Editor\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Checkout-Field-Editor-Dark.png\",\"excerpt\":\"Optimize your checkout process by adding, removing or editing fields to suit your needs.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-checkout-field-editor\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"2b8029f0d7cdd1118f4d843eb3ab43ff\",\"slug\":\"woocommerce-checkout-field-editor\",\"id\":184594},{\"title\":\"WooCommerce Memberships\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2015\\/06\\/Thumbnail-Memberships-updated.png\",\"excerpt\":\"Give members access to restricted content or products, for a fee or for free.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-memberships\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;199.00\",\"hash\":\"9288e7609ad0b487b81ef6232efa5cfc\",\"slug\":\"woocommerce-memberships\",\"id\":958589},{\"title\":\"WooCommerce Bookings\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Bookings-Dark.png\",\"excerpt\":\"Allow customers to book appointments, make reservations or rent equipment without leaving your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-bookings\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/themes.woocommerce.com\\/hotel\\/\",\"price\":\"&#36;249.00\",\"hash\":\"911c438934af094c2b38d5560b9f50f3\",\"slug\":\"WooCommerce Bookings\",\"id\":390890},{\"title\":\"Product Bundles\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-PB.png?v=1\",\"excerpt\":\"Offer personalized product bundles, bulk discount packages, and assembled\\u00a0products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-bundles\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"aa2518b5-ab19-4b75-bde9-60ca51e20f28\",\"slug\":\"woocommerce-product-bundles\",\"id\":18716},{\"title\":\"Multichannel for WooCommerce: Google, Amazon, eBay &amp; Walmart Integration\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2018\\/10\\/Woo-Extension-Store-Logo-v2.png\",\"excerpt\":\"Get the official Google, Amazon, eBay and Walmart extension and create, sync and manage multichannel listings directly from WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/amazon-ebay-integration\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"e4000666-9275-4c71-8619-be61fb41c9f9\",\"slug\":\"woocommerce-amazon-ebay-integration\",\"id\":3545890},{\"title\":\"Min\\/Max Quantities\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Min-Max-Qua-Dark.png\",\"excerpt\":\"Specify minimum and maximum allowed product quantities for orders to be completed.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/minmax-quantities\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"2b5188d90baecfb781a5aa2d6abb900a\",\"slug\":\"woocommerce-min-max-quantities\",\"id\":18616},{\"title\":\"FedEx Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/01\\/FedEx_Logo_Wallpaper.jpeg\",\"excerpt\":\"Get shipping rates from the FedEx API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/fedex-shipping-module\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1a48b598b47a81559baadef15e320f64\",\"slug\":\"woocommerce-shipping-fedex\",\"id\":18620},{\"title\":\"LiveChat for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2015\\/11\\/LC_woo_regular-zmiaym.png\",\"excerpt\":\"Live Chat and messaging platform for sales and support -- increase average order value and overall sales through live conversations.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/livechat\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.livechat.com\\/livechat-for-ecommerce\\/?a=woocommerce&amp;utm_source=woocommerce.com&amp;utm_medium=integration&amp;utm_campaign=woocommerce.com\",\"price\":\"&#36;0.00\",\"hash\":\"5344cc1f-ed4a-4d00-beff-9d67f6d372f3\",\"slug\":\"livechat-woocommerce\",\"id\":1348888},{\"title\":\"Authorize.Net\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2013\\/04\\/Thumbnail-Authorize.net-updated.png\",\"excerpt\":\"Authorize.Net gateway with support for pre-orders and subscriptions.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/authorize-net\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8b61524fe53add7fdd1a8d1b00b9327d\",\"slug\":\"woocommerce-gateway-authorize-net-cim\",\"id\":178481},{\"title\":\"Product CSV Import Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Product-CSV-Import-Dark.png\",\"excerpt\":\"Import, merge, and export products and variations to and from WooCommerce using a CSV file.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-csv-import-suite\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"7ac9b00a1fe980fb61d28ab54d167d0d\",\"slug\":\"woocommerce-product-csv-import-suite\",\"id\":18680},{\"title\":\"Follow-Ups\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Follow-Ups-Dark.png\",\"excerpt\":\"Automatically contact customers after purchase - be it everyone, your most loyal or your biggest spenders - and keep your store top-of-mind.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/follow-up-emails\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"05ece68fe94558e65278fe54d9ec84d2\",\"slug\":\"woocommerce-follow-up-emails\",\"id\":18686},{\"title\":\"WooCommerce Customer \\/ Order \\/ Coupon Export\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/02\\/Thumbnail-Customer-Order-Coupon-Export-updated.png\",\"excerpt\":\"Export customers, orders, and coupons from WooCommerce manually or on an automated schedule.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/ordercustomer-csv-export\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"914de15813a903c767b55445608bf290\",\"slug\":\"woocommerce-customer-order-csv-export\",\"id\":18652},{\"title\":\"Australia Post Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/australia-post.gif\",\"excerpt\":\"Get shipping rates for your WooCommerce store from the Australia Post API, which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/australia-post-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1dbd4dc6bd91a9cda1bd6b9e7a5e4f43\",\"slug\":\"woocommerce-shipping-australia-post\",\"id\":18622},{\"title\":\"Canada Post Shipping Method\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/canada-post.png\",\"excerpt\":\"Get shipping rates from the Canada Post Ratings API which handles both domestic and international parcels.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/canada-post-shipping-method\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"ac029cdf3daba20b20c7b9be7dc00e0e\",\"slug\":\"woocommerce-shipping-canada-post\",\"id\":18623},{\"title\":\"Product Vendors\",\"image\":\"\",\"excerpt\":\"Turn your store into a multi-vendor marketplace\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-vendors\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"a97d99fccd651bbdd728f4d67d492c31\",\"slug\":\"woocommerce-product-vendors\",\"id\":219982},{\"title\":\"WooCommerce Accommodation Bookings\",\"image\":\"\",\"excerpt\":\"Book accommodation using WooCommerce and the WooCommerce Bookings extension.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-accommodation-bookings\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"99b2a7a4af90b6cefd2a733b3b1f78e7\",\"slug\":\"woocommerce-accommodation-bookings\",\"id\":1412069},{\"title\":\"Smart Coupons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/10\\/wc-product-smart-coupons.png\",\"excerpt\":\"Everything you need for discounts, coupons, credits, gift cards, product giveaways, offers, and promotions. Most popular and complete coupons plugin for WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/smart-coupons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/demo.storeapps.org\\/?demo=sc\",\"price\":\"&#36;99.00\",\"hash\":\"05c45f2aa466106a466de4402fff9dde\",\"slug\":\"woocommerce-smart-coupons\",\"id\":18729},{\"title\":\"WooCommerce Brands\",\"image\":\"\",\"excerpt\":\"Create, assign and list brands for products, and allow customers to view by brand.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/brands\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"8a88c7cbd2f1e73636c331c7a86f818c\",\"slug\":\"woocommerce-brands\",\"id\":18737},{\"title\":\"Xero\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/08\\/xero2.png\",\"excerpt\":\"Save time with automated sync between WooCommerce and your Xero account.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/xero\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"f0dd29d338d3c67cf6cee88eddf6869b\",\"slug\":\"woocommerce-xero\",\"id\":18733},{\"title\":\"Royal Mail\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/04\\/royalmail.png\",\"excerpt\":\"Offer Royal Mail shipping rates to your customers\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/royal-mail\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"03839cca1a16c4488fcb669aeb91a056\",\"slug\":\"woocommerce-shipping-royalmail\",\"id\":182719},{\"title\":\"AutomateWoo\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-AutomateWoo-Dark-1.png\",\"excerpt\":\"Powerful marketing automation for WooCommerce. AutomateWoo has the tools you need to grow your store and make more money.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/automatewoo\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"ba9299b8-1dba-4aa0-a313-28bc1755cb88\",\"slug\":\"automatewoo\",\"id\":4652610},{\"title\":\"WooCommerce Zapier\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/woocommerce-zapier-logo.png\",\"excerpt\":\"Integrate with 3000+ cloud apps and services today.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-zapier\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;59.00\",\"hash\":\"0782bdbe932c00f4978850268c6cfe40\",\"slug\":\"woocommerce-zapier\",\"id\":243589},{\"title\":\"Advanced Notifications\",\"image\":\"\",\"excerpt\":\"Easily setup \\\"new order\\\" and stock email notifications for multiple recipients of your choosing.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/advanced-notifications\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"112372c44b002fea2640bd6bfafbca27\",\"slug\":\"woocommerce-advanced-notifications\",\"id\":18740},{\"title\":\"Dynamic Pricing\",\"image\":\"\",\"excerpt\":\"Bulk discounts, role-based pricing and much more\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/dynamic-pricing\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"9a41775bb33843f52c93c922b0053986\",\"slug\":\"woocommerce-dynamic-pricing\",\"id\":18643},{\"title\":\"WooCommerce Points and Rewards\",\"image\":\"\",\"excerpt\":\"Reward your customers for purchases and other actions with points which can be redeemed for discounts.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-points-and-rewards\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"1649b6cca5da8b923b01ca56b5cdd246\",\"slug\":\"woocommerce-points-and-rewards\",\"id\":210259},{\"title\":\"Name Your Price\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2012\\/09\\/nyp-icon-dark-v83owf.png\",\"excerpt\":\"Allow customers to define the product price. Also useful for accepting user-set donations.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/name-your-price\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"31b4e11696cd99a3c0572975a84f1c08\",\"slug\":\"woocommerce-name-your-price\",\"id\":18738},{\"title\":\"WooCommerce Print Invoices &amp; Packing lists\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/03\\/Thumbnail-Print-Invoices-Packing-lists-updated.png\",\"excerpt\":\"Generate invoices, packing slips, and pick lists for your WooCommerce orders.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/print-invoices-packing-lists\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"465de1126817cdfb42d97ebca7eea717\",\"slug\":\"woocommerce-pip\",\"id\":18666},{\"title\":\"WooCommerce Pre-Orders\",\"image\":\"\",\"excerpt\":\"Allow customers to order products before they are available.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-pre-orders\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"b2dc75e7d55e6f5bbfaccb59830f66b7\",\"slug\":\"woocommerce-pre-orders\",\"id\":178477},{\"title\":\"WooCommerce Subscription Downloads\",\"image\":\"\",\"excerpt\":\"Offer additional downloads to your subscribers, via downloadable products listed in your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-subscription-downloads\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"5be9e21c13953253e4406d2a700382ec\",\"slug\":\"woocommerce-subscription-downloads\",\"id\":420458},{\"title\":\"WooCommerce Additional Variation Images\",\"image\":\"\",\"excerpt\":\"Add gallery images per variation on variable products within WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-additional-variation-images\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/themes.woocommerce.com\\/storefront\\/product\\/woo-single-1\\/\",\"price\":\"&#36;49.00\",\"hash\":\"c61dd6de57dcecb32bd7358866de4539\",\"slug\":\"woocommerce-additional-variation-images\",\"id\":477384},{\"title\":\"WooCommerce Deposits\",\"image\":\"\",\"excerpt\":\"Enable customers to pay for products using a deposit or a payment plan.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-deposits\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;179.00\",\"hash\":\"de192a6cf12c4fd803248da5db700762\",\"slug\":\"woocommerce-deposits\",\"id\":977087},{\"title\":\"Google Product Feed\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2011\\/11\\/logo-regular-lscryp.png\",\"excerpt\":\"Feed product data to Google Merchant Center for setting up Google product listings &amp; product ads.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/google-product-feed\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"d55b4f852872025741312839f142447e\",\"slug\":\"woocommerce-product-feeds\",\"id\":18619},{\"title\":\"Amazon S3 Storage\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/09\\/amazon.png\",\"excerpt\":\"Serve digital products via Amazon S3\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/amazon-s3-storage\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"473bf6f221b865eff165c97881b473bb\",\"slug\":\"woocommerce-amazon-s3-storage\",\"id\":18663},{\"title\":\"Cart Add-ons\",\"image\":\"\",\"excerpt\":\"A powerful tool for driving incremental and impulse purchases by customers once they are in the shopping cart\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/cart-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"3a8ef25334396206f5da4cf208adeda3\",\"slug\":\"woocommerce-cart-add-ons\",\"id\":18717},{\"title\":\"Shipping Multiple Addresses\",\"image\":\"\",\"excerpt\":\"Allow your customers to ship individual items in a single order to multiple addresses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/shipping-multiple-addresses\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"aa0eb6f777846d329952d5b891d6f8cc\",\"slug\":\"woocommerce-shipping-multiple-addresses\",\"id\":18741},{\"title\":\"WooCommerce AvaTax\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/01\\/Thumbnail-Avalara-updated.png\",\"excerpt\":\"Get 100% accurate sales tax calculations and on time tax return filing. No more tracking sales tax rates, rules, or jurisdictional boundaries.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-avatax\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"57077a4b28ba71cacf692bcf4a1a7f60\",\"slug\":\"woocommerce-avatax\",\"id\":1389326},{\"title\":\"PayPal Payments Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Paypal-Payments-Pro-Dark.png\",\"excerpt\":\"Take credit card payments directly on your checkout using PayPal Pro.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/paypal-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6d23ba7f0e0198937c0029f9e865b40e\",\"slug\":\"woocommerce-gateway-paypal-pro\",\"id\":18594},{\"title\":\"Klarna Checkout\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2018\\/01\\/Partner_marketing_Klarna_Checkout_Black-1.png\",\"excerpt\":\"Klarna Checkout is a full checkout experience embedded on your site that includes all popular payment methods (Pay Now, Pay Later, Financing, Installments).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/klarna-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/demo.krokedil.se\\/klarnacheckout\\/\",\"price\":\"&#36;0.00\",\"hash\":\"90f8ce584e785fcd8c2d739fd4f40d78\",\"slug\":\"klarna-checkout-for-woocommerce\",\"id\":2754152},{\"title\":\"Gravity Forms Product Add-ons\",\"image\":\"\",\"excerpt\":\"Powerful product add-ons, Gravity style\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/gravity-forms-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/gravity-forms\\/\",\"price\":\"&#36;99.00\",\"hash\":\"a6ac0ab1a1536e3a357ccf24c0650ed0\",\"slug\":\"woocommerce-gravityforms-product-addons\",\"id\":18633},{\"title\":\"Bulk Stock Management\",\"image\":\"\",\"excerpt\":\"Edit product and variation stock levels in bulk via this handy interface\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/bulk-stock-management\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"02f4328d52f324ebe06a78eaaae7934f\",\"slug\":\"woocommerce-bulk-stock-management\",\"id\":18670},{\"title\":\"Composite Products\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-CP.png?v=1\",\"excerpt\":\"Create product kit builders and custom product configurators using existing products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/composite-products\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;99.00\",\"hash\":\"0343e0115bbcb97ccd98442b8326a0af\",\"slug\":\"woocommerce-composite-products\",\"id\":216836},{\"title\":\"WooCommerce Email Customizer\",\"image\":\"\",\"excerpt\":\"Connect with your customers with each email you send by visually modifying your email templates via the WordPress Customizer.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-email-customizer\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"bd909fa97874d431f203b5336c7e8873\",\"slug\":\"woocommerce-email-customizer\",\"id\":853277},{\"title\":\"TaxJar\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/10\\/taxjar-logotype.png\",\"excerpt\":\"Save hours every month by putting your sales tax on autopilot. Automated, multi-state sales tax calculation, reporting, and filing for your WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/taxjar\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"12072d8e-e933-4561-97b1-9db3c7eeed91\",\"slug\":\"taxjar-simplified-taxes-for-woocommerce\",\"id\":514914},{\"title\":\"Force Sells\",\"image\":\"\",\"excerpt\":\"Force products to be added to the cart\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/force-sells\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"3ebddfc491ca168a4ea4800b893302b0\",\"slug\":\"woocommerce-force-sells\",\"id\":18678},{\"title\":\"WooCommerce Quick View\",\"image\":\"\",\"excerpt\":\"Show a quick-view button to view product details and add to cart via lightbox popup\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-quick-view\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"619c6e57ce72c49c4b57e15b06eddb65\",\"slug\":\"woocommerce-quick-view\",\"id\":187509},{\"title\":\"WooCommerce Purchase Order Gateway\",\"image\":\"\",\"excerpt\":\"Receive purchase orders via your WooCommerce-powered online store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gateway-purchase-order\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"573a92318244ece5facb449d63e74874\",\"slug\":\"woocommerce-gateway-purchase-order\",\"id\":478542},{\"title\":\"Returns and Warranty Requests\",\"image\":\"\",\"excerpt\":\"Manage the RMA process, add warranties to products &amp; let customers request &amp; manage returns \\/ exchanges from their account.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/warranty-requests\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"9b4c41102e6b61ea5f558e16f9b63e25\",\"slug\":\"woocommerce-warranty\",\"id\":228315},{\"title\":\"Product Enquiry Form\",\"image\":\"\",\"excerpt\":\"Allow visitors to contact you directly from the product details page via a reCAPTCHA protected form to enquire about a product.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/product-enquiry-form\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"5a0f5d72519a8ffcc86669f042296937\",\"slug\":\"woocommerce-product-enquiry-form\",\"id\":18601},{\"title\":\"WooCommerce Box Office\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-BO-Dark.png\",\"excerpt\":\"Sell tickets for your next event, concert, function, fundraiser or conference directly on your own site\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-box-office\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"e704c9160de318216a8fa657404b9131\",\"slug\":\"woocommerce-box-office\",\"id\":1628717},{\"title\":\"WooCommerce Order Barcodes\",\"image\":\"\",\"excerpt\":\"Generates a unique barcode for each order on your site - perfect for e-tickets, packing slips, reservations and a variety of other uses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-barcodes\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"889835bb29ee3400923653e1e44a3779\",\"slug\":\"woocommerce-order-barcodes\",\"id\":391708},{\"title\":\"WooCommerce Paid Courses\",\"image\":\"\",\"excerpt\":\"Sell your online courses using the most popular eCommerce platform on the web \\u2013 WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-paid-courses\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"bad2a02a063555b7e2bee59924690763\",\"slug\":\"woothemes-sensei\",\"id\":152116},{\"title\":\"WooCommerce 360\\u00ba Image\",\"image\":\"\",\"excerpt\":\"An easy way to add a dynamic, controllable 360\\u00ba image rotation to your WooCommerce site, by adding a group of images to a product\\u2019s gallery.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-360-image\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"24eb2cfa3738a66bf3b2587876668cd2\",\"slug\":\"woocommerce-360-image\",\"id\":512186},{\"title\":\"WooCommerce Photography\",\"image\":\"\",\"excerpt\":\"Sell photos in the blink of an eye using this simple as dragging &amp; dropping interface.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-photography\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"ee76e8b9daf1d97ca4d3874cc9e35687\",\"slug\":\"woocommerce-photography\",\"id\":583602},{\"title\":\"WooCommerce Bookings Availability\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/06\\/Logo-Woo-Bookings-Aval-Dark.png\",\"excerpt\":\"Sell more bookings by presenting a calendar or schedule of available slots in a page or post.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/bookings-availability\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"30770d2a-e392-4e82-baaa-76cfc7d02ae3\",\"slug\":\"woocommerce-bookings-availability\",\"id\":4228225},{\"title\":\"Software Add-on\",\"image\":\"\",\"excerpt\":\"Sell License Keys for Software\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/software-add-on\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;129.00\",\"hash\":\"79f6dbfe1f1d3a56a86f0509b6d6b04b\",\"slug\":\"woocommerce-software-add-on\",\"id\":18683},{\"title\":\"WooCommerce Products Compare\",\"image\":\"\",\"excerpt\":\"WooCommerce Products Compare will allow your potential customers to easily compare products within your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-products-compare\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"c3ba0a4a3199a0cc7a6112eb24414548\",\"slug\":\"woocommerce-products-compare\",\"id\":853117},{\"title\":\"WooCommerce Store Catalog PDF Download\",\"image\":\"\",\"excerpt\":\"Offer your customers a PDF download of your product catalog, generated by WooCommerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-store-catalog-pdf-download\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"79ca7aadafe706364e2d738b7c1090c4\",\"slug\":\"woocommerce-store-catalog-pdf-download\",\"id\":675790},{\"title\":\"eWAY\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2011\\/10\\/eway-logo-3000-2000.jpg\",\"excerpt\":\"Take credit card payments securely via eWay (SG, MY, HK, AU, and NZ) keeping customers on your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/eway\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"2c497769d98d025e0d340cd0b5ea5da1\",\"slug\":\"woocommerce-gateway-eway\",\"id\":18604},{\"title\":\"Catalog Visibility Options\",\"image\":\"\",\"excerpt\":\"Transform WooCommerce into an online catalog by removing eCommerce functionality\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/catalog-visibility-options\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"12e791110365fdbb5865c8658907967e\",\"slug\":\"woocommerce-catalog-visibility-options\",\"id\":18648},{\"title\":\"WooCommerce Blocks\",\"image\":\"\",\"excerpt\":\"WooCommerce Blocks offers a range of Gutenberg blocks you can use to build and customise your site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-gutenberg-products-block\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"c2e9f13a-f90c-4ffe-a8a5-b432399ec263\",\"slug\":\"woo-gutenberg-products-block\",\"id\":3076677},{\"title\":\"Sequential Order Numbers Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/05\\/Thumbnail-Sequential-Order-Numbers-Pro-updated.png\",\"excerpt\":\"Tame your order numbers! Advanced &amp; sequential order numbers with optional prefixes \\/ suffixes\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/sequential-order-numbers-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"0b18a2816e016ba9988b93b1cd8fe766\",\"slug\":\"woocommerce-sequential-order-numbers-pro\",\"id\":18688},{\"title\":\"Conditional Shipping and Payments\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2020\\/07\\/Logo-CSP.png?v=1\",\"excerpt\":\"Use conditional logic to restrict the shipping and payment options available on your store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/conditional-shipping-and-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"1f56ff002fa830b77017b0107505211a\",\"slug\":\"woocommerce-conditional-shipping-and-payments\",\"id\":680253},{\"title\":\"WooCommerce Order Status Manager\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2015\\/02\\/Thumbnail-Order-Status-Manager-updated.png\",\"excerpt\":\"Create, edit, and delete completely custom order statuses and integrate them seamlessly into your order management flow.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-status-manager\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;49.00\",\"hash\":\"51fd9ab45394b4cad5a0ebf58d012342\",\"slug\":\"woocommerce-order-status-manager\",\"id\":588398},{\"title\":\"WooCommerce Checkout Add-Ons\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/07\\/Thumbnail-Checkout-Add-Ons-updated.png\",\"excerpt\":\"Highlight relevant products, offers like free shipping and other up-sells during checkout.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-checkout-add-ons\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"8fdca00b4000b7a8cc26371d0e470a8f\",\"slug\":\"woocommerce-checkout-add-ons\",\"id\":466854},{\"title\":\"WooCommerce Google Analytics Pro\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2016\\/01\\/Thumbnail-GAPro-updated.png\",\"excerpt\":\"Add advanced event tracking and enhanced eCommerce tracking to your WooCommerce site.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-google-analytics-pro\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"d8aed8b7306b509eec1589e59abe319f\",\"slug\":\"woocommerce-google-analytics-pro\",\"id\":1312497},{\"title\":\"QuickBooks Sync for WooCommerce\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2019\\/04\\/woocommerce-com-logo-1-hyhzbh.png\",\"excerpt\":\"Automatic two-way sync for orders, customers, products, inventory and more between WooCommerce and QuickBooks (Online, Desktop, or POS).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/quickbooks-sync-for-woocommerce\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"c5e32e20-7c1f-4585-8b15-d930c2d842ac\",\"slug\":\"myworks-woo-sync-for-quickbooks-online\",\"id\":4065824},{\"title\":\"WooCommerce One Page Checkout\",\"image\":\"\",\"excerpt\":\"Create special pages where customers can choose products, checkout &amp; pay all on the one page.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-one-page-checkout\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"c9ba8f8352cd71b5508af5161268619a\",\"slug\":\"woocommerce-one-page-checkout\",\"id\":527886},{\"title\":\"WooCommerce Product Search\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2014\\/10\\/woocommerce-product-search-product-image-1870x960-1-jvsljj.png\",\"excerpt\":\"The perfect search engine helps customers to find and buy products quickly \\u2013 essential for every WooCommerce store.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-product-search\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/demo.itthinx.com\\/wps\\/\",\"price\":\"&#36;49.00\",\"hash\":\"c84cc8ca16ddac3408e6b6c5871133a8\",\"slug\":\"woocommerce-product-search\",\"id\":512174},{\"title\":\"First Data\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2012\\/02\\/Thumbnail-FirstData-updated.png\",\"excerpt\":\"FirstData gateway for WooCommerce\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/firstdata\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"eb3e32663ec0810592eaf0d097796230\",\"slug\":\"woocommerce-gateway-firstdata\",\"id\":18645},{\"title\":\"WooSlider\",\"image\":\"\",\"excerpt\":\"WooSlider is the ultimate responsive slideshow WordPress slider plugin\\r\\n\\r\\n\\u00a0\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/wooslider\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/www.wooslider.com\\/\",\"price\":\"&#36;49.00\",\"hash\":\"209d98f3ccde6cc3de7e8732a2b20b6a\",\"slug\":\"wooslider\",\"id\":46506},{\"title\":\"WooCommerce Social Login\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/08\\/Thumbnail-Social-Login-updated.png\",\"excerpt\":\"Enable Social Login for seamless checkout and account creation.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-social-login\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"http:\\/\\/demos.skyverge.com\\/woocommerce-social-login\\/\",\"price\":\"&#36;79.00\",\"hash\":\"b231cd6367a79cc8a53b7d992d77525d\",\"slug\":\"woocommerce-social-login\",\"id\":473617},{\"title\":\"Coupon Shortcodes\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2013\\/09\\/woocommerce-coupon-shortcodes-product-image-1870x960-1-vc5gux.png\",\"excerpt\":\"Show coupon discount info using shortcodes. Allows to render coupon information and content conditionally, based on the validity of coupons.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/coupon-shortcodes\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"ac5d9d51-70b2-4d8f-8b89-24200eea1394\",\"slug\":\"woocommerce-coupon-shortcodes\",\"id\":244762},{\"title\":\"WooCommerce Order Status Control\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2014\\/06\\/Thumbnail-Order-Status-Control-updated.png\",\"excerpt\":\"Use this extension to automatically change the order status to \\\"completed\\\" after successful payment.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-order-status-control\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"32400e509c7c36dcc1cd368e8267d981\",\"slug\":\"woocommerce-order-status-control\",\"id\":439037},{\"title\":\"Variation Swatches and Photos\",\"image\":\"\",\"excerpt\":\"Show color and image swatches instead of dropdowns for variable products.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/variation-swatches-and-photos\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"https:\\/\\/www.elementstark.com\\/woocommerce-extension-demos\\/product-category\\/swatches-and-photos\\/\",\"price\":\"&#36;99.00\",\"hash\":\"37bea8d549df279c8278878d081b062f\",\"slug\":\"woocommerce-variation-swatches-and-photos\",\"id\":18697},{\"title\":\"Jilt\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2017\\/12\\/Thumbnail-Jilt-updated.png\",\"excerpt\":\"All-in-one email marketing platform built for WooCommerce stores. Send newsletters, abandoned cart reminders, win-backs, welcome automations, and more.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/jilt\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"b53aafb64dca33835e41ee06de7e9816\",\"slug\":\"jilt-for-woocommerce\",\"id\":2754876},{\"title\":\"Opayo Payment Suite\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2011\\/10\\/Opayo_logo_RGB.png\",\"excerpt\":\"Take payments on your WooCommerce store via Opayo (formally SagePay).\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/sage-pay-form\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;79.00\",\"hash\":\"6bc0cca47d0274d8ef9b164f6fbec1cc\",\"slug\":\"woocommerce-gateway-sagepay-form\",\"id\":18599},{\"title\":\"EU VAT Number\",\"image\":\"\",\"excerpt\":\"Collect VAT numbers at checkout and remove the VAT charge for eligible EU businesses.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/eu-vat-number\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;29.00\",\"hash\":\"d2720c4b4bb8d6908e530355b7a2d734\",\"slug\":\"woocommerce-eu-vat-number\",\"id\":18592},{\"title\":\"PayPal\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/woocommerce_uploads\\/2020\\/10\\/PPCP-Tile-PayPal-Logo-and-Cart-Art-2x-2-uozwz8.jpg\",\"excerpt\":\"PayPal\\u2019s latest, most complete payment processing solution. Accept PayPal exclusives, credit\\/debit cards and local payment methods. Turn on only PayPal options or process a full suite of payment methods. Enable global transactions with extensive currency and country coverage. Built and supported by WooCommerce and PayPal.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-paypal-payments\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"934115ab-e3f3-4435-9580-345b1ce21899\",\"slug\":\"woocommerce-paypal-payments\",\"id\":6410731},{\"title\":\"QuickBooks Commerce (formerly TradeGecko)\",\"image\":\"https:\\/\\/woocommerce.com\\/wp-content\\/uploads\\/2013\\/09\\/qbo-mark.png\",\"excerpt\":\"Get a wholesale and multichannel inventory &amp; order management platform for your WooCommerce store with QuickBooks Commerce.\",\"link\":\"https:\\/\\/woocommerce.com\\/products\\/woocommerce-tradegecko\\/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\",\"demo_url\":\"\",\"price\":\"&#36;0.00\",\"hash\":\"21da7811f7fc1f13ee19daa7415f0ff3\",\"slug\":\"woocommerce-tradegecko\",\"id\":245960}]}\";s:7:\"headers\";O:25:\"Requests_Response_Headers\":1:{s:7:\"\0*\0data\";a:18:{s:6:\"server\";a:1:{i:0;s:5:\"nginx\";}s:4:\"date\";a:1:{i:0;s:29:\"Tue, 01 Jun 2021 09:29:44 GMT\";}s:12:\"content-type\";a:1:{i:0;s:31:\"application/json; charset=UTF-8\";}s:14:\"content-length\";a:1:{i:0;s:5:\"11636\";}s:12:\"x-robots-tag\";a:1:{i:0;s:7:\"noindex\";}s:4:\"link\";a:1:{i:0;s:60:\"<https://woocommerce.com/wp-json/>; rel=\"https://api.w.org/\"\";}s:22:\"x-content-type-options\";a:1:{i:0;s:7:\"nosniff\";}s:29:\"access-control-expose-headers\";a:1:{i:0;s:33:\"X-WP-Total, X-WP-TotalPages, Link\";}s:28:\"access-control-allow-headers\";a:1:{i:0;s:73:\"Authorization, X-WP-Nonce, Content-Disposition, Content-MD5, Content-Type\";}s:13:\"x-wccom-cache\";a:1:{i:0;s:3:\"HIT\";}s:13:\"cache-control\";a:1:{i:0;s:10:\"max-age=60\";}s:5:\"allow\";a:1:{i:0;s:3:\"GET\";}s:16:\"content-encoding\";a:1:{i:0;s:4:\"gzip\";}s:4:\"x-rq\";a:1:{i:0;s:16:\"ams5 85 167 3131\";}s:3:\"age\";a:1:{i:0;s:2:\"27\";}s:7:\"x-cache\";a:1:{i:0;s:3:\"hit\";}s:4:\"vary\";a:1:{i:0;s:23:\"Accept-Encoding, Origin\";}s:13:\"accept-ranges\";a:1:{i:0;s:5:\"bytes\";}}}s:11:\"status_code\";i:200;s:16:\"protocol_version\";d:1.1;s:7:\"success\";b:1;s:9:\"redirects\";i:0;s:3:\"url\";s:59:\"https://woocommerce.com/wp-json/wccom-extensions/1.0/search\";s:7:\"history\";a:0:{}s:7:\"cookies\";O:19:\"Requests_Cookie_Jar\":1:{s:10:\"\0*\0cookies\";a:0:{}}}s:11:\"\0*\0filename\";N;s:4:\"data\";N;s:7:\"headers\";N;s:6:\"status\";N;}}","no"),
("563","_site_transient_timeout_browser_ef57a61c62d6cd20b9737b90f53f775b","1623148732","no"),
("564","_site_transient_browser_ef57a61c62d6cd20b9737b90f53f775b","a:10:{s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"89.0\";s:8:\"platform\";s:9:\"Macintosh\";s:10:\"update_url\";s:32:\"https://www.mozilla.org/firefox/\";s:7:\"img_src\";s:44:\"http://s.w.org/images/browsers/firefox.png?1\";s:11:\"img_src_ssl\";s:45:\"https://s.w.org/images/browsers/firefox.png?1\";s:15:\"current_version\";s:2:\"56\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no"),
("565","themeisle_sdk_notifications","a:2:{s:17:\"last_notification\";a:2:{s:2:\"id\";s:16:\"neve_logger_flag\";s:10:\"display_at\";i:1622543932;}s:24:\"last_notification_active\";i:1622543946;}","yes"),
("566","_transient_timeout_wc_report_orders_stats_b8c9b2c0e0d0170ba07a277a32411fb7","1623148732","no"),
("567","_transient_wc_report_orders_stats_b8c9b2c0e0d0170ba07a277a32411fb7","a:2:{s:7:\"version\";s:10:\"1619687030\";s:5:\"value\";O:8:\"stdClass\":5:{s:6:\"totals\";O:8:\"stdClass\":15:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"products\";i:0;s:8:\"segments\";a:0:{}}s:9:\"intervals\";a:1:{i:0;a:6:{s:8:\"interval\";s:7:\"2021-22\";s:10:\"date_start\";s:19:\"2021-06-01 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2021-06-01 00:00:00\";s:8:\"date_end\";s:19:\"2021-06-01 23:59:59\";s:12:\"date_end_gmt\";s:19:\"2021-06-01 23:59:59\";s:9:\"subtotals\";O:8:\"stdClass\":14:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"segments\";a:0:{}}}}s:5:\"total\";i:1;s:5:\"pages\";i:1;s:7:\"page_no\";i:1;}}","no"),
("568","_transient_timeout_wc_report_orders_stats_85ec71cd55d00e327c55d624ca9e63c3","1623148732","no"),
("569","_transient_wc_report_orders_stats_85ec71cd55d00e327c55d624ca9e63c3","a:2:{s:7:\"version\";s:10:\"1619687030\";s:5:\"value\";O:8:\"stdClass\":5:{s:6:\"totals\";O:8:\"stdClass\":15:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"products\";i:0;s:8:\"segments\";a:0:{}}s:9:\"intervals\";a:1:{i:0;a:6:{s:8:\"interval\";s:7:\"2021-22\";s:10:\"date_start\";s:19:\"2021-06-01 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2021-06-01 00:00:00\";s:8:\"date_end\";s:19:\"2021-06-01 23:59:59\";s:12:\"date_end_gmt\";s:19:\"2021-06-01 23:59:59\";s:9:\"subtotals\";O:8:\"stdClass\":14:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"segments\";a:0:{}}}}s:5:\"total\";i:1;s:5:\"pages\";i:1;s:7:\"page_no\";i:1;}}","no"),
("570","_transient_timeout_wc_report_orders_stats_1c97045d8fb054a5c23d471b6b3eec43","1623148732","no"),
("571","_transient_wc_report_orders_stats_1c97045d8fb054a5c23d471b6b3eec43","a:2:{s:7:\"version\";s:10:\"1619687030\";s:5:\"value\";O:8:\"stdClass\":5:{s:6:\"totals\";O:8:\"stdClass\":4:{s:11:\"net_revenue\";d:0;s:8:\"products\";i:0;s:13:\"coupons_count\";i:0;s:8:\"segments\";a:0:{}}s:9:\"intervals\";a:7:{i:0;a:6:{s:8:\"interval\";s:10:\"2021-05-26\";s:10:\"date_start\";s:19:\"2021-05-26 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2021-05-26 00:00:00\";s:8:\"date_end\";s:19:\"2021-05-26 23:59:59\";s:12:\"date_end_gmt\";s:19:\"2021-05-26 23:59:59\";s:9:\"subtotals\";O:8:\"stdClass\":3:{s:11:\"net_revenue\";d:0;s:13:\"coupons_count\";i:0;s:8:\"segments\";a:0:{}}}i:1;a:6:{s:8:\"interval\";s:10:\"2021-05-27\";s:10:\"date_start\";s:19:\"2021-05-27 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2021-05-27 00:00:00\";s:8:\"date_end\";s:19:\"2021-05-27 23:59:59\";s:12:\"date_end_gmt\";s:19:\"2021-05-27 23:59:59\";s:9:\"subtotals\";O:8:\"stdClass\":3:{s:11:\"net_revenue\";d:0;s:13:\"coupons_count\";i:0;s:8:\"segments\";a:0:{}}}i:2;a:6:{s:8:\"interval\";s:10:\"2021-05-28\";s:10:\"date_start\";s:19:\"2021-05-28 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2021-05-28 00:00:00\";s:8:\"date_end\";s:19:\"2021-05-28 23:59:59\";s:12:\"date_end_gmt\";s:19:\"2021-05-28 23:59:59\";s:9:\"subtotals\";O:8:\"stdClass\":3:{s:11:\"net_revenue\";d:0;s:13:\"coupons_count\";i:0;s:8:\"segments\";a:0:{}}}i:3;a:6:{s:8:\"interval\";s:10:\"2021-05-29\";s:10:\"date_start\";s:19:\"2021-05-29 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2021-05-29 00:00:00\";s:8:\"date_end\";s:19:\"2021-05-29 23:59:59\";s:12:\"date_end_gmt\";s:19:\"2021-05-29 23:59:59\";s:9:\"subtotals\";O:8:\"stdClass\":3:{s:11:\"net_revenue\";d:0;s:13:\"coupons_count\";i:0;s:8:\"segments\";a:0:{}}}i:4;a:6:{s:8:\"interval\";s:10:\"2021-05-30\";s:10:\"date_start\";s:19:\"2021-05-30 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2021-05-30 00:00:00\";s:8:\"date_end\";s:19:\"2021-05-30 23:59:59\";s:12:\"date_end_gmt\";s:19:\"2021-05-30 23:59:59\";s:9:\"subtotals\";O:8:\"stdClass\":3:{s:11:\"net_revenue\";d:0;s:13:\"coupons_count\";i:0;s:8:\"segments\";a:0:{}}}i:5;a:6:{s:8:\"interval\";s:10:\"2021-05-31\";s:10:\"date_start\";s:19:\"2021-05-31 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2021-05-31 00:00:00\";s:8:\"date_end\";s:19:\"2021-05-31 23:59:59\";s:12:\"date_end_gmt\";s:19:\"2021-05-31 23:59:59\";s:9:\"subtotals\";O:8:\"stdClass\":3:{s:11:\"net_revenue\";d:0;s:13:\"coupons_count\";i:0;s:8:\"segments\";a:0:{}}}i:6;a:6:{s:8:\"interval\";s:10:\"2021-06-01\";s:10:\"date_start\";s:19:\"2021-06-01 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2021-06-01 00:00:00\";s:8:\"date_end\";s:19:\"2021-06-01 23:59:59\";s:12:\"date_end_gmt\";s:19:\"2021-06-01 23:59:59\";s:9:\"subtotals\";O:8:\"stdClass\":3:{s:11:\"net_revenue\";d:0;s:13:\"coupons_count\";i:0;s:8:\"segments\";a:0:{}}}}s:5:\"total\";i:7;s:5:\"pages\";i:1;s:7:\"page_no\";i:1;}}","no"),
("572","_transient_timeout_wc_low_stock_count","1625135932","no"),
("573","_transient_wc_low_stock_count","0","no"),
("574","_transient_timeout_wc_outofstock_count","1625135932","no"),
("575","_transient_wc_outofstock_count","0","no"),
("578","_site_transient_timeout_community-events-1aecf33ab8525ff212ebdffbb438372e","1622587135","no"),
("579","_site_transient_community-events-1aecf33ab8525ff212ebdffbb438372e","a:4:{s:9:\"sandboxed\";b:0;s:5:\"error\";N;s:8:\"location\";a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}s:6:\"events\";a:7:{i:0;a:10:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:60:\"Watch Party + Discussion Group: Intro to the Block Directory\";s:3:\"url\";s:68:\"https://www.meetup.com/learn-wordpress-discussions/events/278272711/\";s:6:\"meetup\";s:27:\"Learn WordPress Discussions\";s:10:\"meetup_url\";s:51:\"https://www.meetup.com/learn-wordpress-discussions/\";s:4:\"date\";s:19:\"2021-06-04 19:00:00\";s:8:\"end_date\";s:19:\"2021-06-04 21:00:00\";s:20:\"start_unix_timestamp\";i:1622858400;s:18:\"end_unix_timestamp\";i:1622865600;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"US\";s:8:\"latitude\";d:37.779998779297;s:9:\"longitude\";d:-122.41999816895;}}i:1;a:10:{s:4:\"type\";s:8:\"wordcamp\";s:5:\"title\";s:15:\"WordCamp Europe\";s:3:\"url\";s:33:\"https://europe.wordcamp.org/2021/\";s:6:\"meetup\";N;s:10:\"meetup_url\";N;s:4:\"date\";s:19:\"2021-06-07 14:00:00\";s:8:\"end_date\";s:19:\"2021-06-09 00:00:00\";s:20:\"start_unix_timestamp\";i:1623070800;s:18:\"end_unix_timestamp\";i:1623193200;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"PT\";s:8:\"latitude\";d:41.1579438;s:9:\"longitude\";d:-8.6291053;}}i:2;a:10:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:23:\"WordPress Meetup Zwolle\";s:3:\"url\";s:68:\"https://www.meetup.com/Zwolle-WordPress-Meetup/events/nsmmmryccjbnb/\";s:6:\"meetup\";s:23:\"WordPress Meetup Zwolle\";s:10:\"meetup_url\";s:47:\"https://www.meetup.com/Zwolle-WordPress-Meetup/\";s:4:\"date\";s:19:\"2021-06-10 18:45:00\";s:8:\"end_date\";s:19:\"2021-06-10 20:55:00\";s:20:\"start_unix_timestamp\";i:1623343500;s:18:\"end_unix_timestamp\";i:1623351300;s:8:\"location\";a:4:{s:8:\"location\";s:19:\"Zwolle, Netherlands\";s:7:\"country\";s:2:\"nl\";s:8:\"latitude\";d:52.508583068848;s:9:\"longitude\";d:6.0933017730713;}}i:3;a:10:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:43:\"WordPress Meetup Nijmegen: To be announced.\";s:3:\"url\";s:66:\"https://www.meetup.com/WordPress-Meetup-Nijmegen/events/277572569/\";s:6:\"meetup\";s:25:\"WordPress Meetup Nijmegen\";s:10:\"meetup_url\";s:49:\"https://www.meetup.com/WordPress-Meetup-Nijmegen/\";s:4:\"date\";s:19:\"2021-06-16 20:00:00\";s:8:\"end_date\";s:19:\"2021-06-16 22:00:00\";s:20:\"start_unix_timestamp\";i:1623866400;s:18:\"end_unix_timestamp\";i:1623873600;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"NL\";s:8:\"latitude\";d:51.840000152588;s:9:\"longitude\";d:5.8499999046326;}}i:4;a:10:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:23:\"WordPress Meetup Zwolle\";s:3:\"url\";s:68:\"https://www.meetup.com/Zwolle-WordPress-Meetup/events/nsmmmrycckblb/\";s:6:\"meetup\";s:23:\"WordPress Meetup Zwolle\";s:10:\"meetup_url\";s:47:\"https://www.meetup.com/Zwolle-WordPress-Meetup/\";s:4:\"date\";s:19:\"2021-07-08 18:45:00\";s:8:\"end_date\";s:19:\"2021-07-08 20:55:00\";s:20:\"start_unix_timestamp\";i:1625762700;s:18:\"end_unix_timestamp\";i:1625770500;s:8:\"location\";a:4:{s:8:\"location\";s:19:\"Zwolle, Netherlands\";s:7:\"country\";s:2:\"nl\";s:8:\"latitude\";d:52.508583068848;s:9:\"longitude\";d:6.0933017730713;}}i:5;a:10:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:23:\"WordPress Meetup Zwolle\";s:3:\"url\";s:68:\"https://www.meetup.com/Zwolle-WordPress-Meetup/events/nsmmmrycclbqb/\";s:6:\"meetup\";s:23:\"WordPress Meetup Zwolle\";s:10:\"meetup_url\";s:47:\"https://www.meetup.com/Zwolle-WordPress-Meetup/\";s:4:\"date\";s:19:\"2021-08-12 18:45:00\";s:8:\"end_date\";s:19:\"2021-08-12 20:55:00\";s:20:\"start_unix_timestamp\";i:1628786700;s:18:\"end_unix_timestamp\";i:1628794500;s:8:\"location\";a:4:{s:8:\"location\";s:19:\"Zwolle, Netherlands\";s:7:\"country\";s:2:\"nl\";s:8:\"latitude\";d:52.508583068848;s:9:\"longitude\";d:6.0933017730713;}}i:6;a:10:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:23:\"WordPress Meetup Zwolle\";s:3:\"url\";s:68:\"https://www.meetup.com/Zwolle-WordPress-Meetup/events/nsmmmryccmbmb/\";s:6:\"meetup\";s:23:\"WordPress Meetup Zwolle\";s:10:\"meetup_url\";s:47:\"https://www.meetup.com/Zwolle-WordPress-Meetup/\";s:4:\"date\";s:19:\"2021-09-09 18:45:00\";s:8:\"end_date\";s:19:\"2021-09-09 20:55:00\";s:20:\"start_unix_timestamp\";i:1631205900;s:18:\"end_unix_timestamp\";i:1631213700;s:8:\"location\";a:4:{s:8:\"location\";s:19:\"Zwolle, Netherlands\";s:7:\"country\";s:2:\"nl\";s:8:\"latitude\";d:52.508583068848;s:9:\"longitude\";d:6.0933017730713;}}}}","no"),
("580","_transient_timeout_feed_c326b61060938210a1df3d05d623467e","1622587135","no"),
("581","_transient_feed_c326b61060938210a1df3d05d623467e","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Blog | WordPress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"https://nl.wordpress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 10 Mar 2021 09:48:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"nl\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=5.8-alpha-51050\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:74:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		

			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:8:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 5.7 is vrijgegeven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://nl.wordpress.org/2021/03/10/wordpress-5-7-is-vrijgegeven/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://nl.wordpress.org/2021/03/10/wordpress-5-7-is-vrijgegeven/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 10 Mar 2021 08:15:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://nl.wordpress.org/?p=1149\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:316:\"Fleur je verhalen op in een editor die schoner en scherper is en meer uit de weg gaat. Verken WordPress 5.7. Met deze nieuwe versie brengt WordPress je frisse kleuren. De editor helpt je te werken op een paar plaatsen waar dat voorheen niet mogelijk was—tenminste, niet zonder in de code te duiken of een [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"enclosure\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:60:\"https://s.w.org/images/core/5.7/about-57-drag-drop-image.mp4\";s:6:\"length\";s:6:\"183815\";s:4:\"type\";s:9:\"video/mp4\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Remkus de Vries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5906:\"
<p>Fleur je verhalen op in een editor die schoner en scherper is en meer uit de weg gaat.</p>



<h2>Verken WordPress 5.7.</h2>



<p>Met deze nieuwe versie brengt WordPress je frisse kleuren. De editor helpt je te werken op een paar plaatsen waar dat voorheen niet mogelijk was—tenminste, niet zonder in de code te duiken of een professional in te huren. De bedieningselementen die je het meest gebruikt, zoals het wijzigen van de lettertype grootte, zijn op meer plaatsen te vinden—precies waar je ze nodig hebt. En lay-out wijzigingen die eenvoudig zouden moeten zijn, zoals volledige-hoogte afbeeldingen, zijn nu nog eenvoudiger uit te voeren.</p>



<span id=\"more-1149\"></span>



<h2>De editor is nu makkelijker te gebruiken</h2>



<p><strong>Aanpassing van lettertypegrootte op meer plaatsen:</strong>&nbsp;nu zijn de besturingselementen voor lettertypegrootte precies daar waar je ze nodig hebt in de lijst- en codeblokken. Je hoeft niet meer naar een ander scherm te gaan om die ene wijziging aan te brengen!</p>



<p><strong>Herbruikbare blokken:</strong>&nbsp;verschillende verbeteringen maken herbruikbare blokken stabieler en gemakkelijker te gebruiken. En nu slaan ze automatisch op met het bericht wanneer je op de knop Update klikt.</p>



<p><strong>Inserter verslepen:</strong> sleep blokken en blokpatronen van de inserter rechtstreeks naar je bericht.</p>



<figure class=\"wp-block-embed is-type-rich is-provider-insluiten-handler wp-block-embed-insluiten-handler\"><div class=\"wp-block-embed__wrapper\">
<div style=\"width: 612px;\" class=\"wp-video\"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<video class=\"wp-video-shortcode\" id=\"video-1149-1\" width=\"612\" height=\"344\" preload=\"metadata\" controls=\"controls\"><source type=\"video/mp4\" src=\"https://s.w.org/images/core/5.7/about-57-drag-drop-image.mp4?_=1\" /><a href=\"https://s.w.org/images/core/5.7/about-57-drag-drop-image.mp4\">https://s.w.org/images/core/5.7/about-57-drag-drop-image.mp4</a></video></div>
</div></figure>



<h2>Je kunt meer doen zonder het schrijven van aangepaste code</h2>



<p><strong>Uitlijning op volledige hoogte:</strong>&nbsp;heb je ooit een blok willen maken, zoals het cover-blok, om het hele venster te vullen? Nu kan je dat.</p>



<p><strong>Knoppen blok:</strong>&nbsp;je kunt nu kiezen voor een verticale of horizontale lay-out. En je kunt de breedte van een knop instellen op een vooraf ingesteld percentage.</p>



<p><strong>Sociale pictogrammen blok: </strong>je kunt nu de grootte van de pictogrammen wijzigen.</p>



<figure class=\"wp-block-image size-large\"><img src=\"https://i0.wp.com/s.w.org/images/core/5.7/about-57-cover.jpg\" alt=\"\" /></figure>



<h2>Een eenvoudiger standaard kleurenpalet</h2>



<figure class=\"wp-block-jetpack-image-compare\"><div class=\"juxtapose\" data-mode=\"horizontal\"><img loading=\"lazy\" id=\"1155\" src=\"https://nl.wordpress.org/files/2021/03/about-57-color-old.png\" alt=\"\" width=\"2000\" height=\"1334\" class=\"image-compare__image-before\" /><img loading=\"lazy\" id=\"1156\" src=\"https://nl.wordpress.org/files/2021/03/about-57-color-new.png\" alt=\"\" width=\"2000\" height=\"1334\" class=\"image-compare__image-after\" /></div><figcaption>Hierboven het Dashboard voor en na de kleurenupdate in 5.7.<br></figcaption></figure>



<p>In dit nieuwe gestroomlijnde kleurenpalet worden alle kleuren die vroeger in de WordPress broncode zaten samengevouwen tot zeven core kleuren en een reeks van 56 tinten die voldoen aan de door&nbsp;<a href=\"https://www.w3.org/WAI/WCAG2AAA-Conformance\">WCAG 2.0 AA aanbevolen contrastverhouding</a>&nbsp;tegen wit of zwart.</p>



<p>De kleuren zijn perceptueel uniform van licht tot donker in elk bereik, wat betekent dat ze bij wit beginnen en bij elke stap even veel donkerder worden.</p>



<p>De helft van het bereik heeft een contrastverhouding van 4,5 of hoger tegen zwart, en de andere helft behoudt hetzelfde contrast tegen wit.</p>



<p>Zoek het nieuwe palet in het standaardkleurenschema van WordPress Dashboard en gebruik het bij het bouwen van thema&#8217;s, plugins of andere componenten. Voor alle details,&nbsp;<a href=\"https://make.wordpress.org/core/2021/02/23/standardization-of-wp-admin-colors-in-wordpress-5-7\">bekijk de ontwikkelaar kleurpalet opmerkingen</a>.</p>



<h3>Van HTTP naar HTTPS met een enkele klik</h3>



<p>Vanaf nu is het omzetten van een site van HTTP naar HTTPS een beweging met één klik. WordPress werkt de database URL&#8217;s automatisch bij wanneer je de overstap maakt. Nooit meer jagen en gissen!</p>



<h3>Nieuwe Robots API</h3>



<p>Met de nieuwe Robots API kun je de filter richtlijnen opnemen in de robots metatag, en de API bevat standaard de&nbsp;<code>max-image-preview: large</code>&nbsp;richtlijn. Dat betekent dat zoekmachines grotere afbeelding voorbeelden kunnen tonen, wat je verkeer kan stimuleren (maar niet als de site is gemarkeerd als&nbsp;<em>niet-openbaar</em>).</p>



<h3>Doorlopende schoonmaak na de update naar jQuery 3.5.1</h3>



<p>JQuery heeft jarenlang geholpen om dingen op het scherm te laten bewegen op manieren die de basistools niet konden, maar dat blijft veranderen, en dat geldt ook voor jQuery.</p>



<p>In 5.7 wordt jQuery meer gefocust en minder opdringerig, met minder berichten in de console.</p>



<h3>Lazy-load je iframes</h3>



<p>Het is nu eenvoudig om iframes ook lazy-load te laden. Standaard voegt WordPress het&nbsp;<code>loading=\"lazy\"</code>&nbsp;attribuut toe aan iframe tags wanneer zowel breedte als hoogte zijn opgegeven.</p>



<hr class=\"wp-block-separator\" />



<h3>Bekijk de Field Guide voor meer informatie!</h3>



<p>Bekijk de nieuwste versie van de WordPress Field Guide. Het heeft opmerkingen van ontwikkelaars voor elke wijziging waarvan je op de hoogte wilt zijn:&nbsp;<a href=\"https://make.wordpress.org/core/2021/02/23/wordpress-5-7-field-guide\">WordPress 5.7 Field Guide</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://nl.wordpress.org/2021/03/10/wordpress-5-7-is-vrijgegeven/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:73:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 5.6 is vrijgegeven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://nl.wordpress.org/2020/12/08/wordpress-5-6-is-vrijgegeven/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://nl.wordpress.org/2020/12/08/wordpress-5-6-is-vrijgegeven/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 08 Dec 2020 22:23:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://nl.wordpress.org/?p=1143\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:347:\"Het delen van je verhalen is nog nooit zo eenvoudig geweest. WordPress 5.6 biedt je talloze manieren om je ideeën de vrije loop te laten en ze tot leven te brengen. Met een gloednieuw standaardthema als je canvas, ondersteunt het een steeds groter wordende verzameling blokken als je penselen. Verf met woorden. Afbeeldingen. Geluid. Of [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Remkus de Vries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6306:\"
<p class=\"has-background has-large-font-size\" style=\"background-color:#d1e4dd\">Het delen van je verhalen is nog nooit zo eenvoudig geweest.</p>



<p>WordPress 5.6 biedt je talloze manieren om je ideeën de vrije loop te laten en ze tot leven te brengen. Met een gloednieuw standaardthema als je canvas, ondersteunt het een steeds groter wordende verzameling blokken als je penselen. Verf met woorden. Afbeeldingen. Geluid. Of rich embedded media.</p>



<h2>Meer flexibiliteit in de lay-out</h2>



<p>Breng je verhalen tot leven met meer gereedschappen waarmee je je lay-out met of zonder code kunt bewerken. Blokken met één kolom, ontwerpen met verschillende breedtes en kolommen, headers over de volledige breedte en video&#8217;s in je cover blok &#8211; breng met hetzelfde gemak kleine wijzigingen of grote uitspraken aan!</p>



<h2>Meer blokpatronen</h2>



<p>In geselecteerde thema&#8217;s maken voor-geconfigureerde blokpatronen het opzetten van standaardpagina&#8217;s op je site een fluitje van een cent. Ontdek de kracht van patronen om je workflow te stroomlijnen, of deel een deel van die kracht met je klanten en bespaar jezelf een paar klikken.</p>



<h2>Upload videobijschriften direct in de blokeditor</h2>



<p>Om je te helpen ondertiteling of bijschriften toe te voegen aan je videos, kan je ze nu uploaden in je bericht of pagina. Dit maakt het makkelijker dan ooit om videos toegankelijk te maken voor iedereen die ondertiteling nodig heeft of hiervoor de voorkeur voor heeft.</p>



<h2>Twenty Twenty-One is er!</h2>



<p>Twenty Twenty-One is een leeg canvas voor je ideeën en de blok-editor is het beste penseel. Het is gebouwd voor de blok-editor en zit boordevol gloednieuwe blokpatronen die je alleen in de standaardthema&#8217;s kunt krijgen. Probeer binnen enkele seconden verschillende lay-outs uit en laat het opvallende, maar tijdloze ontwerp van het thema je werk doen stralen.</p>



<div class=\"wp-block-image\"><figure class=\"aligncenter size-large\"><img src=\"https://s.w.org/images/core/5.6/twentytwentyone-layouts.jpg\" alt=\"\" /></figure></div>



<p>Aanvullend, dit standaardthema zet de toegankelijkheid in het hart van je site. Het voldoet aan de&nbsp;<a href=\"https://make.wordpress.org/themes/handbook/review/accessibility/\">WordPress accessibility-ready</a>&nbsp;richtlijnen en behandeld verschillende meer gespecialiseerde normen van de&nbsp;<a href=\"https://www.w3.org/WAI/WCAG2AAA-Conformance\">Web Content Accessibility Guidelines (WCAG) 2.1 at level AAA</a>. Het helpt je bij het voldoen aan het hoogste niveau van internationale toegankelijkheidsnormen wanneer je toegankelijke inhoud maakt en kiest plugins die ook toegankelijk zijn!</p>



<h2>Een regenboog van zachte pastelkleuren</h2>



<figure class=\"wp-block-image size-large\"><img src=\"https://s.w.org/images/core/5.6/twentytwentyone-rainbow.png\" alt=\"\" /></figure>



<p>Twenty Twenty-One is perfect voor een nieuw jaar en biedt je een reeks vooraf geselecteerde kleurenpaletten in pastelkleuren, die allemaal voldoen aan de AAA-normen voor contrast. Je kan ook je eigen achtergrondkleur voor het thema kiezen, en het thema kiest automatisch bewust toegankelijke tekstkleuren voor je!</p>



<p>Meer flexibiliteit nodig dan dat? Je kunt ook je eigen kleurenpalet kiezen uit de kleurenkiezer.</p>



<figure class=\"wp-block-image size-large\"><img src=\"https://i0.wp.com/wordpress.org/news/files/2020/12/WordPress5-6-3.jpeg?w=1264&amp;ssl=1\" alt=\"\" /></figure>



<h2>Verbeteringen voor iedereen</h2>



<h3>Auto-updates uitgebreid</h3>



<p>Jarenlang konden alleen ontwikkelaars WordPress automatisch updaten. Maar nu heb je die optie, rechtstreeks in je dashboard. Als dit je eerste site is, heb je nu auto-updates klaar voor gebruik! Een bestaande site upgraden? Geen probleem! Alles is hetzelfde als voorheen.</p>



<h3>Template voor toegankelijkheidsverklaring</h3>



<p>Zelfs als je geen expert bent, kun je mensen met een klik op de knop laten weten dat je site zich inzet voor toegankelijkheid! De nieuwe&nbsp;<a href=\"https://github.com/10degrees/accessibility-statement-plugin\">functie plugin</a>&nbsp;bevat een template kopie die je kan updaten en publiceren, en het is geschreven om verschillende contexten en rechtsgebieden te ondersteunen.</p>



<h3>Ingebouwde patronen</h3>



<p>Als je nog niet de kans hebt gehad om met blokpatronen te spelen, hebben alle standaardthema&#8217;s nu een reeks blokpatronen waarmee je complexe lay-outs met minimale inspanning onder de knie kunt krijgen. Pas de patronen naar wens aan met de tekst, afbeeldingen en kleuren die bij je verhaal of merk passen.</p>



<h2>Voor ontwikkelaars</h2>



<h3>REST API authenticatie met applicatie wachtwoorden</h3>



<p>Dankzij de nieuwe autorisatiefunctie voor Application Passwords van de API kunnen apps van derden naadloos en veilig verbinding maken met je site. Met deze nieuwe REST API functie kan je zien welke apps verbinding maken met je site en bepalen wat ze doen.</p>



<h3>Meer ondersteuning voor PHP 8</h3>



<p>5.6 markeert de eerste stappen in de richting van WordPress Core ondersteuning voor PHP 8. Dit is een goed moment om te plannen hoe je WordPress producten, diensten en sites de nieuwste PHP-versie kunnen ondersteunen. Voor meer informatie over wat je kan verwachten,&nbsp;<a href=\"https://make.wordpress.org/core/2020/11/23/wordpress-and-php-8-0/\">lees de PHP 8 ontwikkelaar notitie</a>.</p>



<h3>jQuery</h3>



<p>Updates voor jQuery in WordPress vinden plaats in drie releases:5.5, 5.6 en 5.7. Als we het midden van dit proces hebben bereikt, voer je de update test plugin uit om je sites van tevoren op fouten te controleren.</p>



<p>Als je problemen hebt met de manier waarop je site er uitziet (bijv. een slider werkt niet, een knop zit vast &#8211; dat soort dingen), installeer dan de <a href=\"https://wordpress.org/plugins/enable-jquery-migrate-helper/\">jQuery Migrate plugin</a>.</p>



<hr class=\"wp-block-separator\" />



<h3>Bekijk de Field Guide voor meer informatie!</h3>



<p>Bekijk de nieuwste versie van de WordPress Field Guide. Het heeft opmerkingen van ontwikkelaars voor elke wijziging waarvan je op de hoogte wil zijn:&nbsp;<a href=\"https://make.wordpress.org/core/2020/11/20/wordpress-5-6-field-guide/\">WordPress 5.6 Field Guide</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://nl.wordpress.org/2020/12/08/wordpress-5-6-is-vrijgegeven/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:73:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 5.5 is vrijgegeven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://nl.wordpress.org/2020/08/11/wordpress-5-5-is-vrijgegeven/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://nl.wordpress.org/2020/08/11/wordpress-5-5-is-vrijgegeven/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 11 Aug 2020 20:13:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://nl.wordpress.org/?p=1102\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:403:\"In WordPress 5.5 wordt je site beter in drie belangrijke gebieden: snelheid, zoeken en veiligheid. Snelheid Berichten en pagina&#8217;s voelen sneller aan, dankzij &#8216;lazy-loaded&#8217; afbeeldingen. Afbeeldingen kunnen je verhaal veel impact geven, maar zij kunnen soms je site langzaam maken. In WordPress 5.5 wachten afbeeldingen met inladen totdat zij door het scrollen in beeld komen. [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Remkus de Vries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6495:\"
<p>In WordPress 5.5 wordt je site beter in drie belangrijke gebieden: snelheid, zoeken en veiligheid.</p>



<h2>Snelheid</h2>



<p><strong>Berichten en pagina&#8217;s voelen sneller aan, dankzij &#8216;lazy-loaded&#8217; afbeeldingen.</strong></p>



<p>Afbeeldingen kunnen je verhaal veel impact geven, maar zij kunnen soms je site langzaam maken.</p>



<p>In WordPress 5.5 wachten afbeeldingen met inladen totdat zij door het scrollen in beeld komen. De technische term is &#8216;lazy-loading&#8217;.</p>



<p>Op mobiel kan lazy-loading ervoor zorgen dat browsers geen bestanden downloaden die bedoeld zijn voor andere apparaten. Dat bespaart je lezers kosten voor datagebruik en helpt de levensduur van de batterij te verlengen.</p>



<h2>Zoeken</h2>



<p><strong>Verwelkom je nieuwe sitemap.</strong></p>



<p>WordPress sites werken goed met zoekmachines.</p>



<p>WordPress 5.5 bevat nu standaard een XML-sitemap, die zoekmachines helpt je meest belangrijke pagina&#8217;s te vinden vanaf het moment je live gaat met je site.</p>



<p>Daardoor vinden meer mensen je site, en dat geeft je meer tijd om ze te boeien, om ze vast te houden en om ze te converteren naar abonnee, klant, of hoe jij succes ook definieert</p>



<h2>Beveiliging</h2>



<p><strong>Auto-updates voor plugins en thema&#8217;s</strong></p>



<p>Je kan nu in de WordPress-admin instellen dat plugins en thema&#8217;s automatisch worden geüpdatet — of niet natuurlijk! Zo weet je zeker dat je site altijd de meest recente code draait.</p>



<p>Je kan auto-updates in- of uitschakelen voor elke plugin of elk thema die je hebt geïnstalleerd — alles op dezelfde schermen zoals je gewend bent.</p>



<p><strong>Bijwerken door het uploaden van ZIP bestanden</strong></p>



<p>Als handmatig updaten van plugins en thema&#8217;s je ding is, dan is dat nu ook eenvoudiger — simpel door een ZIP bestand uploaden.</p>



<h2>Hoogtepunten van de blok-editor</h2>



<p>Wederom zit de laatste release van WordPress bomvol spannende nieuwe functies voor de blok-editor. Bijvoorbeeld:</p>



<h3>Blokpatronen</h3>



<p>Nieuwe blokpatronen maken het simpel en leuk om prachtige, complexe lay-outs te maken door gebruik te maken van een combinatie van tekst en media om je verhaal te vertellen.</p>



<p>Je vindt blokpatronen ook in een uitgebreid aanbod aan plugins en thema&#8217;s, en er worden continue nieuwe toegevoegd. Kies ze vanuit een enkele locatie — gewoon klikken en gaan!</p>



<p>Er zijn verschillende blok lay-outs in dit tabblad. Na het scrollen door opties, waaronder knoppen en kolommen, wordt een patroon gekozen genaamd &#8220;Grote header met een header&#8221;. Dit voegt een cover blok toe, dat is aangepast met een foto en de naam van de WordPress 5.5 jazzmuzikant.</p>



<hr class=\"wp-block-separator\" />



<h3>Inline afbeelding bewerking</h3>



<p>Vanuit het afbeeldingsblok kan je nu meteen je foto&#8217;s bijsnijden, roteren en inzoomen. Als je veel tijd besteedt aan afbeeldingen, dan kan dit je uren besparen!</p>



<h3>De nieuwe blok bibliotheek</h3>



<p>Het is nu makkelijker dan ooit om het blok te vinden wat je nodig hebt. De nieuwe blok bibliotheek is in de blok-editor gebouwd, zodat je nieuwe bloktypes kunt installeren voor je site zonder de editor te verlaten.</p>



<h3>En zo veel meer.</h3>



<p>De hoogtepunten hierboven zijn maar een klein gedeelte van de nieuwe mogelijkheden van de blok-editor die je net hebt geïnstalleerd. Open de blok-editor en geniet ervan!</p>



<h2>Toegankelijkheid</h2>



<p>Iedere release voegt verbeteringen toe aan de toegankelijke publicatie ervaring, en dat geldt ook voor WordPress 5.5.</p>



<p>Nu kun je links kopiëren in mediaschermen en modale dialogen met een knop, in plaats van te proberen een regel tekst te markeren.</p>



<p>Je kan ook metaboxen verplaatsen met je toetsenbord, en afbeeldingen in WordPress bewerken met je ondersteunende apparaat, omdat het de instructies in de afbeeldingseditor kan lezen.</p>



<h2>Voor ontwikkelaars</h2>



<p>WordPress 5.5 komt ook met een grote hoeveelheid wijzigingen alleen voor ontwikkelaars.</p>



<h3>Server-side geregistreerde blokken in de REST API</h3>



<p>Het toevoegen van endpoints voor bloktypes betekent dat JavaScript apps (zoals de blok-editor) definities op kunnen halen voor alle blokken die zijn geregistreerd op de server.</p>



<h3>Dashicons</h3>



<p>De Dashicons bibliotheek heeft zijn laatste update gekregen in 5.5. Het voegt 39 blok-editor pictogrammen toe samen met 26 andere.</p>



<h3>Definieer omgevingen</h3>



<p>WordPress heeft de manier waarop het type omgeving van je site (staging, productie, etc) wordt gedefinieerd gestandaardiseerd. Haal dat type op met&nbsp;<code>wp_get_environment_type()</code>&nbsp;en voer alleen de daarvoor bedoelde code uit.</p>



<h3>Gegevens doorgeven aan template bestanden</h3>



<p>De template-laadfuncties (<code>get_header()</code>,&nbsp;<code>get_template_part()</code>, etc.) hebben een nieuw&nbsp;<code>$args</code>-argument. Je kan vanaf nu een hele array aan data meegeven aan deze templates.</p>



<h3>Meer wijzigingen voor ontwikkelaars</h3>



<ul><li>De PHPMailer bibliotheek heeft een grote update gehad, van versie 5.2.27 naar 6.1.6.</li><li>Krijg preciezere controle over&nbsp;<code>redirect_guess_404_permalink()</code>.</li><li>Sites die gebruik maken van PHP&#8217;s OPcache hebben een betrouwbaardere cache-invalidatie dankzij de nieuwe&nbsp;<code>wp_opcache_invalidate()</code>-functie tijdens updates (ook van plugins en thema&#8217;s).</li><li>Extra berichttypen die aan de categorie-taxonomie zijn gekoppeld, kunnen nu via opt-in de standaardterm te ondersteunen.</li><li>Standaardtermen kunnen nu worden gespecificeerd voor aangepaste taxonomieën in&nbsp;<code>register_taxonomy()</code>.</li><li>De REST-API ondersteunt nu officieel het specificeren van standaard metadata waarden via&nbsp;<code>register_meta()</code>.</li><li>Je krijgt bijgewerkte versies van de volgende gebundelde libraries: SimplePie, Twemoji, Masonry, imagesLoaded, getID3, Moment.js, and clipboard.js.</li></ul>



<h3>Bekijk de Field Guide voor meer informatie!</h3>



<p>Er is nog veel meer voor ontwikkelaars om van te houden in WordPress 5.5. Raadpleeg de <a href=\"https://make.wordpress.org/core/wordpress-5-5-field-guide/\">WordPress 5.5 Field Guide</a> om meer te ontdekken en te leren hoe je deze wijzigingen kunt laten schitteren op je sites, thema&#8217;s, plugins en meer.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://nl.wordpress.org/2020/08/11/wordpress-5-5-is-vrijgegeven/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"8\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:73:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 5.4 is vrijgegeven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://nl.wordpress.org/2020/04/01/wordpress-5-4-is-vrijgegeven/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://nl.wordpress.org/2020/04/01/wordpress-5-4-is-vrijgegeven/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 01 Apr 2020 08:17:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Algemeen\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://nl.wordpress.org/?p=1086\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:341:\"Zeg hallo tegen meer en beter. Meer mogelijkheden om je pagina&#8217;s tot leven te brengen. Met eenvoudigere manier om van alles mogelijk te maken, beter dan ooit en een verbetering in snelheid die je echt kunt voelen. Welkom bij WordPress 5.4. Iedere grote release voegt meer toe aan de blok-editor. Meer manieren om je berichten [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Remkus de Vries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5315:\"
<h1>Zeg hallo tegen meer en beter.</h1>



<p>Meer mogelijkheden om je pagina&#8217;s tot leven te brengen. Met eenvoudigere manier om van alles mogelijk te maken, beter dan ooit en een verbetering in snelheid die je echt kunt voelen.</p>



<h2>Welkom bij WordPress 5.4.</h2>



<p>Iedere grote release voegt meer toe aan de blok-editor.</p>



<p>Meer manieren om je berichten en pagina&#8217;s tot leven te laten komen met je beste afbeeldingen. Meer manieren om je bezoekers binnen te halen en betrokken te houden met de rijkdom van ingesloten media van het web&#8217;s top diensten.</p>



<p>Meer manieren om jouw visie echt te make. Zet blokken op de perfect plek neer. Zelfs als het specifieke blok nieuw voor je is. Meer efficiëntere processen.</p>



<p>En meer snelheid in heel veel andere opties. Bijvoorbeeld in het maken van groepen of gallerijen. Je kunt zoveel sneller werken nu!</p>



<h2>Twee nieuwe blokken. En betere blokken in het algemeen.</h2>



<ul><li>Twee gloednieuwe blokken: Sociale iconen en knoppen maken het toevoegen van interactieve functies snel en gemakkelijk.</li><li>Meer opties met kleuren: gradients in de knoppen en cover blok, toolbar toegang to kleur opties in de tekstblokken, en voor het eerst nu, kleur opties in de Groep en Kolom blokken.</li><li>Je hoeft een stuk minder te gokken! Versie 5.4 stroomlijnt het hele proces voor het plaatsen en vervangen van multimedia in elk blok. Nu werkt het op dezelfde manier in bijna elk blok!</li><li>Als je ooit hebt gedacht dat je afbeelding in het Media+Tekst blok zou moeten linken naar wat anders zou, misschien zou de foto van een brochure bijvoorbeeld de brochure zelf moeten downloaden als een document? Vanaf nu kan dat.</li></ul>



<h2>Strakkere UI, duidelijkere navigatie en eenvoudiger met tab doorheen te navigeren!</h2>



<ul><li>Duidelijkere blok navigatie met blok-kruimelpad. En een eenvoudigere selectie eens je daar bent.</li><li>Voor wanneer je moet navigeren met het toetsenbord, beter met tabben werken en focus. Plus, je kunt met tab naar de sidebar navigeren van bijna elk blok.</li><li>Snelheid! 14% sneller laden van de editor en 51% sneller om te kunnen typen!</li><li>Tips zijn verdwenen. Maar in plaats daarvan hebben we een Welkom Gids scherm die je tevoorschijn kunt toveren. Zo vaak je maar wilt.</li><li>Zie direct of je in de wijzig- of navigatiemodus van een blok zit. Of, wanneer je beperkt zicht hebt zal je screenreader je vertellen in welke modus je zit.</li></ul>



<p>Als je met de allerlaatste tools en mogelijkheden wilt werken, installeer dan de <a href=\"https://wordpress.org/plugins/gutenberg/\">Gutenberg plugin</a>. Je bent dan één van de eersten die met nieuwe en interessante mogelijkheden in de blok editor werkt!</p>



<h2>Je fundamentele recht: privacy</h2>



<p>WordPress 5.4 helpt je met een aantal verschillende wereldwijde privacy punten. Dus wanneer je gebruikers en andere belanghebbenden vragen hebben over naleving van de regelgeving, of hoe je team omgaat met gebruikersdata, dan zou je nu het antwoord een stuk eenvoudiger juist moeten kunnen krijgen.</p>



<p>Neem een kijkje:</p>



<ul><li>Persoonlijke data exports zijn nu inclusief informatie over gebruikerssessies en gebruikers locatie data van de community evenementen widget. Plus, een overzichtstabel.</li><li>Zie de voortgang van export en verwijderverzoeken via de privacy tools.</li><li>Aanvullend, kleine verbeteringen waardoor de Privacy Tools er net even wat strakker uit zien.</li></ul>



<h2>Speciaal voor ontwikkelaars</h2>



<h3>Voeg custom fields toe aan menu-items&#8211;standaard</h3>



<p>Twee nieuwe acties maken het je mogelijk om custom fields aan het menu toe te voegen. Zonder aparte plugin en zonder maatwerk code.</p>



<p>Op het Menu admin scherm, wordt <code>wp_nav_menu_item_custom_fields</code>&nbsp;uitgevoerd net voor de verschuifknoppen van een navigatie menu item in de menu editor.</p>



<p>In de Customizer,&nbsp;<code>wp_nav_menu_item_custom_fields_customize_template</code>&nbsp;wordt uitgevoerd aan het eind van de menu onderdelen form-fields template.</p>



<p>Check je code en bekijk of deze nieuwe acties jouw code kunnen vervangen. Als je bezorgt bent voor duplicatie, voeg dan een WordPress versiespecifieke check toe.</p>



<h3>Blokken! Eenvoudiger vormgeving, nieuwe API&#8217;s en insluitingen.</h3>



<ul><li>Blokvormgeving is <strong>drastisch</strong> vereenvoudigd. Negatieve margins en standaard padding zijn verdwenen! Je kunt blokken nu vormgeven zoals je wenst. Ook zijn vier onnodige wrapper div&#8217;s opgeschoond.</li><li>Als je plugins ontwikkelt, dan kun je nu verzamelingen van je blokken registeren via de namespace over verschillende categorieën. Een mooie manier om je merk meer zichtbaarheid te geven.</li><li>Twee nieuwe API&#8217;s bieden gebruikers meer mogelijkheden: blokvarianten en kleurverlopen.</li><li>De blokeditor (Gutenberg) ondersteunt nu TikTok in ingesloten code. CollegeHumor is verwijderd.</li></ul>



<p>Er zitten ontzettend veel fijne verbeteringen voor ontwikkelaars in WordPress 5.4. Als je meer wilt weten hoe je je websites, thema&#8217;s en plugins beter kunt maken, bekijk dan de <a href=\"https://make.wordpress.org/core/2020/03/03/wordpress-5-4-field-guide/\">WordPress 5.4 Field Guide</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://nl.wordpress.org/2020/04/01/wordpress-5-4-is-vrijgegeven/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:73:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 5.3 is vrijgegeven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://nl.wordpress.org/2019/11/13/wordpress-5-3-is-vrijgegeven/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://nl.wordpress.org/2019/11/13/wordpress-5-3-is-vrijgegeven/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 13 Nov 2019 10:11:19 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://nl.wordpress.org/?p=1064\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:407:\"We introduceren onze meest verfijnde gebruikerservaring met de verbeterde blokeditor in WordPress 5.3! WordPress 5.3 maakt de blokeditor, die is geïntroduceerd in WordPress 5.0, nog beter en het heeft nu ook een nieuwe blok, meer intuïtieve interacties en verbeterde toegankelijkheid. Nieuwe functies in de editor vergroten de ontwerp vrijheid, bieden extra lay-outopties en stijlvariaties zodat [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Remkus de Vries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5228:\"
<p><strong>We introduceren onze meest verfijnde gebruikerservaring met de verbeterde blokeditor in WordPress 5.3!</strong></p>



<p>WordPress 5.3 maakt de blokeditor, die is geïntroduceerd in WordPress 5.0, nog beter en het heeft nu ook een nieuwe blok, meer intuïtieve interacties en verbeterde toegankelijkheid. Nieuwe functies in de editor vergroten de ontwerp vrijheid, bieden extra lay-outopties en stijlvariaties zodat ontwerpers volledige controle hebben over het uiterlijk van hun website. </p>



<p>Deze release introduceert ook het Twenty Twenty thema waardoor de gebruiker meer ontwerpflexibiliteit en integratie met de blokeditor heeft. Het maken van prachtige webpagina&#8217;s en geavanceerde lay-outs is nog nooit zo eenvoudig geweest.</p>



<span id=\"more-1064\"></span>



<h2>Verbeteringen blok-editor</h2>



<p>Deze op verbeteringen gerichte update introduceert meer dan 150 nieuwe functies en gebruiksverbeteringen, waaronder verbeterde ondersteuning van grote afbeeldingen voor het uploaden van niet-geoptimaliseerde foto&#8217;s met een hoge resolutie die zijn gemaakt met je smartphone of andere hoogwaardige camera&#8217;s. In combinatie met grotere standaard afbeeldingsformaten zien foto&#8217;s er altijd op hun best uit.</p>



<p>De verbeteringen van de toegankelijkheid omvat de integratie van stijlen voor blokeditor in de beheerinterface. Deze verbeterde stijlen lossen veel toegankelijkheidsproblemen op: kleurcontrast op formuliervelden en knoppen, consistentie tussen editor- en admin-interfaces, nieuwe notificaties, standaardisatie naar het standaard WordPress-kleurenschema en de introductie van animatie om interactie met je blokken snel en natuurlijk aan te laten voelen. </p>



<p>Voor mensen die een toetsenbord gebruiken om door het dashboard te navigeren, heeft de blokeditor nu ook een navigatiemodus. Hiermee kan je van blok naar blok springen zonder door elk deel van de blokbesturing te bladeren.</p>



<h2>Uitgebreide design flexibiliteit</h2>



<p>WordPress 5.3 voegt nog meer gereedschappen toe om geweldige ontwerpen mee te maken.</p>



<ul><li>Het nieuwe Groep blok staat je toe om jouw pagina makkelijk op te delen in kleurrijke secties.</li><li>Het Kolom blok ondersteund vanaf nu vaste kolombreedtes</li><li>De nieuwe vooraf gedefinieerde lay-outs maken het heel simpel om inhoud in geavanceerde lay-outs te ontwerpen</li><li>De tekstkleur van titelblokken is nu instelbaar</li><li>Met extra stijlopties kan je de gewenste stijl instellen voor elke blok dat deze functie ondersteunt</li></ul>



<h2>Introductie Twenty Twenty</h2>



<figure class=\"wp-block-image size-large\"><img src=\"https://s.w.org/images/core/5.3/twentytwenty-desktop.png\" alt=\"\" /></figure>



<p>Terwijl de blokeditor zijn eerste verjaardag viert, zijn we er trots op dat Twenty Twenty is ontworpen met flexibiliteit in de kern. Pronk met je diensten of producten met een combinatie van kolommen, groepen en mediablokken. Stel je inhoud in op breed of volledige uitlijning voor dynamische en boeiende lay-outs.</p>



<p>Twenty Twenty heeft, zoals het hoort, een sterke focus op overzichtbaarheid en leesbaarheid. Het thema bevat het typeface&nbsp;<a href=\"https://rsms.me/inter/\">Inter</a>&nbsp;wat ontworpen is door Rasmus Andersson. Inter is beschikbaar als een Variable Font versie, voor het eerst in een standaard thema, wat maakt dat de laadtijd kort houd door alle stijlen van Inter in slechts twee font bestanden beschikbaar zijn.</p>



<h2>Verbeteringen voor iedereen</h2>



<h3>Automatische afbeeldingsrotatie</h3>



<p>Je afbeeldingen zullen nu op de correcte manier gedraaid zijn wanneer je ze uploadt gebaseerd op de orientatiedata. Deze verbetering is negen jaar geleden voorgesteld en mogelijk gemaakt door het doorzettingsvermogen van vele volhardende bijdragers.</p>



<h3>Sitediagnose controles</h3>



<p>De verbeteringen die geïntroduceerd worden in 5.3 maken het zelfs makkelijker om problemen te detecteren. Uitgebreide aanbevelingen brengen lichten bepaalde onderdelen uit die aandacht nodig hebben in het Health Check scherm.</p>



<h3>Admin e-mail verificatie</h3>



<p>Je wordt nu periodiek gevraagd om je admin email adres te bevestigen wanneer je ingelogd bent als een administrator. Dit maakt de kans een stuk kleiner dat je niet meer in je site kunt komen wanneer je je email adres wijzigt.</p>



<h2>Voor ontwikkelaars</h2>



<h3>Date/Time component verbeteringen</h3>



<p>Ontwikkelaars kunnen nu werken met&nbsp;<a href=\"https://make.wordpress.org/core/2019/09/23/date-time-improvements-wp-5-3/\">data en tijdzones</a>&nbsp;in een betrouwbaardere manier. Datum en tijd functionaliteit heeft een aantal nieuwe API functies toegevoegd gekregen voor unified timezone retrieval en PHP interoperability en daarnaast zijn er ook een hoop bug fixes doorgevoerd.</p>



<h3>PHP 7.4 compatibiliteit</h3>



<p>WordPress 5.3 ondersteunt PHP 7.4 volledig. Deze release bevat&nbsp;<a href=\"https://make.wordpress.org/core/2019/10/11/wordpress-and-php-7-4/\">meerdere wijzigingen</a>&nbsp;die verouderde functionaliteit verwijderen en de compatibiliteit verzekeren. WordPress blijft gebruikers aanbevelen om de laatste en beste versie van PHP te gebruiken.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://nl.wordpress.org/2019/11/13/wordpress-5-3-is-vrijgegeven/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:73:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 5.2 is vrijgegeven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://nl.wordpress.org/2019/05/08/wordpress-5-2-is-vrijgegeven/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://nl.wordpress.org/2019/05/08/wordpress-5-2-is-vrijgegeven/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 May 2019 08:11:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://nl.wordpress.org/?p=1041\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:337:\"Met deze update is het gemakkelijker dan ooit om je site te repareren als er iets misgaat. Houd je site veilig WordPress 5.2 geeft je nog meer robuuste gereedschappen voor het identificeren en repareren van configuratieproblemen en fatale fouten. Of je nu een ontwikkelaar bent die klanten helpt of dat je zelf je site beheert, [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Remkus de Vries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3632:\"
<p>Met deze update is het gemakkelijker dan ooit om je site te repareren als er iets misgaat.</p>



<h2>Houd je site veilig</h2>



<p>WordPress 5.2 geeft je nog meer robuuste gereedschappen voor het identificeren en repareren van configuratieproblemen en fatale fouten. Of je nu een ontwikkelaar bent die klanten helpt of dat je zelf je site beheert, deze gereedschappen kunnen je aan de juiste informatie helpen op het moment dat je het nodig hebt.</p>



<figure class=\"wp-block-image\"><img src=\"https://s.w.org/images/core/5.2/about_maintain-wordpress-v2.svg\" alt=\"\" /></figure>



<span id=\"more-1041\"></span>



<h3>Sitediagnose controle</h3>



<div class=\"wp-block-image\"><figure class=\"alignright\"><img src=\"https://s.w.org/images/core/5.2/about_site-health.svg\" alt=\"\" /></figure></div>



<p>Voortbordurend op&nbsp;<a href=\"https://wordpress.org/news/2019/02/betty/\">de Sitediagnose features geïntroduceerd in 5.1</a>, voegt deze release twee nieuwe pagina&#8217;s toe om je te helpen veelvoorkomende problemen in de configuratie op te lossen. Er wordt ook een ruimte toegevoegd waar ontwikkelaars informatie kunnen toevoegen voor mensen die sites onderhouden.&nbsp;Ontdek meer of je site status, en&nbsp;leer hoe je issues kunt oplossen.</p>



<h3>PHP foutbescherming</h3>



<div class=\"wp-block-image\"><figure class=\"alignright\"><img src=\"https://s.w.org/images/core/5.2/about_error-protection.svg\" alt=\"\" /></figure></div>



<p>Deze update met een focus op beheerders laat je op een veilige manier fatale fouten herstellen of beheren, zonder dat het ontwikkeltijd kost. Er is een betere afhandeling van de zogenaamde &#8220;white screen of death&#8221; en een manier om in herstelmodus te komen. De herstelmodus pauzeert plugins of thema&#8217;s die voor fouten zorgen.</p>



<h3>Verbeteringen voor iedereen</h3>



<h4>Toegankelijkheid updates</h4>



<p>Een aantal verbeteringen werken samen om de contextuele positie en flow van de toetsenbordnavigatie te verbeteren voor zij die screenreaders en andere ondersteunende technologie gebruiken.</p>



<h4>Nieuwe dashboard iconen</h4>



<p>Dertien nieuwe icoontjes, inclusief Instagram, een aantal BuddyPress icoontjes en verschillende versies van de wereldbol zijn toegevoegd. Je vindt ze terug in het Dashboard. Veel plezier ermee!</p>



<h3>Hier worden ontwikkelaars blij van</h3>



<h4><a href=\"https://make.wordpress.org/core/2019/03/26/coding-standards-updates-for-php-5-6/\">PHP versie update</a></h4>



<p>De minimum ondersteunde PHP versie is nu 5.6.20. Vanaf WordPress 5.2 kunnen thema&#8217;s en plugins veilig gebruik maken van de voordelen van namespaces, anonymous functions, en meer!</p>



<h4><a href=\"https://make.wordpress.org/core/2019/04/24/developer-focused-privacy-updates-in-5-2/\">Privacy updates</a></h4>



<p>Een nieuwe thema pagina template, een conditionele functie en twee CSS classes maken het ontwerpen en aanpassen van de Privacy Policy pagina eenvoudiger.</p>



<h4><a href=\"https://make.wordpress.org/core/2019/04/24/miscellaneous-developer-updates-in-5-2/\">Nieuwe Body Tag hook</a></h4>



<p>5.2 introduceert een&nbsp;<code>wp_body_open</code>&nbsp;hook die thema&#8217;s toestaat code toe te voegen helemaal aan het begin van het&nbsp;<code>&lt;body&gt;</code>&nbsp;element.</p>



<h4><a href=\"https://make.wordpress.org/core/2019/03/25/building-javascript/\">JavaScript</a></h4>



<p>Met de toevoeging van webpack en Babel instellingen in het wordpress/scripts package hoeven ontwikkelaars niet meer bezig te zijn om uit te zoeken hoe ze complexe build tools moeten gebruiken om moderne JavaScript the schrijven.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://nl.wordpress.org/2019/05/08/wordpress-5-2-is-vrijgegeven/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:73:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 5.1 is vrijgegeven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://nl.wordpress.org/2019/02/22/wordpress-5-1-is-vrijgegeven/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://nl.wordpress.org/2019/02/22/wordpress-5-1-is-vrijgegeven/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 Feb 2019 08:11:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://nl.wordpress.org/?p=1027\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:440:\"In navolging op WordPress 5.0—een grote release waar de nieuwe blok editor werd geïntroduceerd—is 5.1 vooral toegespitst op verfijning, specifiek performance-verbeteringen van de editor. Ook baant deze release een weg naar een betere, snellere en veiligere WordPress installatie met een aantal essentiële gereedschappen voor sitebeheerders en ontwikkelaars. Sitediagnose Deze release introduceert, met veiligheid en snelheid [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Remkus de Vries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3876:\"
<p>In navolging op <a href=\"https://nl.wordpress.org/2018/12/07/wordpress-5-0-is-vrijgegeven/\">WordPress 5.0</a>—een grote release waar de nieuwe blok editor werd geïntroduceerd—is 5.1 vooral toegespitst op verfijning, specifiek performance-verbeteringen van de editor. Ook baant deze release een weg naar een betere, snellere en veiligere WordPress installatie met een aantal essentiële gereedschappen voor sitebeheerders en ontwikkelaars.</p>



<h3>Sitediagnose</h3>



<div class=\"wp-block-image\"><figure class=\"alignright\"><img src=\"https://s.w.org/images/core/5.1/site-health.svg\" alt=\"\" /></figure></div>



<p>Deze release introduceert, met veiligheid en snelheid in het achterhoofd, de eerste&nbsp;<a href=\"https://make.wordpress.org/core/2019/01/14/php-site-health-mechanisms-in-5-1/\">Sitediagnose</a>&nbsp;kenmerken. Zo zal WordPress berichten gaan tonen aan beheerders van sites die zeer oude versies van PHP draaien, de programmeertaal waar WordPress in gebouwd is.</p>



<p>Wanneer je nieuwe plugins installeert zal de Sitediagnose functie in WordPress controleren of een plugin een PHP versie nodig heeft die niet werkt met jouw site. Indien dit het geval is zal WordPress je niet toestaan de plugin te activeren.</p>



<span id=\"more-1027\"></span>



<h3>Snelheidsverbeteringen voor de editor</h3>



<div class=\"wp-block-image\"><figure class=\"alignright\"><img src=\"https://s.w.org/images/core/5.1/editor-performance.svg\" alt=\"\" /></figure></div>



<p>De nieuwe blok editor die in WordPress 5.0 is geïntroduceerd is verder verbeterd. De grootste verbetering is de snelheid waarmee de editor nu werkt in WordPress 5.1. De editor zou nu iets sneller moeten opstarten en typen zou vloeiender moeten voelen. Los daarvan, in de komende versies zullen er meer snelheidsverbeteringen doorgevoerd worden.</p>



<h3>Hier worden ontwikkelaars blij van</h3>



<h4>Multisite metagegevens</h4>



<p>5.1 introduceert een nieuwe databasetabel om metadata op te slaan die geassocieerd is met sites en het mogelijk maakt om arbitraire site data op te slaan die relevant kan zijn in een multisite / netwerkcontext.	<br><a href=\"https://make.wordpress.org/core/2019/01/28/multisite-support-for-site-metadata-in-5-1/\">Lees meer.</a></p>



<h4>Cron API</h4>



<p>De Cron API is bijgewerkt met nieuwe functies voor returning data en bevat ook nieuwe filters voor het aanpassen van de cron storage. Andere wijzigingen hebben effect op cron spawning op servers die FastCGI en PHP-FPM versions 7.0.16 en daarboven draaien.	<br><a href=\"https://make.wordpress.org/core/2019/01/09/cron-improvements-with-php-fpm-in-wordpress-5-1/\">Lees meer.</a></p>



<h4>Nieuw JS Build Proces</h4>



<p>WordPress 5.1 introduceert een nieuw JavaScript build optie als gevolg van de grote reorganizatie van code die begon met de 5.0 release. <br><a href=\"https://make.wordpress.org/core/2018/05/16/preparing-wordpress-for-a-javascript-future-part-1-build-step-and-folder-reorganization/\">Lees meer.</a></p>



<h4>Overige fijne zaken voor ontwikkelaars</h4>



<p>Verschillende verbeteringen zoals updates voor de waarden die je kunt gebruiken in in de&nbsp;<code>WP_DEBUG_LOG</code>&nbsp;constant, een nieuwe test config file constant in de test suite, nieuwe plugin action hooks, short-circuit filters voor&nbsp;<code>wp_unique_post_slug()</code>&nbsp;en&nbsp;<code>WP_User_Query</code>&nbsp;en&nbsp;<code>count_users()</code>, een nieuwe&nbsp;<code>human_readable_duration</code>&nbsp;functie, verbeterde taxonomy metabox opschoning, gelimiteerde&nbsp;<code>LIKE</code>&nbsp;support voor meta keys wanneer je&nbsp;<code>WP_Meta_Query</code>&nbsp;gebruikt en een nieuwe “doing it wrong” melding wanneer je REST API endpoints registreert, en nog veel meer!	<br><a href=\"https://make.wordpress.org/core/2019/01/23/miscellaneous-developer-focused-changes-in-5-1/\">Lees meer.</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://nl.wordpress.org/2019/02/22/wordpress-5-1-is-vrijgegeven/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:75:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		


			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:8:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 5.0 is vrijgegeven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://nl.wordpress.org/2018/12/07/wordpress-5-0-is-vrijgegeven/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://nl.wordpress.org/2018/12/07/wordpress-5-0-is-vrijgegeven/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 07 Dec 2018 10:11:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://nl.wordpress.org/?p=1004\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:371:\"WordPress 5.0 is vrijgegeven. Deze nieuwe versie brengt één hele grote vernieuwing. We hebben namelijk een aantal grote veranderingen gemaakt in de editor. Onze nieuwe, op blokken gebaseerde editor, is de eerste stap richting een nieuwe toekomst met een gestroomlijnde editor ervaring op je site. Je hebt meer flexibiliteit over de manier hoe inhoud weergeven [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"enclosure\";a:2:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:52:\"https://s.w.org/images/core/5.0/videos/add-block.mp4\";s:6:\"length\";s:7:\"8086508\";s:4:\"type\";s:9:\"video/mp4\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:48:\"https://s.w.org/images/core/5.0/videos/build.mp4\";s:6:\"length\";s:7:\"2623964\";s:4:\"type\";s:9:\"video/mp4\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Remkus de Vries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:7129:\"
<figure class=\"wp-block-image\"><img src=\"https://s.w.org/images/core/5.0/header/Gutenberg1x.jpg\" alt=\"\" /></figure>



<p>WordPress 5.0 is vrijgegeven. Deze nieuwe versie brengt één hele grote vernieuwing. We hebben namelijk een aantal grote veranderingen gemaakt in de editor. Onze nieuwe, op blokken gebaseerde editor, is de eerste stap richting een nieuwe toekomst met een gestroomlijnde editor ervaring op je site. Je hebt meer flexibiliteit over de manier hoe inhoud weergeven wordt. Of je nou je eerste site aan het maken bent, je blog nieuw leven inblaast of code schrijft als baan.</p>



<span id=\"more-1004\"></span>



<div class=\"wp-block-columns has-2-columns\">
<div class=\"wp-block-column\">
<figure class=\"wp-block-image is-resized\"><img loading=\"lazy\" src=\"https://s.w.org/images/core/5.0/features/Plugins1x.jpg\" alt=\"\" width=\"250\" height=\"250\" /><figcaption>Doe meer met minder plugins.</figcaption></figure>
</div>



<div class=\"wp-block-column\">
<figure class=\"wp-block-image is-resized\"><img loading=\"lazy\" src=\"https://s.w.org/images/core/5.0/features/Layout1x.jpg\" alt=\"\" width=\"250\" height=\"250\" /><figcaption>Creëer moderne, multimedia rijke lay-outs.</figcaption></figure>
</div>
</div>



<div class=\"wp-block-columns has-2-columns\">
<div class=\"wp-block-column\">
<figure class=\"wp-block-image is-resized\"><img loading=\"lazy\" src=\"https://s.w.org/images/core/5.0/features/Editor%20Styles1x.jpg\" alt=\"\" width=\"250\" height=\"250\" /><figcaption>Vertrouw dat de editor lijkt op je site.</figcaption></figure>
</div>



<div class=\"wp-block-column\">
<figure class=\"wp-block-image is-resized\"><img loading=\"lazy\" src=\"https://s.w.org/images/core/5.0/features/Responsive1x.jpg\" alt=\"\" width=\"250\" height=\"250\" /><figcaption>Werkt op alle schermformaten en apparaten.</figcaption></figure>
</div>
</div>



<h2>Bouwen met blokken</h2>



<p>De nieuwe, op blokken gebaseerde editor, verandert niets aan de manier hoe je content er uit ziet voor bezoekers. Wat het wel doet, is het jou mogelijk maken elke multimedia soort super eenvoudig toe te voegen precies zoals jij dat voor ogen hebt. Elk stukje content is een afgebakend blok welke je eenvoudig kunt verplaatsen. Mocht je liever met HTML en CSS willen werken, dan staan de blokken je niet in de weg. WordPress is hier om het proces eenvoudiger te maken, niet het resultaat.</p>



<figure class=\"wp-block-video\"><video controls src=\"https://s.w.org/images/core/5.0/videos/add-block.mp4\"></video></figure>



<p>We hebben standaard al heel veel blokken beschikbaar, en elke dag worden er meer toegevoegd door de community. Begin een nieuw blok door de forward slash in te typen. Je krijgt dan direct te zien welke blokken er allemaal beschikbaar zijn.</p>



<h3>Vrijheid om te bouwen, vrijheid om te schrijven</h3>



<p>Deze nieuwe editor ervaring behandelt design en content op meer consistente manier. Wanneer je klantensites maakt kun je herbruikbare blokken maken. Hiermee kunnen je klanten steeds nieuwe content blijven toevoegen en blijft de uitstraling precies zoals je die bedoeld had.</p>



<figure class=\"wp-block-video\"><video controls src=\"https://s.w.org/images/core/5.0/videos/build.mp4\"></video></figure>



<hr class=\"wp-block-separator\" />



<h2>Een verbluffend nieuw standaard thema</h2>



<figure class=\"wp-block-image\"><img src=\"https://s.w.org/images/core/5.0/twenty%20nineteen/twenty-nineteen.webp\" alt=\"\" /><figcaption>De front-end van Twenty Nineteen aan de linkerkant en hoe het er uit ziet in de editor aan de rechterkant.</figcaption></figure>



<p>De introductie van Twenty Nineteen, het nieuwe standaard thema welke de kracht van de nieuwe editor laat zien.</p>



<h3>Ontworpen voor de Blok-editor</h3>



<p>Twenty Nineteen bevat aangepaste styling voor de blokken die standaard beschikbaar zijn in 5.0. Het thema maakt uitgebreid gebruik van editor-styles. Op die manier is wat je in de editor aan het maken bent een reflectie van hoe het op de site zelf er uit ziet.</p>



<h3>Eenvoudige, tekst gedreven lay-out</h3>



<p>Twenty Nineteen bevat veel witruimte en moderne schreefloze koppen, gecombineerd met klassieke serif-tekst. Het thema gebruikt systeemlettertypes om de laadsnelheid te verhogen. Niet meer lang wachten op trage netwerken!</p>



<figure class=\"wp-block-image\"><img src=\"https://s.w.org/images/core/5.0/twenty%20nineteen/twenty-nineteen-versatile.gif\" alt=\"\" /></figure>



<h3>Veelzijdig ontwerp voor alle sites</h3>



<p>Twenty Nineteen is ontworpen om te werken voor een breed scala aan toepassingen. Of je nu een foto-blog hebt, een nieuw bedrijf start of een non-profitorganisatie, Twenty Nineteen is flexibel genoeg om aan al je wensen te voldoen.</p>



<hr class=\"wp-block-separator\" />



<h2>Hier worden ontwikkelaars blij van</h2>



<h3>Beschermen</h3>



<p>Blokken bieden een fijne manier voor gebruikers om content direct te wijzigen en ze voorkomen dat de structuur van de content niet eenvoudig kan worden gestoord door onopzettelijke codebewerkingen. Dit staat de ontwikkelaar toe om controle te hebben op de output door gepolijste en semantische markup te leveren die bewaard blijft tijdens het bewerken.</p>



<h3>Opstellen</h3>



<p>Profiteer van een grote verzameling aan API&#8217;s en interface-componenten om eenvoudig blokken met een intuïtieve besturing voor je klanten te maken. Gebruik maken van deze componenten versnelt niet alleen het ontwikkelingswerk, maar biedt ook een consistentere, bruikbare en toegankelijke interface voor alle gebruikers.</p>



<h3>Maak</h3>



<p>Het nieuwe blokkenparadigma opent diverse mogelijkheden en verbeelding of hoe gebruikerswensen opgelost kunnen worden. Met eenduidige flow voor het toevoegen van een blok is eenvoudiger voor gebruikers om blokken te vinden voor alle soorten content. Ontwikkelaars kunnen zich richten op hun visie om verrijkte ervaringen te bieden, in plaats van werken met ingewikkelde API&#8217;s. <a href=\"https://wordpress.org/gutenberg/handbook/\">Leren hoe je moet starten</a></p>



<hr class=\"wp-block-separator\" />



<h2>Liever Klassiek?</h2>



<figure class=\"wp-block-image\"><img src=\"https://s.w.org/images/core/5.0/classic/Classic.webp\" alt=\"\" /></figure>



<p>Blijf je liever met de vertrouwde Klassieke editor werken? Dat is geen probleem! Ondersteuning voor de Klassieke editor plugin blijft aanwezig in WordPress tot en met 2021.</p>



<p>De <a href=\"https://nl.wordpress.org/plugins/classic-editor/\">Klassieke editor</a> plugin herstelt de vorige WordPress editor en het &#8220;bericht bewerken&#8221; scherm. Hiermee kan je plugins blijven gebruiken die de klassieke editor uitbreiden, klassieke metaboxes toevoegen of op een andere manier afhankelijk zijn van de vorige editor. Bezoek de plugins pagina en klik de “Nu installeren” knop naast &#8220;Klassieke editor&#8221; om de plugin te installeren. Wanneer de plugin klaar is met installeren, klik op “Activeren”. Dat is alles!</p>



<p>Opmerking voor gebruikers van computerhulpmiddelen: als je problemen met de bruikbaarheid ervaart met de Blok-editor, raden we je aan gebruik te maken van de Klassieke editor.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://nl.wordpress.org/2018/12/07/wordpress-5-0-is-vrijgegeven/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:73:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"WordCamps in Nederland in 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://nl.wordpress.org/2018/01/10/wordcamps-in-nederland-in-2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://nl.wordpress.org/2018/01/10/wordcamps-in-nederland-in-2018/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 10 Jan 2018 10:11:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"WordCamp\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://nl.wordpress.org/?p=854\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:415:\"Beste WordCamp Nederland liefhebber, Zoals je mogelijk hebt kunnen zien moesten wij, als organisatie achter WordCamp Nederland, eerst 3 andere WordCamps in Nederland &#8220;laten gebeuren&#8221; voordat we weer een WordCamp Nederland mochten organiseren. Als WordPress Community hebben we hier werk van gemaakt. WordCamp Nijmegen en WordCamp Utrecht staan ondertussen al als twee succesvolle WordCamps die [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Remkus de Vries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2318:\"
<p>Beste WordCamp Nederland liefhebber,</p>



<p>Zoals je mogelijk hebt kunnen zien moesten wij, als organisatie achter WordCamp Nederland, eerst 3 andere WordCamps in Nederland &#8220;laten gebeuren&#8221; <a href=\"https://nl.wordpress.org/2017/06/15/toch-toekomst-voor-wordcamp-nederland/\" target=\"_blank\" rel=\"noopener noreferrer\">voordat we weer een WordCamp Nederland mochten organiseren</a>.</p>



<p>Als WordPress Community hebben we hier werk van gemaakt. WordCamp Nijmegen en WordCamp Utrecht staan ondertussen al als twee succesvolle WordCamps die in de geschiedenisboeken.</p>



<span id=\"more-854\"></span>



<p>Maar daar stopt het niet. We hebben ook in 2018 al een aantal WordCamps op de planning staan. Dit zijn de twee die er op dit moment in de agenda staan:</p>



<p><a href=\"https://2018.noordnederland.wordcamp.org\" target=\"_blank\" rel=\"noopener noreferrer\">WordCamp Noord-Nederland</a> in Drachten, 9 en 10 feb. <a href=\"https://2018.noordnederland.wordcamp.org/tickets/\" target=\"_blank\" rel=\"noopener noreferrer\">Tickets koop je hier</a>.</p>



<p><a href=\"https://rotterdam.wordcamp.org\" target=\"_blank\" rel=\"noopener noreferrer\">WordCamp Rotterdam</a> in, je raadt het nooit, Rotterdam.&nbsp;23 &amp; 24 maart. <a href=\"https://2018.rotterdam.wordcamp.org/tickets/\" target=\"_blank\" rel=\"noopener noreferrer\">Tickets vind je hier</a>.</p>



<p>Daarnaast zijn <a href=\"https://utrecht.wordcamp.org\" target=\"_blank\" rel=\"noopener noreferrer\">WordCamp Utrecht</a> en <a href=\"https://nijmegen.wordcamp.org\" target=\"_blank\" rel=\"noopener noreferrer\">WordCamp Nijmegen</a> alweer voorzichtig bezig met een planning. En uiteraard moeten we onze zuiderburen niet vergeten: WordCamp Antwerp gaat voor de tweede keer alweer los <a href=\"https://antwerp.wordcamp.org\" target=\"_blank\" rel=\"noopener noreferrer\">op 2 &amp; 3 maart 2018</a>.</p>



<p>Al met al zul je de komende tijd steeds meer lokale WordCamps voorbij zien komen. Uiteraard komt er ook weer een WordCamp Nederland aan, maar we wachten nog even met het definitieve plannen hiervan.</p>



<p>Zodra we meer weten laten we het jullie weten.</p>



<p><strong>Update 6 juli 2018:</strong> <a href=\"https://nl.wordpress.org/team/2018/07/06/wordcamps-in-nederland-onze-ervaringen/\">WordCamps in Nederland &#8211; onze ervaringen</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://nl.wordpress.org/2018/01/10/wordcamps-in-nederland-in-2018/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:73:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"Nederlanders krijgen commitrechten op WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"https://nl.wordpress.org/2017/12/12/nederlanders-krijgen-commitrechten-op-wordpress-core/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"https://nl.wordpress.org/2017/12/12/nederlanders-krijgen-commitrechten-op-wordpress-core/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 12 Dec 2017 08:42:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Nieuws\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://nl.wordpress.org/?p=833\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:416:\"WordPress is een Open Source software-project. Dat betekent dat iedereen de broncode van WordPress kan bekijken en suggesties voor verbetering kan aandragen. Gebruikers maken WordPress daarom niet alleen voor elkaar, maar vooral ook met elkaar. Hoewel iedereen verbeteringen kan aandragen, is het daadwerkelijk toevoegen van code aan WordPress voorbehouden aan een vrij selecte groep ervaren WordPressers. [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Taco Verdonschot\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2973:\"<p>WordPress is een Open Source software-project. Dat betekent dat iedereen de broncode van WordPress kan bekijken en suggesties voor verbetering kan aandragen. Gebruikers maken WordPress daarom niet alleen voor elkaar, maar vooral ook met elkaar.</p>
<p>Hoewel iedereen verbeteringen kan aandragen, is het daadwerkelijk toevoegen van code aan WordPress voorbehouden aan een vrij selecte groep ervaren WordPressers. Om dit te kunnen doen heb je zogenaamde commitrechten nodig. Je krijgt deze rechten niet zomaar, want het betekent dat je WordPress voor alle gebruikers kan aanpassen. Het gebeurt dus niet vaak dat er nieuwe committers (mensen met commitrechten) worden toegevoegd aan het project.<span id=\"more-833\"></span></p>
<p>Extra bijzonder is het daarom dat maar liefst twee Nederlanders commitrechten hebben gekregen in de afgelopen 10 dagen. We zetten ze daarom graag even in het zonnetje.</p>
<h3>Juliette Reinders Folmer</h3>
<p><a href=\"https://profiles.wordpress.org/jrf\">Juliette</a> is geen onbekende in de WordPress community. Ze werkt al sinds 2004 met PHP en al sinds 2010 met WordPress, en heeft zeer actief bijgedragen aan diverse plugins en aan WordPress zelf. De afgelopen periode heeft Juliette zich vooral ingezet om te zorgen dat WordPress voldoet aan de WordPress codestandaard. Dit is een set afspraken die WordPress-ontwikkelaars hebben gemaakt over wat goede code is. Haar project zorgt ervoor dat meer dan 60.000 foutmeldingen en waarschuwingen in één klap worden opgelost. Indrukwekkend feit, deze ene patch (verbetering aan de software) heeft meer dan 25% van alle regels code in WordPress gewijzigd!<br />
Meer weten? Op <a href=\"https://nijmegen.wordcamp.org\">WordCamp Nijmegen</a> heeft Juliette over deze patch gesproken. Je kan haar presentatie terugkijken op <a href=\"https://wordpress.tv/2017/10/14/juliette-reinders-folmer-the-biggest-wp-core-patch-ever/\">wordpress.tv</a>.</p>
<h3>Anton Timmermans</h3>
<p>Ook <a href=\"https://profiles.wordpress.org/atimmer\">Anton</a> loopt al lange tijd rond in het WordPress-wereldje. In 2012 ontdekte Anton WordPress, en nog geen jaar later werd zijn eerste verbetering (patch) toegevoegd aan WordPress. De afgelopen tijd heeft zich, samen met zijn collega&#8217;s van <a href=\"https://yoast.com\">Yoast</a>, ingezet voor het verbeteren van de JavaScript documentatie in WordPress. Hierdoor is het voor andere ontwikkelaars makkelijker om de JavaScript-code van WordPress te begrijpen en er op in te haken.</p>
<h3>Zelf ook bijdragen?</h3>
<p>Wil je zelf ook bijdragen aan het verbeteren van WordPress? Dat kan! Op <a href=\"https://make.wordpress.org\">make.wordpress.org</a> vind je een overzicht van de gebieden waarin je kan bijdragen. Elk team heeft een eigen &#8216;Getting started&#8217; sectie in hun handboek. Voor WordPress core kan je deze bijvoorbeeld vinden op <a href=\"https://make.wordpress.org/core/handbook/about/getting-started-at-a-contributor-day/\">Getting started</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"https://nl.wordpress.org/2017/12/12/nederlanders-krijgen-commitrechten-op-wordpress-core/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:35:\"https://nl.wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"
	hourly	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"
	1	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Tue, 01 Jun 2021 10:38:55 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Mon, 29 Mar 2021 06:49:47 GMT\";s:4:\"link\";s:61:\"<https://nl.wordpress.org/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 2\";}}s:5:\"build\";s:14:\"20201016152008\";}","no"),
("582","_transient_timeout_feed_mod_c326b61060938210a1df3d05d623467e","1622587135","no"),
("583","_transient_feed_mod_c326b61060938210a1df3d05d623467e","1622543935","no"),
("584","_transient_timeout_feed_26b0d8e18ed25a5313e8c7eb9c687d1b","1622587135","no"),
("585","_transient_feed_26b0d8e18ed25a5313e8c7eb9c687d1b","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"WordPress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"https://nl.wordpress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 10 Mar 2021 09:48:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"nl\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=5.8-alpha-51050\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:74:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		

			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:8:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 5.7 is vrijgegeven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://nl.wordpress.org/2021/03/10/wordpress-5-7-is-vrijgegeven/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://nl.wordpress.org/2021/03/10/wordpress-5-7-is-vrijgegeven/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 10 Mar 2021 08:15:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://nl.wordpress.org/?p=1149\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:316:\"Fleur je verhalen op in een editor die schoner en scherper is en meer uit de weg gaat. Verken WordPress 5.7. Met deze nieuwe versie brengt WordPress je frisse kleuren. De editor helpt je te werken op een paar plaatsen waar dat voorheen niet mogelijk was—tenminste, niet zonder in de code te duiken of een [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"enclosure\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:60:\"https://s.w.org/images/core/5.7/about-57-drag-drop-image.mp4\";s:6:\"length\";s:6:\"183815\";s:4:\"type\";s:9:\"video/mp4\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Remkus de Vries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5906:\"
<p>Fleur je verhalen op in een editor die schoner en scherper is en meer uit de weg gaat.</p>



<h2>Verken WordPress 5.7.</h2>



<p>Met deze nieuwe versie brengt WordPress je frisse kleuren. De editor helpt je te werken op een paar plaatsen waar dat voorheen niet mogelijk was—tenminste, niet zonder in de code te duiken of een professional in te huren. De bedieningselementen die je het meest gebruikt, zoals het wijzigen van de lettertype grootte, zijn op meer plaatsen te vinden—precies waar je ze nodig hebt. En lay-out wijzigingen die eenvoudig zouden moeten zijn, zoals volledige-hoogte afbeeldingen, zijn nu nog eenvoudiger uit te voeren.</p>



<span id=\"more-1149\"></span>



<h2>De editor is nu makkelijker te gebruiken</h2>



<p><strong>Aanpassing van lettertypegrootte op meer plaatsen:</strong>&nbsp;nu zijn de besturingselementen voor lettertypegrootte precies daar waar je ze nodig hebt in de lijst- en codeblokken. Je hoeft niet meer naar een ander scherm te gaan om die ene wijziging aan te brengen!</p>



<p><strong>Herbruikbare blokken:</strong>&nbsp;verschillende verbeteringen maken herbruikbare blokken stabieler en gemakkelijker te gebruiken. En nu slaan ze automatisch op met het bericht wanneer je op de knop Update klikt.</p>



<p><strong>Inserter verslepen:</strong> sleep blokken en blokpatronen van de inserter rechtstreeks naar je bericht.</p>



<figure class=\"wp-block-embed is-type-rich is-provider-insluiten-handler wp-block-embed-insluiten-handler\"><div class=\"wp-block-embed__wrapper\">
<div style=\"width: 612px;\" class=\"wp-video\"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<video class=\"wp-video-shortcode\" id=\"video-1149-1\" width=\"612\" height=\"344\" preload=\"metadata\" controls=\"controls\"><source type=\"video/mp4\" src=\"https://s.w.org/images/core/5.7/about-57-drag-drop-image.mp4?_=1\" /><a href=\"https://s.w.org/images/core/5.7/about-57-drag-drop-image.mp4\">https://s.w.org/images/core/5.7/about-57-drag-drop-image.mp4</a></video></div>
</div></figure>



<h2>Je kunt meer doen zonder het schrijven van aangepaste code</h2>



<p><strong>Uitlijning op volledige hoogte:</strong>&nbsp;heb je ooit een blok willen maken, zoals het cover-blok, om het hele venster te vullen? Nu kan je dat.</p>



<p><strong>Knoppen blok:</strong>&nbsp;je kunt nu kiezen voor een verticale of horizontale lay-out. En je kunt de breedte van een knop instellen op een vooraf ingesteld percentage.</p>



<p><strong>Sociale pictogrammen blok: </strong>je kunt nu de grootte van de pictogrammen wijzigen.</p>



<figure class=\"wp-block-image size-large\"><img src=\"https://i0.wp.com/s.w.org/images/core/5.7/about-57-cover.jpg\" alt=\"\" /></figure>



<h2>Een eenvoudiger standaard kleurenpalet</h2>



<figure class=\"wp-block-jetpack-image-compare\"><div class=\"juxtapose\" data-mode=\"horizontal\"><img loading=\"lazy\" id=\"1155\" src=\"https://nl.wordpress.org/files/2021/03/about-57-color-old.png\" alt=\"\" width=\"2000\" height=\"1334\" class=\"image-compare__image-before\" /><img loading=\"lazy\" id=\"1156\" src=\"https://nl.wordpress.org/files/2021/03/about-57-color-new.png\" alt=\"\" width=\"2000\" height=\"1334\" class=\"image-compare__image-after\" /></div><figcaption>Hierboven het Dashboard voor en na de kleurenupdate in 5.7.<br></figcaption></figure>



<p>In dit nieuwe gestroomlijnde kleurenpalet worden alle kleuren die vroeger in de WordPress broncode zaten samengevouwen tot zeven core kleuren en een reeks van 56 tinten die voldoen aan de door&nbsp;<a href=\"https://www.w3.org/WAI/WCAG2AAA-Conformance\">WCAG 2.0 AA aanbevolen contrastverhouding</a>&nbsp;tegen wit of zwart.</p>



<p>De kleuren zijn perceptueel uniform van licht tot donker in elk bereik, wat betekent dat ze bij wit beginnen en bij elke stap even veel donkerder worden.</p>



<p>De helft van het bereik heeft een contrastverhouding van 4,5 of hoger tegen zwart, en de andere helft behoudt hetzelfde contrast tegen wit.</p>



<p>Zoek het nieuwe palet in het standaardkleurenschema van WordPress Dashboard en gebruik het bij het bouwen van thema&#8217;s, plugins of andere componenten. Voor alle details,&nbsp;<a href=\"https://make.wordpress.org/core/2021/02/23/standardization-of-wp-admin-colors-in-wordpress-5-7\">bekijk de ontwikkelaar kleurpalet opmerkingen</a>.</p>



<h3>Van HTTP naar HTTPS met een enkele klik</h3>



<p>Vanaf nu is het omzetten van een site van HTTP naar HTTPS een beweging met één klik. WordPress werkt de database URL&#8217;s automatisch bij wanneer je de overstap maakt. Nooit meer jagen en gissen!</p>



<h3>Nieuwe Robots API</h3>



<p>Met de nieuwe Robots API kun je de filter richtlijnen opnemen in de robots metatag, en de API bevat standaard de&nbsp;<code>max-image-preview: large</code>&nbsp;richtlijn. Dat betekent dat zoekmachines grotere afbeelding voorbeelden kunnen tonen, wat je verkeer kan stimuleren (maar niet als de site is gemarkeerd als&nbsp;<em>niet-openbaar</em>).</p>



<h3>Doorlopende schoonmaak na de update naar jQuery 3.5.1</h3>



<p>JQuery heeft jarenlang geholpen om dingen op het scherm te laten bewegen op manieren die de basistools niet konden, maar dat blijft veranderen, en dat geldt ook voor jQuery.</p>



<p>In 5.7 wordt jQuery meer gefocust en minder opdringerig, met minder berichten in de console.</p>



<h3>Lazy-load je iframes</h3>



<p>Het is nu eenvoudig om iframes ook lazy-load te laden. Standaard voegt WordPress het&nbsp;<code>loading=\"lazy\"</code>&nbsp;attribuut toe aan iframe tags wanneer zowel breedte als hoogte zijn opgegeven.</p>



<hr class=\"wp-block-separator\" />



<h3>Bekijk de Field Guide voor meer informatie!</h3>



<p>Bekijk de nieuwste versie van de WordPress Field Guide. Het heeft opmerkingen van ontwikkelaars voor elke wijziging waarvan je op de hoogte wilt zijn:&nbsp;<a href=\"https://make.wordpress.org/core/2021/02/23/wordpress-5-7-field-guide\">WordPress 5.7 Field Guide</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://nl.wordpress.org/2021/03/10/wordpress-5-7-is-vrijgegeven/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:73:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 5.6 is vrijgegeven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://nl.wordpress.org/2020/12/08/wordpress-5-6-is-vrijgegeven/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://nl.wordpress.org/2020/12/08/wordpress-5-6-is-vrijgegeven/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 08 Dec 2020 22:23:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://nl.wordpress.org/?p=1143\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:347:\"Het delen van je verhalen is nog nooit zo eenvoudig geweest. WordPress 5.6 biedt je talloze manieren om je ideeën de vrije loop te laten en ze tot leven te brengen. Met een gloednieuw standaardthema als je canvas, ondersteunt het een steeds groter wordende verzameling blokken als je penselen. Verf met woorden. Afbeeldingen. Geluid. Of [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Remkus de Vries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6306:\"
<p class=\"has-background has-large-font-size\" style=\"background-color:#d1e4dd\">Het delen van je verhalen is nog nooit zo eenvoudig geweest.</p>



<p>WordPress 5.6 biedt je talloze manieren om je ideeën de vrije loop te laten en ze tot leven te brengen. Met een gloednieuw standaardthema als je canvas, ondersteunt het een steeds groter wordende verzameling blokken als je penselen. Verf met woorden. Afbeeldingen. Geluid. Of rich embedded media.</p>



<h2>Meer flexibiliteit in de lay-out</h2>



<p>Breng je verhalen tot leven met meer gereedschappen waarmee je je lay-out met of zonder code kunt bewerken. Blokken met één kolom, ontwerpen met verschillende breedtes en kolommen, headers over de volledige breedte en video&#8217;s in je cover blok &#8211; breng met hetzelfde gemak kleine wijzigingen of grote uitspraken aan!</p>



<h2>Meer blokpatronen</h2>



<p>In geselecteerde thema&#8217;s maken voor-geconfigureerde blokpatronen het opzetten van standaardpagina&#8217;s op je site een fluitje van een cent. Ontdek de kracht van patronen om je workflow te stroomlijnen, of deel een deel van die kracht met je klanten en bespaar jezelf een paar klikken.</p>



<h2>Upload videobijschriften direct in de blokeditor</h2>



<p>Om je te helpen ondertiteling of bijschriften toe te voegen aan je videos, kan je ze nu uploaden in je bericht of pagina. Dit maakt het makkelijker dan ooit om videos toegankelijk te maken voor iedereen die ondertiteling nodig heeft of hiervoor de voorkeur voor heeft.</p>



<h2>Twenty Twenty-One is er!</h2>



<p>Twenty Twenty-One is een leeg canvas voor je ideeën en de blok-editor is het beste penseel. Het is gebouwd voor de blok-editor en zit boordevol gloednieuwe blokpatronen die je alleen in de standaardthema&#8217;s kunt krijgen. Probeer binnen enkele seconden verschillende lay-outs uit en laat het opvallende, maar tijdloze ontwerp van het thema je werk doen stralen.</p>



<div class=\"wp-block-image\"><figure class=\"aligncenter size-large\"><img src=\"https://s.w.org/images/core/5.6/twentytwentyone-layouts.jpg\" alt=\"\" /></figure></div>



<p>Aanvullend, dit standaardthema zet de toegankelijkheid in het hart van je site. Het voldoet aan de&nbsp;<a href=\"https://make.wordpress.org/themes/handbook/review/accessibility/\">WordPress accessibility-ready</a>&nbsp;richtlijnen en behandeld verschillende meer gespecialiseerde normen van de&nbsp;<a href=\"https://www.w3.org/WAI/WCAG2AAA-Conformance\">Web Content Accessibility Guidelines (WCAG) 2.1 at level AAA</a>. Het helpt je bij het voldoen aan het hoogste niveau van internationale toegankelijkheidsnormen wanneer je toegankelijke inhoud maakt en kiest plugins die ook toegankelijk zijn!</p>



<h2>Een regenboog van zachte pastelkleuren</h2>



<figure class=\"wp-block-image size-large\"><img src=\"https://s.w.org/images/core/5.6/twentytwentyone-rainbow.png\" alt=\"\" /></figure>



<p>Twenty Twenty-One is perfect voor een nieuw jaar en biedt je een reeks vooraf geselecteerde kleurenpaletten in pastelkleuren, die allemaal voldoen aan de AAA-normen voor contrast. Je kan ook je eigen achtergrondkleur voor het thema kiezen, en het thema kiest automatisch bewust toegankelijke tekstkleuren voor je!</p>



<p>Meer flexibiliteit nodig dan dat? Je kunt ook je eigen kleurenpalet kiezen uit de kleurenkiezer.</p>



<figure class=\"wp-block-image size-large\"><img src=\"https://i0.wp.com/wordpress.org/news/files/2020/12/WordPress5-6-3.jpeg?w=1264&amp;ssl=1\" alt=\"\" /></figure>



<h2>Verbeteringen voor iedereen</h2>



<h3>Auto-updates uitgebreid</h3>



<p>Jarenlang konden alleen ontwikkelaars WordPress automatisch updaten. Maar nu heb je die optie, rechtstreeks in je dashboard. Als dit je eerste site is, heb je nu auto-updates klaar voor gebruik! Een bestaande site upgraden? Geen probleem! Alles is hetzelfde als voorheen.</p>



<h3>Template voor toegankelijkheidsverklaring</h3>



<p>Zelfs als je geen expert bent, kun je mensen met een klik op de knop laten weten dat je site zich inzet voor toegankelijkheid! De nieuwe&nbsp;<a href=\"https://github.com/10degrees/accessibility-statement-plugin\">functie plugin</a>&nbsp;bevat een template kopie die je kan updaten en publiceren, en het is geschreven om verschillende contexten en rechtsgebieden te ondersteunen.</p>



<h3>Ingebouwde patronen</h3>



<p>Als je nog niet de kans hebt gehad om met blokpatronen te spelen, hebben alle standaardthema&#8217;s nu een reeks blokpatronen waarmee je complexe lay-outs met minimale inspanning onder de knie kunt krijgen. Pas de patronen naar wens aan met de tekst, afbeeldingen en kleuren die bij je verhaal of merk passen.</p>



<h2>Voor ontwikkelaars</h2>



<h3>REST API authenticatie met applicatie wachtwoorden</h3>



<p>Dankzij de nieuwe autorisatiefunctie voor Application Passwords van de API kunnen apps van derden naadloos en veilig verbinding maken met je site. Met deze nieuwe REST API functie kan je zien welke apps verbinding maken met je site en bepalen wat ze doen.</p>



<h3>Meer ondersteuning voor PHP 8</h3>



<p>5.6 markeert de eerste stappen in de richting van WordPress Core ondersteuning voor PHP 8. Dit is een goed moment om te plannen hoe je WordPress producten, diensten en sites de nieuwste PHP-versie kunnen ondersteunen. Voor meer informatie over wat je kan verwachten,&nbsp;<a href=\"https://make.wordpress.org/core/2020/11/23/wordpress-and-php-8-0/\">lees de PHP 8 ontwikkelaar notitie</a>.</p>



<h3>jQuery</h3>



<p>Updates voor jQuery in WordPress vinden plaats in drie releases:5.5, 5.6 en 5.7. Als we het midden van dit proces hebben bereikt, voer je de update test plugin uit om je sites van tevoren op fouten te controleren.</p>



<p>Als je problemen hebt met de manier waarop je site er uitziet (bijv. een slider werkt niet, een knop zit vast &#8211; dat soort dingen), installeer dan de <a href=\"https://wordpress.org/plugins/enable-jquery-migrate-helper/\">jQuery Migrate plugin</a>.</p>



<hr class=\"wp-block-separator\" />



<h3>Bekijk de Field Guide voor meer informatie!</h3>



<p>Bekijk de nieuwste versie van de WordPress Field Guide. Het heeft opmerkingen van ontwikkelaars voor elke wijziging waarvan je op de hoogte wil zijn:&nbsp;<a href=\"https://make.wordpress.org/core/2020/11/20/wordpress-5-6-field-guide/\">WordPress 5.6 Field Guide</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://nl.wordpress.org/2020/12/08/wordpress-5-6-is-vrijgegeven/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:73:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 5.5 is vrijgegeven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://nl.wordpress.org/2020/08/11/wordpress-5-5-is-vrijgegeven/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://nl.wordpress.org/2020/08/11/wordpress-5-5-is-vrijgegeven/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 11 Aug 2020 20:13:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://nl.wordpress.org/?p=1102\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:403:\"In WordPress 5.5 wordt je site beter in drie belangrijke gebieden: snelheid, zoeken en veiligheid. Snelheid Berichten en pagina&#8217;s voelen sneller aan, dankzij &#8216;lazy-loaded&#8217; afbeeldingen. Afbeeldingen kunnen je verhaal veel impact geven, maar zij kunnen soms je site langzaam maken. In WordPress 5.5 wachten afbeeldingen met inladen totdat zij door het scrollen in beeld komen. [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Remkus de Vries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6495:\"
<p>In WordPress 5.5 wordt je site beter in drie belangrijke gebieden: snelheid, zoeken en veiligheid.</p>



<h2>Snelheid</h2>



<p><strong>Berichten en pagina&#8217;s voelen sneller aan, dankzij &#8216;lazy-loaded&#8217; afbeeldingen.</strong></p>



<p>Afbeeldingen kunnen je verhaal veel impact geven, maar zij kunnen soms je site langzaam maken.</p>



<p>In WordPress 5.5 wachten afbeeldingen met inladen totdat zij door het scrollen in beeld komen. De technische term is &#8216;lazy-loading&#8217;.</p>



<p>Op mobiel kan lazy-loading ervoor zorgen dat browsers geen bestanden downloaden die bedoeld zijn voor andere apparaten. Dat bespaart je lezers kosten voor datagebruik en helpt de levensduur van de batterij te verlengen.</p>



<h2>Zoeken</h2>



<p><strong>Verwelkom je nieuwe sitemap.</strong></p>



<p>WordPress sites werken goed met zoekmachines.</p>



<p>WordPress 5.5 bevat nu standaard een XML-sitemap, die zoekmachines helpt je meest belangrijke pagina&#8217;s te vinden vanaf het moment je live gaat met je site.</p>



<p>Daardoor vinden meer mensen je site, en dat geeft je meer tijd om ze te boeien, om ze vast te houden en om ze te converteren naar abonnee, klant, of hoe jij succes ook definieert</p>



<h2>Beveiliging</h2>



<p><strong>Auto-updates voor plugins en thema&#8217;s</strong></p>



<p>Je kan nu in de WordPress-admin instellen dat plugins en thema&#8217;s automatisch worden geüpdatet — of niet natuurlijk! Zo weet je zeker dat je site altijd de meest recente code draait.</p>



<p>Je kan auto-updates in- of uitschakelen voor elke plugin of elk thema die je hebt geïnstalleerd — alles op dezelfde schermen zoals je gewend bent.</p>



<p><strong>Bijwerken door het uploaden van ZIP bestanden</strong></p>



<p>Als handmatig updaten van plugins en thema&#8217;s je ding is, dan is dat nu ook eenvoudiger — simpel door een ZIP bestand uploaden.</p>



<h2>Hoogtepunten van de blok-editor</h2>



<p>Wederom zit de laatste release van WordPress bomvol spannende nieuwe functies voor de blok-editor. Bijvoorbeeld:</p>



<h3>Blokpatronen</h3>



<p>Nieuwe blokpatronen maken het simpel en leuk om prachtige, complexe lay-outs te maken door gebruik te maken van een combinatie van tekst en media om je verhaal te vertellen.</p>



<p>Je vindt blokpatronen ook in een uitgebreid aanbod aan plugins en thema&#8217;s, en er worden continue nieuwe toegevoegd. Kies ze vanuit een enkele locatie — gewoon klikken en gaan!</p>



<p>Er zijn verschillende blok lay-outs in dit tabblad. Na het scrollen door opties, waaronder knoppen en kolommen, wordt een patroon gekozen genaamd &#8220;Grote header met een header&#8221;. Dit voegt een cover blok toe, dat is aangepast met een foto en de naam van de WordPress 5.5 jazzmuzikant.</p>



<hr class=\"wp-block-separator\" />



<h3>Inline afbeelding bewerking</h3>



<p>Vanuit het afbeeldingsblok kan je nu meteen je foto&#8217;s bijsnijden, roteren en inzoomen. Als je veel tijd besteedt aan afbeeldingen, dan kan dit je uren besparen!</p>



<h3>De nieuwe blok bibliotheek</h3>



<p>Het is nu makkelijker dan ooit om het blok te vinden wat je nodig hebt. De nieuwe blok bibliotheek is in de blok-editor gebouwd, zodat je nieuwe bloktypes kunt installeren voor je site zonder de editor te verlaten.</p>



<h3>En zo veel meer.</h3>



<p>De hoogtepunten hierboven zijn maar een klein gedeelte van de nieuwe mogelijkheden van de blok-editor die je net hebt geïnstalleerd. Open de blok-editor en geniet ervan!</p>



<h2>Toegankelijkheid</h2>



<p>Iedere release voegt verbeteringen toe aan de toegankelijke publicatie ervaring, en dat geldt ook voor WordPress 5.5.</p>



<p>Nu kun je links kopiëren in mediaschermen en modale dialogen met een knop, in plaats van te proberen een regel tekst te markeren.</p>



<p>Je kan ook metaboxen verplaatsen met je toetsenbord, en afbeeldingen in WordPress bewerken met je ondersteunende apparaat, omdat het de instructies in de afbeeldingseditor kan lezen.</p>



<h2>Voor ontwikkelaars</h2>



<p>WordPress 5.5 komt ook met een grote hoeveelheid wijzigingen alleen voor ontwikkelaars.</p>



<h3>Server-side geregistreerde blokken in de REST API</h3>



<p>Het toevoegen van endpoints voor bloktypes betekent dat JavaScript apps (zoals de blok-editor) definities op kunnen halen voor alle blokken die zijn geregistreerd op de server.</p>



<h3>Dashicons</h3>



<p>De Dashicons bibliotheek heeft zijn laatste update gekregen in 5.5. Het voegt 39 blok-editor pictogrammen toe samen met 26 andere.</p>



<h3>Definieer omgevingen</h3>



<p>WordPress heeft de manier waarop het type omgeving van je site (staging, productie, etc) wordt gedefinieerd gestandaardiseerd. Haal dat type op met&nbsp;<code>wp_get_environment_type()</code>&nbsp;en voer alleen de daarvoor bedoelde code uit.</p>



<h3>Gegevens doorgeven aan template bestanden</h3>



<p>De template-laadfuncties (<code>get_header()</code>,&nbsp;<code>get_template_part()</code>, etc.) hebben een nieuw&nbsp;<code>$args</code>-argument. Je kan vanaf nu een hele array aan data meegeven aan deze templates.</p>



<h3>Meer wijzigingen voor ontwikkelaars</h3>



<ul><li>De PHPMailer bibliotheek heeft een grote update gehad, van versie 5.2.27 naar 6.1.6.</li><li>Krijg preciezere controle over&nbsp;<code>redirect_guess_404_permalink()</code>.</li><li>Sites die gebruik maken van PHP&#8217;s OPcache hebben een betrouwbaardere cache-invalidatie dankzij de nieuwe&nbsp;<code>wp_opcache_invalidate()</code>-functie tijdens updates (ook van plugins en thema&#8217;s).</li><li>Extra berichttypen die aan de categorie-taxonomie zijn gekoppeld, kunnen nu via opt-in de standaardterm te ondersteunen.</li><li>Standaardtermen kunnen nu worden gespecificeerd voor aangepaste taxonomieën in&nbsp;<code>register_taxonomy()</code>.</li><li>De REST-API ondersteunt nu officieel het specificeren van standaard metadata waarden via&nbsp;<code>register_meta()</code>.</li><li>Je krijgt bijgewerkte versies van de volgende gebundelde libraries: SimplePie, Twemoji, Masonry, imagesLoaded, getID3, Moment.js, and clipboard.js.</li></ul>



<h3>Bekijk de Field Guide voor meer informatie!</h3>



<p>Er is nog veel meer voor ontwikkelaars om van te houden in WordPress 5.5. Raadpleeg de <a href=\"https://make.wordpress.org/core/wordpress-5-5-field-guide/\">WordPress 5.5 Field Guide</a> om meer te ontdekken en te leren hoe je deze wijzigingen kunt laten schitteren op je sites, thema&#8217;s, plugins en meer.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://nl.wordpress.org/2020/08/11/wordpress-5-5-is-vrijgegeven/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"8\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:73:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 5.4 is vrijgegeven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://nl.wordpress.org/2020/04/01/wordpress-5-4-is-vrijgegeven/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://nl.wordpress.org/2020/04/01/wordpress-5-4-is-vrijgegeven/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 01 Apr 2020 08:17:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Algemeen\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://nl.wordpress.org/?p=1086\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:341:\"Zeg hallo tegen meer en beter. Meer mogelijkheden om je pagina&#8217;s tot leven te brengen. Met eenvoudigere manier om van alles mogelijk te maken, beter dan ooit en een verbetering in snelheid die je echt kunt voelen. Welkom bij WordPress 5.4. Iedere grote release voegt meer toe aan de blok-editor. Meer manieren om je berichten [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Remkus de Vries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5315:\"
<h1>Zeg hallo tegen meer en beter.</h1>



<p>Meer mogelijkheden om je pagina&#8217;s tot leven te brengen. Met eenvoudigere manier om van alles mogelijk te maken, beter dan ooit en een verbetering in snelheid die je echt kunt voelen.</p>



<h2>Welkom bij WordPress 5.4.</h2>



<p>Iedere grote release voegt meer toe aan de blok-editor.</p>



<p>Meer manieren om je berichten en pagina&#8217;s tot leven te laten komen met je beste afbeeldingen. Meer manieren om je bezoekers binnen te halen en betrokken te houden met de rijkdom van ingesloten media van het web&#8217;s top diensten.</p>



<p>Meer manieren om jouw visie echt te make. Zet blokken op de perfect plek neer. Zelfs als het specifieke blok nieuw voor je is. Meer efficiëntere processen.</p>



<p>En meer snelheid in heel veel andere opties. Bijvoorbeeld in het maken van groepen of gallerijen. Je kunt zoveel sneller werken nu!</p>



<h2>Twee nieuwe blokken. En betere blokken in het algemeen.</h2>



<ul><li>Twee gloednieuwe blokken: Sociale iconen en knoppen maken het toevoegen van interactieve functies snel en gemakkelijk.</li><li>Meer opties met kleuren: gradients in de knoppen en cover blok, toolbar toegang to kleur opties in de tekstblokken, en voor het eerst nu, kleur opties in de Groep en Kolom blokken.</li><li>Je hoeft een stuk minder te gokken! Versie 5.4 stroomlijnt het hele proces voor het plaatsen en vervangen van multimedia in elk blok. Nu werkt het op dezelfde manier in bijna elk blok!</li><li>Als je ooit hebt gedacht dat je afbeelding in het Media+Tekst blok zou moeten linken naar wat anders zou, misschien zou de foto van een brochure bijvoorbeeld de brochure zelf moeten downloaden als een document? Vanaf nu kan dat.</li></ul>



<h2>Strakkere UI, duidelijkere navigatie en eenvoudiger met tab doorheen te navigeren!</h2>



<ul><li>Duidelijkere blok navigatie met blok-kruimelpad. En een eenvoudigere selectie eens je daar bent.</li><li>Voor wanneer je moet navigeren met het toetsenbord, beter met tabben werken en focus. Plus, je kunt met tab naar de sidebar navigeren van bijna elk blok.</li><li>Snelheid! 14% sneller laden van de editor en 51% sneller om te kunnen typen!</li><li>Tips zijn verdwenen. Maar in plaats daarvan hebben we een Welkom Gids scherm die je tevoorschijn kunt toveren. Zo vaak je maar wilt.</li><li>Zie direct of je in de wijzig- of navigatiemodus van een blok zit. Of, wanneer je beperkt zicht hebt zal je screenreader je vertellen in welke modus je zit.</li></ul>



<p>Als je met de allerlaatste tools en mogelijkheden wilt werken, installeer dan de <a href=\"https://wordpress.org/plugins/gutenberg/\">Gutenberg plugin</a>. Je bent dan één van de eersten die met nieuwe en interessante mogelijkheden in de blok editor werkt!</p>



<h2>Je fundamentele recht: privacy</h2>



<p>WordPress 5.4 helpt je met een aantal verschillende wereldwijde privacy punten. Dus wanneer je gebruikers en andere belanghebbenden vragen hebben over naleving van de regelgeving, of hoe je team omgaat met gebruikersdata, dan zou je nu het antwoord een stuk eenvoudiger juist moeten kunnen krijgen.</p>



<p>Neem een kijkje:</p>



<ul><li>Persoonlijke data exports zijn nu inclusief informatie over gebruikerssessies en gebruikers locatie data van de community evenementen widget. Plus, een overzichtstabel.</li><li>Zie de voortgang van export en verwijderverzoeken via de privacy tools.</li><li>Aanvullend, kleine verbeteringen waardoor de Privacy Tools er net even wat strakker uit zien.</li></ul>



<h2>Speciaal voor ontwikkelaars</h2>



<h3>Voeg custom fields toe aan menu-items&#8211;standaard</h3>



<p>Twee nieuwe acties maken het je mogelijk om custom fields aan het menu toe te voegen. Zonder aparte plugin en zonder maatwerk code.</p>



<p>Op het Menu admin scherm, wordt <code>wp_nav_menu_item_custom_fields</code>&nbsp;uitgevoerd net voor de verschuifknoppen van een navigatie menu item in de menu editor.</p>



<p>In de Customizer,&nbsp;<code>wp_nav_menu_item_custom_fields_customize_template</code>&nbsp;wordt uitgevoerd aan het eind van de menu onderdelen form-fields template.</p>



<p>Check je code en bekijk of deze nieuwe acties jouw code kunnen vervangen. Als je bezorgt bent voor duplicatie, voeg dan een WordPress versiespecifieke check toe.</p>



<h3>Blokken! Eenvoudiger vormgeving, nieuwe API&#8217;s en insluitingen.</h3>



<ul><li>Blokvormgeving is <strong>drastisch</strong> vereenvoudigd. Negatieve margins en standaard padding zijn verdwenen! Je kunt blokken nu vormgeven zoals je wenst. Ook zijn vier onnodige wrapper div&#8217;s opgeschoond.</li><li>Als je plugins ontwikkelt, dan kun je nu verzamelingen van je blokken registeren via de namespace over verschillende categorieën. Een mooie manier om je merk meer zichtbaarheid te geven.</li><li>Twee nieuwe API&#8217;s bieden gebruikers meer mogelijkheden: blokvarianten en kleurverlopen.</li><li>De blokeditor (Gutenberg) ondersteunt nu TikTok in ingesloten code. CollegeHumor is verwijderd.</li></ul>



<p>Er zitten ontzettend veel fijne verbeteringen voor ontwikkelaars in WordPress 5.4. Als je meer wilt weten hoe je je websites, thema&#8217;s en plugins beter kunt maken, bekijk dan de <a href=\"https://make.wordpress.org/core/2020/03/03/wordpress-5-4-field-guide/\">WordPress 5.4 Field Guide</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://nl.wordpress.org/2020/04/01/wordpress-5-4-is-vrijgegeven/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:73:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 5.3 is vrijgegeven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://nl.wordpress.org/2019/11/13/wordpress-5-3-is-vrijgegeven/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://nl.wordpress.org/2019/11/13/wordpress-5-3-is-vrijgegeven/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 13 Nov 2019 10:11:19 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://nl.wordpress.org/?p=1064\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:407:\"We introduceren onze meest verfijnde gebruikerservaring met de verbeterde blokeditor in WordPress 5.3! WordPress 5.3 maakt de blokeditor, die is geïntroduceerd in WordPress 5.0, nog beter en het heeft nu ook een nieuwe blok, meer intuïtieve interacties en verbeterde toegankelijkheid. Nieuwe functies in de editor vergroten de ontwerp vrijheid, bieden extra lay-outopties en stijlvariaties zodat [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Remkus de Vries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5228:\"
<p><strong>We introduceren onze meest verfijnde gebruikerservaring met de verbeterde blokeditor in WordPress 5.3!</strong></p>



<p>WordPress 5.3 maakt de blokeditor, die is geïntroduceerd in WordPress 5.0, nog beter en het heeft nu ook een nieuwe blok, meer intuïtieve interacties en verbeterde toegankelijkheid. Nieuwe functies in de editor vergroten de ontwerp vrijheid, bieden extra lay-outopties en stijlvariaties zodat ontwerpers volledige controle hebben over het uiterlijk van hun website. </p>



<p>Deze release introduceert ook het Twenty Twenty thema waardoor de gebruiker meer ontwerpflexibiliteit en integratie met de blokeditor heeft. Het maken van prachtige webpagina&#8217;s en geavanceerde lay-outs is nog nooit zo eenvoudig geweest.</p>



<span id=\"more-1064\"></span>



<h2>Verbeteringen blok-editor</h2>



<p>Deze op verbeteringen gerichte update introduceert meer dan 150 nieuwe functies en gebruiksverbeteringen, waaronder verbeterde ondersteuning van grote afbeeldingen voor het uploaden van niet-geoptimaliseerde foto&#8217;s met een hoge resolutie die zijn gemaakt met je smartphone of andere hoogwaardige camera&#8217;s. In combinatie met grotere standaard afbeeldingsformaten zien foto&#8217;s er altijd op hun best uit.</p>



<p>De verbeteringen van de toegankelijkheid omvat de integratie van stijlen voor blokeditor in de beheerinterface. Deze verbeterde stijlen lossen veel toegankelijkheidsproblemen op: kleurcontrast op formuliervelden en knoppen, consistentie tussen editor- en admin-interfaces, nieuwe notificaties, standaardisatie naar het standaard WordPress-kleurenschema en de introductie van animatie om interactie met je blokken snel en natuurlijk aan te laten voelen. </p>



<p>Voor mensen die een toetsenbord gebruiken om door het dashboard te navigeren, heeft de blokeditor nu ook een navigatiemodus. Hiermee kan je van blok naar blok springen zonder door elk deel van de blokbesturing te bladeren.</p>



<h2>Uitgebreide design flexibiliteit</h2>



<p>WordPress 5.3 voegt nog meer gereedschappen toe om geweldige ontwerpen mee te maken.</p>



<ul><li>Het nieuwe Groep blok staat je toe om jouw pagina makkelijk op te delen in kleurrijke secties.</li><li>Het Kolom blok ondersteund vanaf nu vaste kolombreedtes</li><li>De nieuwe vooraf gedefinieerde lay-outs maken het heel simpel om inhoud in geavanceerde lay-outs te ontwerpen</li><li>De tekstkleur van titelblokken is nu instelbaar</li><li>Met extra stijlopties kan je de gewenste stijl instellen voor elke blok dat deze functie ondersteunt</li></ul>



<h2>Introductie Twenty Twenty</h2>



<figure class=\"wp-block-image size-large\"><img src=\"https://s.w.org/images/core/5.3/twentytwenty-desktop.png\" alt=\"\" /></figure>



<p>Terwijl de blokeditor zijn eerste verjaardag viert, zijn we er trots op dat Twenty Twenty is ontworpen met flexibiliteit in de kern. Pronk met je diensten of producten met een combinatie van kolommen, groepen en mediablokken. Stel je inhoud in op breed of volledige uitlijning voor dynamische en boeiende lay-outs.</p>



<p>Twenty Twenty heeft, zoals het hoort, een sterke focus op overzichtbaarheid en leesbaarheid. Het thema bevat het typeface&nbsp;<a href=\"https://rsms.me/inter/\">Inter</a>&nbsp;wat ontworpen is door Rasmus Andersson. Inter is beschikbaar als een Variable Font versie, voor het eerst in een standaard thema, wat maakt dat de laadtijd kort houd door alle stijlen van Inter in slechts twee font bestanden beschikbaar zijn.</p>



<h2>Verbeteringen voor iedereen</h2>



<h3>Automatische afbeeldingsrotatie</h3>



<p>Je afbeeldingen zullen nu op de correcte manier gedraaid zijn wanneer je ze uploadt gebaseerd op de orientatiedata. Deze verbetering is negen jaar geleden voorgesteld en mogelijk gemaakt door het doorzettingsvermogen van vele volhardende bijdragers.</p>



<h3>Sitediagnose controles</h3>



<p>De verbeteringen die geïntroduceerd worden in 5.3 maken het zelfs makkelijker om problemen te detecteren. Uitgebreide aanbevelingen brengen lichten bepaalde onderdelen uit die aandacht nodig hebben in het Health Check scherm.</p>



<h3>Admin e-mail verificatie</h3>



<p>Je wordt nu periodiek gevraagd om je admin email adres te bevestigen wanneer je ingelogd bent als een administrator. Dit maakt de kans een stuk kleiner dat je niet meer in je site kunt komen wanneer je je email adres wijzigt.</p>



<h2>Voor ontwikkelaars</h2>



<h3>Date/Time component verbeteringen</h3>



<p>Ontwikkelaars kunnen nu werken met&nbsp;<a href=\"https://make.wordpress.org/core/2019/09/23/date-time-improvements-wp-5-3/\">data en tijdzones</a>&nbsp;in een betrouwbaardere manier. Datum en tijd functionaliteit heeft een aantal nieuwe API functies toegevoegd gekregen voor unified timezone retrieval en PHP interoperability en daarnaast zijn er ook een hoop bug fixes doorgevoerd.</p>



<h3>PHP 7.4 compatibiliteit</h3>



<p>WordPress 5.3 ondersteunt PHP 7.4 volledig. Deze release bevat&nbsp;<a href=\"https://make.wordpress.org/core/2019/10/11/wordpress-and-php-7-4/\">meerdere wijzigingen</a>&nbsp;die verouderde functionaliteit verwijderen en de compatibiliteit verzekeren. WordPress blijft gebruikers aanbevelen om de laatste en beste versie van PHP te gebruiken.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://nl.wordpress.org/2019/11/13/wordpress-5-3-is-vrijgegeven/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:73:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 5.2 is vrijgegeven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://nl.wordpress.org/2019/05/08/wordpress-5-2-is-vrijgegeven/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://nl.wordpress.org/2019/05/08/wordpress-5-2-is-vrijgegeven/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 May 2019 08:11:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://nl.wordpress.org/?p=1041\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:337:\"Met deze update is het gemakkelijker dan ooit om je site te repareren als er iets misgaat. Houd je site veilig WordPress 5.2 geeft je nog meer robuuste gereedschappen voor het identificeren en repareren van configuratieproblemen en fatale fouten. Of je nu een ontwikkelaar bent die klanten helpt of dat je zelf je site beheert, [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Remkus de Vries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3632:\"
<p>Met deze update is het gemakkelijker dan ooit om je site te repareren als er iets misgaat.</p>



<h2>Houd je site veilig</h2>



<p>WordPress 5.2 geeft je nog meer robuuste gereedschappen voor het identificeren en repareren van configuratieproblemen en fatale fouten. Of je nu een ontwikkelaar bent die klanten helpt of dat je zelf je site beheert, deze gereedschappen kunnen je aan de juiste informatie helpen op het moment dat je het nodig hebt.</p>



<figure class=\"wp-block-image\"><img src=\"https://s.w.org/images/core/5.2/about_maintain-wordpress-v2.svg\" alt=\"\" /></figure>



<span id=\"more-1041\"></span>



<h3>Sitediagnose controle</h3>



<div class=\"wp-block-image\"><figure class=\"alignright\"><img src=\"https://s.w.org/images/core/5.2/about_site-health.svg\" alt=\"\" /></figure></div>



<p>Voortbordurend op&nbsp;<a href=\"https://wordpress.org/news/2019/02/betty/\">de Sitediagnose features geïntroduceerd in 5.1</a>, voegt deze release twee nieuwe pagina&#8217;s toe om je te helpen veelvoorkomende problemen in de configuratie op te lossen. Er wordt ook een ruimte toegevoegd waar ontwikkelaars informatie kunnen toevoegen voor mensen die sites onderhouden.&nbsp;Ontdek meer of je site status, en&nbsp;leer hoe je issues kunt oplossen.</p>



<h3>PHP foutbescherming</h3>



<div class=\"wp-block-image\"><figure class=\"alignright\"><img src=\"https://s.w.org/images/core/5.2/about_error-protection.svg\" alt=\"\" /></figure></div>



<p>Deze update met een focus op beheerders laat je op een veilige manier fatale fouten herstellen of beheren, zonder dat het ontwikkeltijd kost. Er is een betere afhandeling van de zogenaamde &#8220;white screen of death&#8221; en een manier om in herstelmodus te komen. De herstelmodus pauzeert plugins of thema&#8217;s die voor fouten zorgen.</p>



<h3>Verbeteringen voor iedereen</h3>



<h4>Toegankelijkheid updates</h4>



<p>Een aantal verbeteringen werken samen om de contextuele positie en flow van de toetsenbordnavigatie te verbeteren voor zij die screenreaders en andere ondersteunende technologie gebruiken.</p>



<h4>Nieuwe dashboard iconen</h4>



<p>Dertien nieuwe icoontjes, inclusief Instagram, een aantal BuddyPress icoontjes en verschillende versies van de wereldbol zijn toegevoegd. Je vindt ze terug in het Dashboard. Veel plezier ermee!</p>



<h3>Hier worden ontwikkelaars blij van</h3>



<h4><a href=\"https://make.wordpress.org/core/2019/03/26/coding-standards-updates-for-php-5-6/\">PHP versie update</a></h4>



<p>De minimum ondersteunde PHP versie is nu 5.6.20. Vanaf WordPress 5.2 kunnen thema&#8217;s en plugins veilig gebruik maken van de voordelen van namespaces, anonymous functions, en meer!</p>



<h4><a href=\"https://make.wordpress.org/core/2019/04/24/developer-focused-privacy-updates-in-5-2/\">Privacy updates</a></h4>



<p>Een nieuwe thema pagina template, een conditionele functie en twee CSS classes maken het ontwerpen en aanpassen van de Privacy Policy pagina eenvoudiger.</p>



<h4><a href=\"https://make.wordpress.org/core/2019/04/24/miscellaneous-developer-updates-in-5-2/\">Nieuwe Body Tag hook</a></h4>



<p>5.2 introduceert een&nbsp;<code>wp_body_open</code>&nbsp;hook die thema&#8217;s toestaat code toe te voegen helemaal aan het begin van het&nbsp;<code>&lt;body&gt;</code>&nbsp;element.</p>



<h4><a href=\"https://make.wordpress.org/core/2019/03/25/building-javascript/\">JavaScript</a></h4>



<p>Met de toevoeging van webpack en Babel instellingen in het wordpress/scripts package hoeven ontwikkelaars niet meer bezig te zijn om uit te zoeken hoe ze complexe build tools moeten gebruiken om moderne JavaScript the schrijven.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://nl.wordpress.org/2019/05/08/wordpress-5-2-is-vrijgegeven/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:73:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 5.1 is vrijgegeven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://nl.wordpress.org/2019/02/22/wordpress-5-1-is-vrijgegeven/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://nl.wordpress.org/2019/02/22/wordpress-5-1-is-vrijgegeven/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 Feb 2019 08:11:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://nl.wordpress.org/?p=1027\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:440:\"In navolging op WordPress 5.0—een grote release waar de nieuwe blok editor werd geïntroduceerd—is 5.1 vooral toegespitst op verfijning, specifiek performance-verbeteringen van de editor. Ook baant deze release een weg naar een betere, snellere en veiligere WordPress installatie met een aantal essentiële gereedschappen voor sitebeheerders en ontwikkelaars. Sitediagnose Deze release introduceert, met veiligheid en snelheid [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Remkus de Vries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3876:\"
<p>In navolging op <a href=\"https://nl.wordpress.org/2018/12/07/wordpress-5-0-is-vrijgegeven/\">WordPress 5.0</a>—een grote release waar de nieuwe blok editor werd geïntroduceerd—is 5.1 vooral toegespitst op verfijning, specifiek performance-verbeteringen van de editor. Ook baant deze release een weg naar een betere, snellere en veiligere WordPress installatie met een aantal essentiële gereedschappen voor sitebeheerders en ontwikkelaars.</p>



<h3>Sitediagnose</h3>



<div class=\"wp-block-image\"><figure class=\"alignright\"><img src=\"https://s.w.org/images/core/5.1/site-health.svg\" alt=\"\" /></figure></div>



<p>Deze release introduceert, met veiligheid en snelheid in het achterhoofd, de eerste&nbsp;<a href=\"https://make.wordpress.org/core/2019/01/14/php-site-health-mechanisms-in-5-1/\">Sitediagnose</a>&nbsp;kenmerken. Zo zal WordPress berichten gaan tonen aan beheerders van sites die zeer oude versies van PHP draaien, de programmeertaal waar WordPress in gebouwd is.</p>



<p>Wanneer je nieuwe plugins installeert zal de Sitediagnose functie in WordPress controleren of een plugin een PHP versie nodig heeft die niet werkt met jouw site. Indien dit het geval is zal WordPress je niet toestaan de plugin te activeren.</p>



<span id=\"more-1027\"></span>



<h3>Snelheidsverbeteringen voor de editor</h3>



<div class=\"wp-block-image\"><figure class=\"alignright\"><img src=\"https://s.w.org/images/core/5.1/editor-performance.svg\" alt=\"\" /></figure></div>



<p>De nieuwe blok editor die in WordPress 5.0 is geïntroduceerd is verder verbeterd. De grootste verbetering is de snelheid waarmee de editor nu werkt in WordPress 5.1. De editor zou nu iets sneller moeten opstarten en typen zou vloeiender moeten voelen. Los daarvan, in de komende versies zullen er meer snelheidsverbeteringen doorgevoerd worden.</p>



<h3>Hier worden ontwikkelaars blij van</h3>



<h4>Multisite metagegevens</h4>



<p>5.1 introduceert een nieuwe databasetabel om metadata op te slaan die geassocieerd is met sites en het mogelijk maakt om arbitraire site data op te slaan die relevant kan zijn in een multisite / netwerkcontext.	<br><a href=\"https://make.wordpress.org/core/2019/01/28/multisite-support-for-site-metadata-in-5-1/\">Lees meer.</a></p>



<h4>Cron API</h4>



<p>De Cron API is bijgewerkt met nieuwe functies voor returning data en bevat ook nieuwe filters voor het aanpassen van de cron storage. Andere wijzigingen hebben effect op cron spawning op servers die FastCGI en PHP-FPM versions 7.0.16 en daarboven draaien.	<br><a href=\"https://make.wordpress.org/core/2019/01/09/cron-improvements-with-php-fpm-in-wordpress-5-1/\">Lees meer.</a></p>



<h4>Nieuw JS Build Proces</h4>



<p>WordPress 5.1 introduceert een nieuw JavaScript build optie als gevolg van de grote reorganizatie van code die begon met de 5.0 release. <br><a href=\"https://make.wordpress.org/core/2018/05/16/preparing-wordpress-for-a-javascript-future-part-1-build-step-and-folder-reorganization/\">Lees meer.</a></p>



<h4>Overige fijne zaken voor ontwikkelaars</h4>



<p>Verschillende verbeteringen zoals updates voor de waarden die je kunt gebruiken in in de&nbsp;<code>WP_DEBUG_LOG</code>&nbsp;constant, een nieuwe test config file constant in de test suite, nieuwe plugin action hooks, short-circuit filters voor&nbsp;<code>wp_unique_post_slug()</code>&nbsp;en&nbsp;<code>WP_User_Query</code>&nbsp;en&nbsp;<code>count_users()</code>, een nieuwe&nbsp;<code>human_readable_duration</code>&nbsp;functie, verbeterde taxonomy metabox opschoning, gelimiteerde&nbsp;<code>LIKE</code>&nbsp;support voor meta keys wanneer je&nbsp;<code>WP_Meta_Query</code>&nbsp;gebruikt en een nieuwe “doing it wrong” melding wanneer je REST API endpoints registreert, en nog veel meer!	<br><a href=\"https://make.wordpress.org/core/2019/01/23/miscellaneous-developer-focused-changes-in-5-1/\">Lees meer.</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://nl.wordpress.org/2019/02/22/wordpress-5-1-is-vrijgegeven/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:75:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		


			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:8:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 5.0 is vrijgegeven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://nl.wordpress.org/2018/12/07/wordpress-5-0-is-vrijgegeven/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://nl.wordpress.org/2018/12/07/wordpress-5-0-is-vrijgegeven/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 07 Dec 2018 10:11:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://nl.wordpress.org/?p=1004\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:371:\"WordPress 5.0 is vrijgegeven. Deze nieuwe versie brengt één hele grote vernieuwing. We hebben namelijk een aantal grote veranderingen gemaakt in de editor. Onze nieuwe, op blokken gebaseerde editor, is de eerste stap richting een nieuwe toekomst met een gestroomlijnde editor ervaring op je site. Je hebt meer flexibiliteit over de manier hoe inhoud weergeven [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"enclosure\";a:2:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:52:\"https://s.w.org/images/core/5.0/videos/add-block.mp4\";s:6:\"length\";s:7:\"8086508\";s:4:\"type\";s:9:\"video/mp4\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:48:\"https://s.w.org/images/core/5.0/videos/build.mp4\";s:6:\"length\";s:7:\"2623964\";s:4:\"type\";s:9:\"video/mp4\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Remkus de Vries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:7129:\"
<figure class=\"wp-block-image\"><img src=\"https://s.w.org/images/core/5.0/header/Gutenberg1x.jpg\" alt=\"\" /></figure>



<p>WordPress 5.0 is vrijgegeven. Deze nieuwe versie brengt één hele grote vernieuwing. We hebben namelijk een aantal grote veranderingen gemaakt in de editor. Onze nieuwe, op blokken gebaseerde editor, is de eerste stap richting een nieuwe toekomst met een gestroomlijnde editor ervaring op je site. Je hebt meer flexibiliteit over de manier hoe inhoud weergeven wordt. Of je nou je eerste site aan het maken bent, je blog nieuw leven inblaast of code schrijft als baan.</p>



<span id=\"more-1004\"></span>



<div class=\"wp-block-columns has-2-columns\">
<div class=\"wp-block-column\">
<figure class=\"wp-block-image is-resized\"><img loading=\"lazy\" src=\"https://s.w.org/images/core/5.0/features/Plugins1x.jpg\" alt=\"\" width=\"250\" height=\"250\" /><figcaption>Doe meer met minder plugins.</figcaption></figure>
</div>



<div class=\"wp-block-column\">
<figure class=\"wp-block-image is-resized\"><img loading=\"lazy\" src=\"https://s.w.org/images/core/5.0/features/Layout1x.jpg\" alt=\"\" width=\"250\" height=\"250\" /><figcaption>Creëer moderne, multimedia rijke lay-outs.</figcaption></figure>
</div>
</div>



<div class=\"wp-block-columns has-2-columns\">
<div class=\"wp-block-column\">
<figure class=\"wp-block-image is-resized\"><img loading=\"lazy\" src=\"https://s.w.org/images/core/5.0/features/Editor%20Styles1x.jpg\" alt=\"\" width=\"250\" height=\"250\" /><figcaption>Vertrouw dat de editor lijkt op je site.</figcaption></figure>
</div>



<div class=\"wp-block-column\">
<figure class=\"wp-block-image is-resized\"><img loading=\"lazy\" src=\"https://s.w.org/images/core/5.0/features/Responsive1x.jpg\" alt=\"\" width=\"250\" height=\"250\" /><figcaption>Werkt op alle schermformaten en apparaten.</figcaption></figure>
</div>
</div>



<h2>Bouwen met blokken</h2>



<p>De nieuwe, op blokken gebaseerde editor, verandert niets aan de manier hoe je content er uit ziet voor bezoekers. Wat het wel doet, is het jou mogelijk maken elke multimedia soort super eenvoudig toe te voegen precies zoals jij dat voor ogen hebt. Elk stukje content is een afgebakend blok welke je eenvoudig kunt verplaatsen. Mocht je liever met HTML en CSS willen werken, dan staan de blokken je niet in de weg. WordPress is hier om het proces eenvoudiger te maken, niet het resultaat.</p>



<figure class=\"wp-block-video\"><video controls src=\"https://s.w.org/images/core/5.0/videos/add-block.mp4\"></video></figure>



<p>We hebben standaard al heel veel blokken beschikbaar, en elke dag worden er meer toegevoegd door de community. Begin een nieuw blok door de forward slash in te typen. Je krijgt dan direct te zien welke blokken er allemaal beschikbaar zijn.</p>



<h3>Vrijheid om te bouwen, vrijheid om te schrijven</h3>



<p>Deze nieuwe editor ervaring behandelt design en content op meer consistente manier. Wanneer je klantensites maakt kun je herbruikbare blokken maken. Hiermee kunnen je klanten steeds nieuwe content blijven toevoegen en blijft de uitstraling precies zoals je die bedoeld had.</p>



<figure class=\"wp-block-video\"><video controls src=\"https://s.w.org/images/core/5.0/videos/build.mp4\"></video></figure>



<hr class=\"wp-block-separator\" />



<h2>Een verbluffend nieuw standaard thema</h2>



<figure class=\"wp-block-image\"><img src=\"https://s.w.org/images/core/5.0/twenty%20nineteen/twenty-nineteen.webp\" alt=\"\" /><figcaption>De front-end van Twenty Nineteen aan de linkerkant en hoe het er uit ziet in de editor aan de rechterkant.</figcaption></figure>



<p>De introductie van Twenty Nineteen, het nieuwe standaard thema welke de kracht van de nieuwe editor laat zien.</p>



<h3>Ontworpen voor de Blok-editor</h3>



<p>Twenty Nineteen bevat aangepaste styling voor de blokken die standaard beschikbaar zijn in 5.0. Het thema maakt uitgebreid gebruik van editor-styles. Op die manier is wat je in de editor aan het maken bent een reflectie van hoe het op de site zelf er uit ziet.</p>



<h3>Eenvoudige, tekst gedreven lay-out</h3>



<p>Twenty Nineteen bevat veel witruimte en moderne schreefloze koppen, gecombineerd met klassieke serif-tekst. Het thema gebruikt systeemlettertypes om de laadsnelheid te verhogen. Niet meer lang wachten op trage netwerken!</p>



<figure class=\"wp-block-image\"><img src=\"https://s.w.org/images/core/5.0/twenty%20nineteen/twenty-nineteen-versatile.gif\" alt=\"\" /></figure>



<h3>Veelzijdig ontwerp voor alle sites</h3>



<p>Twenty Nineteen is ontworpen om te werken voor een breed scala aan toepassingen. Of je nu een foto-blog hebt, een nieuw bedrijf start of een non-profitorganisatie, Twenty Nineteen is flexibel genoeg om aan al je wensen te voldoen.</p>



<hr class=\"wp-block-separator\" />



<h2>Hier worden ontwikkelaars blij van</h2>



<h3>Beschermen</h3>



<p>Blokken bieden een fijne manier voor gebruikers om content direct te wijzigen en ze voorkomen dat de structuur van de content niet eenvoudig kan worden gestoord door onopzettelijke codebewerkingen. Dit staat de ontwikkelaar toe om controle te hebben op de output door gepolijste en semantische markup te leveren die bewaard blijft tijdens het bewerken.</p>



<h3>Opstellen</h3>



<p>Profiteer van een grote verzameling aan API&#8217;s en interface-componenten om eenvoudig blokken met een intuïtieve besturing voor je klanten te maken. Gebruik maken van deze componenten versnelt niet alleen het ontwikkelingswerk, maar biedt ook een consistentere, bruikbare en toegankelijke interface voor alle gebruikers.</p>



<h3>Maak</h3>



<p>Het nieuwe blokkenparadigma opent diverse mogelijkheden en verbeelding of hoe gebruikerswensen opgelost kunnen worden. Met eenduidige flow voor het toevoegen van een blok is eenvoudiger voor gebruikers om blokken te vinden voor alle soorten content. Ontwikkelaars kunnen zich richten op hun visie om verrijkte ervaringen te bieden, in plaats van werken met ingewikkelde API&#8217;s. <a href=\"https://wordpress.org/gutenberg/handbook/\">Leren hoe je moet starten</a></p>



<hr class=\"wp-block-separator\" />



<h2>Liever Klassiek?</h2>



<figure class=\"wp-block-image\"><img src=\"https://s.w.org/images/core/5.0/classic/Classic.webp\" alt=\"\" /></figure>



<p>Blijf je liever met de vertrouwde Klassieke editor werken? Dat is geen probleem! Ondersteuning voor de Klassieke editor plugin blijft aanwezig in WordPress tot en met 2021.</p>



<p>De <a href=\"https://nl.wordpress.org/plugins/classic-editor/\">Klassieke editor</a> plugin herstelt de vorige WordPress editor en het &#8220;bericht bewerken&#8221; scherm. Hiermee kan je plugins blijven gebruiken die de klassieke editor uitbreiden, klassieke metaboxes toevoegen of op een andere manier afhankelijk zijn van de vorige editor. Bezoek de plugins pagina en klik de “Nu installeren” knop naast &#8220;Klassieke editor&#8221; om de plugin te installeren. Wanneer de plugin klaar is met installeren, klik op “Activeren”. Dat is alles!</p>



<p>Opmerking voor gebruikers van computerhulpmiddelen: als je problemen met de bruikbaarheid ervaart met de Blok-editor, raden we je aan gebruik te maken van de Klassieke editor.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://nl.wordpress.org/2018/12/07/wordpress-5-0-is-vrijgegeven/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:73:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"WordCamps in Nederland in 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://nl.wordpress.org/2018/01/10/wordcamps-in-nederland-in-2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://nl.wordpress.org/2018/01/10/wordcamps-in-nederland-in-2018/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 10 Jan 2018 10:11:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"WordCamp\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://nl.wordpress.org/?p=854\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:415:\"Beste WordCamp Nederland liefhebber, Zoals je mogelijk hebt kunnen zien moesten wij, als organisatie achter WordCamp Nederland, eerst 3 andere WordCamps in Nederland &#8220;laten gebeuren&#8221; voordat we weer een WordCamp Nederland mochten organiseren. Als WordPress Community hebben we hier werk van gemaakt. WordCamp Nijmegen en WordCamp Utrecht staan ondertussen al als twee succesvolle WordCamps die [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Remkus de Vries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2318:\"
<p>Beste WordCamp Nederland liefhebber,</p>



<p>Zoals je mogelijk hebt kunnen zien moesten wij, als organisatie achter WordCamp Nederland, eerst 3 andere WordCamps in Nederland &#8220;laten gebeuren&#8221; <a href=\"https://nl.wordpress.org/2017/06/15/toch-toekomst-voor-wordcamp-nederland/\" target=\"_blank\" rel=\"noopener noreferrer\">voordat we weer een WordCamp Nederland mochten organiseren</a>.</p>



<p>Als WordPress Community hebben we hier werk van gemaakt. WordCamp Nijmegen en WordCamp Utrecht staan ondertussen al als twee succesvolle WordCamps die in de geschiedenisboeken.</p>



<span id=\"more-854\"></span>



<p>Maar daar stopt het niet. We hebben ook in 2018 al een aantal WordCamps op de planning staan. Dit zijn de twee die er op dit moment in de agenda staan:</p>



<p><a href=\"https://2018.noordnederland.wordcamp.org\" target=\"_blank\" rel=\"noopener noreferrer\">WordCamp Noord-Nederland</a> in Drachten, 9 en 10 feb. <a href=\"https://2018.noordnederland.wordcamp.org/tickets/\" target=\"_blank\" rel=\"noopener noreferrer\">Tickets koop je hier</a>.</p>



<p><a href=\"https://rotterdam.wordcamp.org\" target=\"_blank\" rel=\"noopener noreferrer\">WordCamp Rotterdam</a> in, je raadt het nooit, Rotterdam.&nbsp;23 &amp; 24 maart. <a href=\"https://2018.rotterdam.wordcamp.org/tickets/\" target=\"_blank\" rel=\"noopener noreferrer\">Tickets vind je hier</a>.</p>



<p>Daarnaast zijn <a href=\"https://utrecht.wordcamp.org\" target=\"_blank\" rel=\"noopener noreferrer\">WordCamp Utrecht</a> en <a href=\"https://nijmegen.wordcamp.org\" target=\"_blank\" rel=\"noopener noreferrer\">WordCamp Nijmegen</a> alweer voorzichtig bezig met een planning. En uiteraard moeten we onze zuiderburen niet vergeten: WordCamp Antwerp gaat voor de tweede keer alweer los <a href=\"https://antwerp.wordcamp.org\" target=\"_blank\" rel=\"noopener noreferrer\">op 2 &amp; 3 maart 2018</a>.</p>



<p>Al met al zul je de komende tijd steeds meer lokale WordCamps voorbij zien komen. Uiteraard komt er ook weer een WordCamp Nederland aan, maar we wachten nog even met het definitieve plannen hiervan.</p>



<p>Zodra we meer weten laten we het jullie weten.</p>



<p><strong>Update 6 juli 2018:</strong> <a href=\"https://nl.wordpress.org/team/2018/07/06/wordcamps-in-nederland-onze-ervaringen/\">WordCamps in Nederland &#8211; onze ervaringen</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://nl.wordpress.org/2018/01/10/wordcamps-in-nederland-in-2018/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:73:\"
		
		
					
		
		
		
				
		

					
										
					
					
			
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"Nederlanders krijgen commitrechten op WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"https://nl.wordpress.org/2017/12/12/nederlanders-krijgen-commitrechten-op-wordpress-core/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"https://nl.wordpress.org/2017/12/12/nederlanders-krijgen-commitrechten-op-wordpress-core/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 12 Dec 2017 08:42:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Nieuws\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://nl.wordpress.org/?p=833\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:416:\"WordPress is een Open Source software-project. Dat betekent dat iedereen de broncode van WordPress kan bekijken en suggesties voor verbetering kan aandragen. Gebruikers maken WordPress daarom niet alleen voor elkaar, maar vooral ook met elkaar. Hoewel iedereen verbeteringen kan aandragen, is het daadwerkelijk toevoegen van code aan WordPress voorbehouden aan een vrij selecte groep ervaren WordPressers. [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Taco Verdonschot\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2973:\"<p>WordPress is een Open Source software-project. Dat betekent dat iedereen de broncode van WordPress kan bekijken en suggesties voor verbetering kan aandragen. Gebruikers maken WordPress daarom niet alleen voor elkaar, maar vooral ook met elkaar.</p>
<p>Hoewel iedereen verbeteringen kan aandragen, is het daadwerkelijk toevoegen van code aan WordPress voorbehouden aan een vrij selecte groep ervaren WordPressers. Om dit te kunnen doen heb je zogenaamde commitrechten nodig. Je krijgt deze rechten niet zomaar, want het betekent dat je WordPress voor alle gebruikers kan aanpassen. Het gebeurt dus niet vaak dat er nieuwe committers (mensen met commitrechten) worden toegevoegd aan het project.<span id=\"more-833\"></span></p>
<p>Extra bijzonder is het daarom dat maar liefst twee Nederlanders commitrechten hebben gekregen in de afgelopen 10 dagen. We zetten ze daarom graag even in het zonnetje.</p>
<h3>Juliette Reinders Folmer</h3>
<p><a href=\"https://profiles.wordpress.org/jrf\">Juliette</a> is geen onbekende in de WordPress community. Ze werkt al sinds 2004 met PHP en al sinds 2010 met WordPress, en heeft zeer actief bijgedragen aan diverse plugins en aan WordPress zelf. De afgelopen periode heeft Juliette zich vooral ingezet om te zorgen dat WordPress voldoet aan de WordPress codestandaard. Dit is een set afspraken die WordPress-ontwikkelaars hebben gemaakt over wat goede code is. Haar project zorgt ervoor dat meer dan 60.000 foutmeldingen en waarschuwingen in één klap worden opgelost. Indrukwekkend feit, deze ene patch (verbetering aan de software) heeft meer dan 25% van alle regels code in WordPress gewijzigd!<br />
Meer weten? Op <a href=\"https://nijmegen.wordcamp.org\">WordCamp Nijmegen</a> heeft Juliette over deze patch gesproken. Je kan haar presentatie terugkijken op <a href=\"https://wordpress.tv/2017/10/14/juliette-reinders-folmer-the-biggest-wp-core-patch-ever/\">wordpress.tv</a>.</p>
<h3>Anton Timmermans</h3>
<p>Ook <a href=\"https://profiles.wordpress.org/atimmer\">Anton</a> loopt al lange tijd rond in het WordPress-wereldje. In 2012 ontdekte Anton WordPress, en nog geen jaar later werd zijn eerste verbetering (patch) toegevoegd aan WordPress. De afgelopen tijd heeft zich, samen met zijn collega&#8217;s van <a href=\"https://yoast.com\">Yoast</a>, ingezet voor het verbeteren van de JavaScript documentatie in WordPress. Hierdoor is het voor andere ontwikkelaars makkelijker om de JavaScript-code van WordPress te begrijpen en er op in te haken.</p>
<h3>Zelf ook bijdragen?</h3>
<p>Wil je zelf ook bijdragen aan het verbeteren van WordPress? Dat kan! Op <a href=\"https://make.wordpress.org\">make.wordpress.org</a> vind je een overzicht van de gebieden waarin je kan bijdragen. Elk team heeft een eigen &#8216;Getting started&#8217; sectie in hun handboek. Voor WordPress core kan je deze bijvoorbeeld vinden op <a href=\"https://make.wordpress.org/core/handbook/about/getting-started-at-a-contributor-day/\">Getting started</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"https://nl.wordpress.org/2017/12/12/nederlanders-krijgen-commitrechten-op-wordpress-core/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:30:\"https://nl.wordpress.org/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"
	hourly	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"
	1	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Tue, 01 Jun 2021 10:38:55 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Fri, 07 May 2021 01:00:44 GMT\";s:4:\"link\";s:61:\"<https://nl.wordpress.org/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 2\";}}s:5:\"build\";s:14:\"20201016152008\";}","no"),
("586","_transient_timeout_feed_mod_26b0d8e18ed25a5313e8c7eb9c687d1b","1622587135","no"),
("587","_transient_feed_mod_26b0d8e18ed25a5313e8c7eb9c687d1b","1622543935","no"),
("588","_transient_timeout_dash_v2_12fb51b99c5dfec05835445e04f970a4","1622587135","no"),
("589","_transient_dash_v2_12fb51b99c5dfec05835445e04f970a4","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://nl.wordpress.org/2021/03/10/wordpress-5-7-is-vrijgegeven/\'>WordPress 5.7 is vrijgegeven</a></li><li><a class=\'rsswidget\' href=\'https://nl.wordpress.org/2020/12/08/wordpress-5-6-is-vrijgegeven/\'>WordPress 5.6 is vrijgegeven</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://nl.wordpress.org/2021/03/10/wordpress-5-7-is-vrijgegeven/\'>WordPress 5.7 is vrijgegeven</a></li><li><a class=\'rsswidget\' href=\'https://nl.wordpress.org/2020/12/08/wordpress-5-6-is-vrijgegeven/\'>WordPress 5.6 is vrijgegeven</a></li><li><a class=\'rsswidget\' href=\'https://nl.wordpress.org/2020/08/11/wordpress-5-5-is-vrijgegeven/\'>WordPress 5.5 is vrijgegeven</a></li></ul></div>","no"),
("594","neve_logger_flag","no","yes"),
("602","_site_transient_timeout_available_translations","1622554820","no"),
("603","_site_transient_available_translations","a:126:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-13 15:59:22\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-21 20:16:59\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:6:\"4.8.17\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.8.17/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-29 04:16:56\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2019-10-29 07:54:22\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.9.18/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-07-01 06:36:01\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.4.6/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:22:\"Продължение\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-10-31 08:48:37\";s:12:\"english_name\";s:20:\"Bengali (Bangladesh)\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.4.6/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2020-10-30 03:24:38\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"མུ་མཐུད།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-25 07:27:37\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-28 10:26:50\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-19 06:51:04\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 10:32:41\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-01 06:17:31\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Forts&#230;t\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-24 08:16:22\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/5.7.2/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-24 08:15:48\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-03-14 20:06:23\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:5:\"de_AT\";a:8:{s:8:\"language\";s:5:\"de_AT\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-03-10 19:15:18\";s:12:\"english_name\";s:16:\"German (Austria)\";s:11:\"native_name\";s:21:\"Deutsch (Österreich)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/de_AT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-03-14 20:06:52\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/5.7.2/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dsb\";a:8:{s:8:\"language\";s:3:\"dsb\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 13:33:04\";s:12:\"english_name\";s:13:\"Lower Sorbian\";s:11:\"native_name\";s:16:\"Dolnoserbšćina\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.7.2/dsb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"dsb\";i:3;s:3:\"dsb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Dalej\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-18 11:08:46\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 04:12:51\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 07:22:30\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 04:12:40\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 07:31:22\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 04:12:28\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-18 09:35:35\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_CR\";a:8:{s:8:\"language\";s:5:\"es_CR\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-17 23:45:12\";s:12:\"english_name\";s:20:\"Spanish (Costa Rica)\";s:11:\"native_name\";s:22:\"Español de Costa Rica\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/es_CR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-03-10 15:04:44\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-16 02:17:21\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_EC\";a:8:{s:8:\"language\";s:5:\"es_EC\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 02:05:34\";s:12:\"english_name\";s:17:\"Spanish (Ecuador)\";s:11:\"native_name\";s:19:\"Español de Ecuador\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/es_EC.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-16 13:07:32\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-12 12:43:41\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 02:05:15\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"5.6.4\";s:7:\"updated\";s:19:\"2020-12-11 02:12:59\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.6.4/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PR\";a:8:{s:8:\"language\";s:5:\"es_PR\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-04-29 15:36:59\";s:12:\"english_name\";s:21:\"Spanish (Puerto Rico)\";s:11:\"native_name\";s:23:\"Español de Puerto Rico\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.4.6/es_PR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:6:\"5.2.11\";s:7:\"updated\";s:19:\"2019-03-02 06:35:01\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.2.11/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_UY\";a:8:{s:8:\"language\";s:5:\"es_UY\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-03-31 18:33:26\";s:12:\"english_name\";s:17:\"Spanish (Uruguay)\";s:11:\"native_name\";s:19:\"Español de Uruguay\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/es_UY.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-03-11 17:28:23\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2020-08-12 08:38:59\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-13 21:49:34\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_AF\";a:8:{s:8:\"language\";s:5:\"fa_AF\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-10 13:20:19\";s:12:\"english_name\";s:21:\"Persian (Afghanistan)\";s:11:\"native_name\";s:31:\"(فارسی (افغانستان\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/fa_AF.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-01 11:39:36\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-06 05:21:48\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-02-22 13:54:46\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-30 13:29:35\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-17 17:57:39\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:3:\"fur\";a:8:{s:8:\"language\";s:3:\"fur\";s:7:\"version\";s:6:\"4.8.17\";s:7:\"updated\";s:19:\"2018-01-29 17:32:35\";s:12:\"english_name\";s:8:\"Friulian\";s:11:\"native_name\";s:8:\"Friulian\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.8.17/fur.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"fur\";i:3;s:3:\"fur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 18:17:43\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2018-09-14 12:33:48\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.18/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:6:\"4.4.25\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.4.25/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-28 16:42:59\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"להמשיך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-11-06 12:34:38\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.4.6/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-13 08:03:31\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:3:\"hsb\";a:8:{s:8:\"language\";s:3:\"hsb\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 13:34:18\";s:12:\"english_name\";s:13:\"Upper Sorbian\";s:11:\"native_name\";s:17:\"Hornjoserbšćina\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.7.2/hsb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"hsb\";i:3;s:3:\"hsb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:4:\"Dale\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-30 14:38:59\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Tovább\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-24 02:11:27\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2018-12-11 10:40:02\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.18/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-27 08:57:19\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-20 01:00:08\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"jv_ID\";a:8:{s:8:\"language\";s:5:\"jv_ID\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2019-02-16 23:58:56\";s:12:\"english_name\";s:8:\"Javanese\";s:11:\"native_name\";s:9:\"Basa Jawa\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.18/jv_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"jv\";i:2;s:3:\"jav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nutugne\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-03-29 10:00:46\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-06 18:16:02\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.7.2/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:2:\"kk\";a:8:{s:8:\"language\";s:2:\"kk\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2018-07-10 11:35:44\";s:12:\"english_name\";s:6:\"Kazakh\";s:11:\"native_name\";s:19:\"Қазақ тілі\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.18/kk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kk\";i:2;s:3:\"kaz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Жалғастыру\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:6:\"5.2.11\";s:7:\"updated\";s:19:\"2019-06-10 16:18:28\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.2.11/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:2:\"kn\";a:8:{s:8:\"language\";s:2:\"kn\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2020-09-30 14:08:59\";s:12:\"english_name\";s:7:\"Kannada\";s:11:\"native_name\";s:15:\"ಕನ್ನಡ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.18/kn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kn\";i:2;s:3:\"kan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"ಮುಂದುವರೆಸಿ\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-30 08:12:22\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-29 01:20:15\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.7.2/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"ຕໍ່\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-03-23 12:35:40\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-26 10:05:05\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-07-01 09:16:57\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.4.6/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2019-11-22 15:32:08\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.18/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2018-08-31 11:57:07\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.18/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.2.30\";s:7:\"updated\";s:19:\"2017-12-26 11:57:10\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.2.30/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ေဆာင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 16:50:37\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:6:\"5.2.11\";s:7:\"updated\";s:19:\"2020-05-31 16:07:59\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.2.11/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"जारीराख्नु \";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-26 08:38:23\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-01 05:44:19\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-10 14:42:01\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/5.7.2/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-03-18 10:59:16\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:6:\"4.8.17\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.8.17/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-26 08:29:14\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.3.26\";s:7:\"updated\";s:19:\"2015-12-02 21:41:29\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.3.26/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"دوام\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-22 11:19:45\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_AO\";a:8:{s:8:\"language\";s:5:\"pt_AO\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-30 09:51:29\";s:12:\"english_name\";s:19:\"Portuguese (Angola)\";s:11:\"native_name\";s:20:\"Português de Angola\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/pt_AO.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-26 17:10:08\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 08:18:42\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/5.7.2/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-01 09:09:31\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-18 14:23:41\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:3:\"snd\";a:8:{s:8:\"language\";s:3:\"snd\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-07-07 01:53:37\";s:12:\"english_name\";s:6:\"Sindhi\";s:11:\"native_name\";s:8:\"سنڌي\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.4.6/snd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"sd\";i:2;s:3:\"snd\";i:3;s:3:\"snd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"اڳتي هلو\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-13 04:10:29\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:3:\"skr\";a:8:{s:8:\"language\";s:3:\"skr\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-23 11:54:14\";s:12:\"english_name\";s:7:\"Saraiki\";s:11:\"native_name\";s:14:\"سرائیکی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.7.2/skr.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"skr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"جاری رکھو\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:6:\"5.1.10\";s:7:\"updated\";s:19:\"2019-04-30 13:03:56\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.1.10/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Nadaljujte\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-13 15:40:47\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-14 22:03:48\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-22 13:02:31\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:2:\"sw\";a:8:{s:8:\"language\";s:2:\"sw\";s:7:\"version\";s:5:\"5.3.8\";s:7:\"updated\";s:19:\"2019-10-13 15:35:35\";s:12:\"english_name\";s:7:\"Swahili\";s:11:\"native_name\";s:9:\"Kiswahili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.8/sw.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sw\";i:2;s:3:\"swa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Endelea\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:5:\"ta_LK\";a:8:{s:8:\"language\";s:5:\"ta_LK\";s:7:\"version\";s:6:\"4.2.30\";s:7:\"updated\";s:19:\"2015-12-03 01:07:44\";s:12:\"english_name\";s:17:\"Tamil (Sri Lanka)\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.2.30/ta_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"தொடர்க\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"5.5.5\";s:7:\"updated\";s:19:\"2021-04-22 18:43:36\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.5.5/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:6:\"4.8.17\";s:7:\"updated\";s:19:\"2017-09-30 09:04:29\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.17/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-23 09:26:34\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2018-05-16 07:36:13\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:16:\"ئۇيغۇرچە\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.18/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-23 07:44:37\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-04-09 11:17:33\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.4.6/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-02-28 12:02:22\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-23 07:16:16\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-07 07:43:24\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-13 03:20:55\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-29 12:30:01\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}}","no"),
("604","new_admin_email","24046@ma-web.nl","yes"),
("607","_transient_timeout_neve_2112versions","1622976047","no"),
("608","_transient_neve_2112versions","a:97:{i:0;a:2:{s:7:\"version\";s:5:\"1.0.4\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.0.4.zip\";}i:1;a:2:{s:7:\"version\";s:5:\"1.0.5\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.0.5.zip\";}i:2;a:2:{s:7:\"version\";s:5:\"1.0.6\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.0.6.zip\";}i:3;a:2:{s:7:\"version\";s:5:\"1.0.8\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.0.8.zip\";}i:4;a:2:{s:7:\"version\";s:5:\"1.0.9\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.0.9.zip\";}i:5;a:2:{s:7:\"version\";s:6:\"1.0.10\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.10.zip\";}i:6;a:2:{s:7:\"version\";s:6:\"1.0.11\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.11.zip\";}i:7;a:2:{s:7:\"version\";s:6:\"1.0.12\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.12.zip\";}i:8;a:2:{s:7:\"version\";s:6:\"1.0.13\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.13.zip\";}i:9;a:2:{s:7:\"version\";s:6:\"1.0.14\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.14.zip\";}i:10;a:2:{s:7:\"version\";s:6:\"1.0.15\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.15.zip\";}i:11;a:2:{s:7:\"version\";s:6:\"1.0.16\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.16.zip\";}i:12;a:2:{s:7:\"version\";s:6:\"1.0.18\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.18.zip\";}i:13;a:2:{s:7:\"version\";s:6:\"1.0.19\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.19.zip\";}i:14;a:2:{s:7:\"version\";s:6:\"1.0.20\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.20.zip\";}i:15;a:2:{s:7:\"version\";s:6:\"1.0.21\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.21.zip\";}i:16;a:2:{s:7:\"version\";s:6:\"1.0.22\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.22.zip\";}i:17;a:2:{s:7:\"version\";s:6:\"1.0.23\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.23.zip\";}i:18;a:2:{s:7:\"version\";s:6:\"1.0.24\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.24.zip\";}i:19;a:2:{s:7:\"version\";s:6:\"1.0.25\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.25.zip\";}i:20;a:2:{s:7:\"version\";s:6:\"1.0.26\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.26.zip\";}i:21;a:2:{s:7:\"version\";s:6:\"1.0.27\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.27.zip\";}i:22;a:2:{s:7:\"version\";s:6:\"1.0.28\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.28.zip\";}i:23;a:2:{s:7:\"version\";s:6:\"1.0.29\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.29.zip\";}i:24;a:2:{s:7:\"version\";s:5:\"1.1.0\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.1.0.zip\";}i:25;a:2:{s:7:\"version\";s:5:\"1.1.1\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.1.1.zip\";}i:26;a:2:{s:7:\"version\";s:5:\"1.1.2\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.1.2.zip\";}i:27;a:2:{s:7:\"version\";s:5:\"1.1.3\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.1.3.zip\";}i:28;a:2:{s:7:\"version\";s:5:\"1.1.4\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.1.4.zip\";}i:29;a:2:{s:7:\"version\";s:5:\"2.0.0\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.0.0.zip\";}i:30;a:2:{s:7:\"version\";s:5:\"2.1.0\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.1.0.zip\";}i:31;a:2:{s:7:\"version\";s:5:\"2.2.0\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.2.0.zip\";}i:32;a:2:{s:7:\"version\";s:5:\"2.3.1\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.3.1.zip\";}i:33;a:2:{s:7:\"version\";s:5:\"2.3.2\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.3.2.zip\";}i:34;a:2:{s:7:\"version\";s:5:\"2.3.3\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.3.3.zip\";}i:35;a:2:{s:7:\"version\";s:5:\"2.3.4\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.3.4.zip\";}i:36;a:2:{s:7:\"version\";s:5:\"2.3.5\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.3.5.zip\";}i:37;a:2:{s:7:\"version\";s:5:\"2.3.6\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.3.6.zip\";}i:38;a:2:{s:7:\"version\";s:5:\"2.3.7\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.3.7.zip\";}i:39;a:2:{s:7:\"version\";s:5:\"2.3.8\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.3.8.zip\";}i:40;a:2:{s:7:\"version\";s:5:\"2.3.9\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.3.9.zip\";}i:41;a:2:{s:7:\"version\";s:6:\"2.3.10\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.10.zip\";}i:42;a:2:{s:7:\"version\";s:6:\"2.3.11\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.11.zip\";}i:43;a:2:{s:7:\"version\";s:6:\"2.3.12\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.12.zip\";}i:44;a:2:{s:7:\"version\";s:6:\"2.3.14\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.14.zip\";}i:45;a:2:{s:7:\"version\";s:6:\"2.3.15\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.15.zip\";}i:46;a:2:{s:7:\"version\";s:6:\"2.3.17\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.17.zip\";}i:47;a:2:{s:7:\"version\";s:6:\"2.3.19\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.19.zip\";}i:48;a:2:{s:7:\"version\";s:6:\"2.3.20\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.20.zip\";}i:49;a:2:{s:7:\"version\";s:6:\"2.3.21\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.21.zip\";}i:50;a:2:{s:7:\"version\";s:6:\"2.3.22\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.22.zip\";}i:51;a:2:{s:7:\"version\";s:5:\"2.4.0\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.4.0.zip\";}i:52;a:2:{s:7:\"version\";s:5:\"2.4.1\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.4.1.zip\";}i:53;a:2:{s:7:\"version\";s:5:\"2.4.2\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.4.2.zip\";}i:54;a:2:{s:7:\"version\";s:5:\"2.4.3\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.4.3.zip\";}i:55;a:2:{s:7:\"version\";s:5:\"2.5.1\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.5.1.zip\";}i:56;a:2:{s:7:\"version\";s:5:\"2.5.2\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.5.2.zip\";}i:57;a:2:{s:7:\"version\";s:5:\"2.5.3\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.5.3.zip\";}i:58;a:2:{s:7:\"version\";s:5:\"2.5.4\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.5.4.zip\";}i:59;a:2:{s:7:\"version\";s:5:\"2.6.0\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.6.0.zip\";}i:60;a:2:{s:7:\"version\";s:5:\"2.6.1\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.6.1.zip\";}i:61;a:2:{s:7:\"version\";s:5:\"2.6.2\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.6.2.zip\";}i:62;a:2:{s:7:\"version\";s:5:\"2.6.3\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.6.3.zip\";}i:63;a:2:{s:7:\"version\";s:5:\"2.6.4\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.6.4.zip\";}i:64;a:2:{s:7:\"version\";s:5:\"2.6.5\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.6.5.zip\";}i:65;a:2:{s:7:\"version\";s:5:\"2.6.6\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.6.6.zip\";}i:66;a:2:{s:7:\"version\";s:5:\"2.7.0\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.7.0.zip\";}i:67;a:2:{s:7:\"version\";s:5:\"2.7.1\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.7.1.zip\";}i:68;a:2:{s:7:\"version\";s:5:\"2.7.2\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.7.2.zip\";}i:69;a:2:{s:7:\"version\";s:5:\"2.7.3\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.7.3.zip\";}i:70;a:2:{s:7:\"version\";s:5:\"2.7.4\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.7.4.zip\";}i:71;a:2:{s:7:\"version\";s:5:\"2.7.5\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.7.5.zip\";}i:72;a:2:{s:7:\"version\";s:5:\"2.7.6\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.7.6.zip\";}i:73;a:2:{s:7:\"version\";s:5:\"2.7.7\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.7.7.zip\";}i:74;a:2:{s:7:\"version\";s:5:\"2.8.0\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.8.0.zip\";}i:75;a:2:{s:7:\"version\";s:5:\"2.8.1\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.8.1.zip\";}i:76;a:2:{s:7:\"version\";s:5:\"2.8.2\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.8.2.zip\";}i:77;a:2:{s:7:\"version\";s:5:\"2.8.3\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.8.3.zip\";}i:78;a:2:{s:7:\"version\";s:5:\"2.8.4\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.8.4.zip\";}i:79;a:2:{s:7:\"version\";s:5:\"2.9.0\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.9.0.zip\";}i:80;a:2:{s:7:\"version\";s:5:\"2.9.1\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.9.1.zip\";}i:81;a:2:{s:7:\"version\";s:5:\"2.9.2\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.9.2.zip\";}i:82;a:2:{s:7:\"version\";s:5:\"2.9.3\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.9.3.zip\";}i:83;a:2:{s:7:\"version\";s:5:\"2.9.4\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.9.4.zip\";}i:84;a:2:{s:7:\"version\";s:5:\"2.9.5\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.9.5.zip\";}i:85;a:2:{s:7:\"version\";s:6:\"2.10.0\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.10.0.zip\";}i:86;a:2:{s:7:\"version\";s:6:\"2.10.1\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.10.1.zip\";}i:87;a:2:{s:7:\"version\";s:6:\"2.10.2\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.10.2.zip\";}i:88;a:2:{s:7:\"version\";s:6:\"2.10.3\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.10.3.zip\";}i:89;a:2:{s:7:\"version\";s:6:\"2.10.4\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.10.4.zip\";}i:90;a:2:{s:7:\"version\";s:6:\"2.11.0\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.11.0.zip\";}i:91;a:2:{s:7:\"version\";s:6:\"2.11.1\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.11.1.zip\";}i:92;a:2:{s:7:\"version\";s:6:\"2.11.2\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.11.2.zip\";}i:93;a:2:{s:7:\"version\";s:6:\"2.11.3\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.11.3.zip\";}i:94;a:2:{s:7:\"version\";s:6:\"2.11.4\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.11.4.zip\";}i:95;a:2:{s:7:\"version\";s:6:\"2.11.5\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.11.5.zip\";}i:96;a:2:{s:7:\"version\";s:6:\"2.11.6\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.11.6.zip\";}}","no"),
("614","_transient_shipping-transient-version","1622544205","yes"),
("615","_transient_timeout_wc_shipping_method_count_legacy","1625136205","no"),
("616","_transient_wc_shipping_method_count_legacy","a:2:{s:7:\"version\";s:10:\"1622544205\";s:5:\"value\";i:0;}","no"),
("623","_transient_timeout_neve_2116versions","1622977246","no"),
("624","_transient_neve_2116versions","a:97:{i:0;a:2:{s:7:\"version\";s:5:\"1.0.4\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.0.4.zip\";}i:1;a:2:{s:7:\"version\";s:5:\"1.0.5\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.0.5.zip\";}i:2;a:2:{s:7:\"version\";s:5:\"1.0.6\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.0.6.zip\";}i:3;a:2:{s:7:\"version\";s:5:\"1.0.8\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.0.8.zip\";}i:4;a:2:{s:7:\"version\";s:5:\"1.0.9\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.0.9.zip\";}i:5;a:2:{s:7:\"version\";s:6:\"1.0.10\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.10.zip\";}i:6;a:2:{s:7:\"version\";s:6:\"1.0.11\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.11.zip\";}i:7;a:2:{s:7:\"version\";s:6:\"1.0.12\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.12.zip\";}i:8;a:2:{s:7:\"version\";s:6:\"1.0.13\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.13.zip\";}i:9;a:2:{s:7:\"version\";s:6:\"1.0.14\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.14.zip\";}i:10;a:2:{s:7:\"version\";s:6:\"1.0.15\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.15.zip\";}i:11;a:2:{s:7:\"version\";s:6:\"1.0.16\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.16.zip\";}i:12;a:2:{s:7:\"version\";s:6:\"1.0.18\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.18.zip\";}i:13;a:2:{s:7:\"version\";s:6:\"1.0.19\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.19.zip\";}i:14;a:2:{s:7:\"version\";s:6:\"1.0.20\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.20.zip\";}i:15;a:2:{s:7:\"version\";s:6:\"1.0.21\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.21.zip\";}i:16;a:2:{s:7:\"version\";s:6:\"1.0.22\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.22.zip\";}i:17;a:2:{s:7:\"version\";s:6:\"1.0.23\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.23.zip\";}i:18;a:2:{s:7:\"version\";s:6:\"1.0.24\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.24.zip\";}i:19;a:2:{s:7:\"version\";s:6:\"1.0.25\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.25.zip\";}i:20;a:2:{s:7:\"version\";s:6:\"1.0.26\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.26.zip\";}i:21;a:2:{s:7:\"version\";s:6:\"1.0.27\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.27.zip\";}i:22;a:2:{s:7:\"version\";s:6:\"1.0.28\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.28.zip\";}i:23;a:2:{s:7:\"version\";s:6:\"1.0.29\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.1.0.29.zip\";}i:24;a:2:{s:7:\"version\";s:5:\"1.1.0\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.1.0.zip\";}i:25;a:2:{s:7:\"version\";s:5:\"1.1.1\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.1.1.zip\";}i:26;a:2:{s:7:\"version\";s:5:\"1.1.2\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.1.2.zip\";}i:27;a:2:{s:7:\"version\";s:5:\"1.1.3\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.1.3.zip\";}i:28;a:2:{s:7:\"version\";s:5:\"1.1.4\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.1.1.4.zip\";}i:29;a:2:{s:7:\"version\";s:5:\"2.0.0\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.0.0.zip\";}i:30;a:2:{s:7:\"version\";s:5:\"2.1.0\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.1.0.zip\";}i:31;a:2:{s:7:\"version\";s:5:\"2.2.0\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.2.0.zip\";}i:32;a:2:{s:7:\"version\";s:5:\"2.3.1\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.3.1.zip\";}i:33;a:2:{s:7:\"version\";s:5:\"2.3.2\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.3.2.zip\";}i:34;a:2:{s:7:\"version\";s:5:\"2.3.3\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.3.3.zip\";}i:35;a:2:{s:7:\"version\";s:5:\"2.3.4\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.3.4.zip\";}i:36;a:2:{s:7:\"version\";s:5:\"2.3.5\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.3.5.zip\";}i:37;a:2:{s:7:\"version\";s:5:\"2.3.6\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.3.6.zip\";}i:38;a:2:{s:7:\"version\";s:5:\"2.3.7\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.3.7.zip\";}i:39;a:2:{s:7:\"version\";s:5:\"2.3.8\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.3.8.zip\";}i:40;a:2:{s:7:\"version\";s:5:\"2.3.9\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.3.9.zip\";}i:41;a:2:{s:7:\"version\";s:6:\"2.3.10\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.10.zip\";}i:42;a:2:{s:7:\"version\";s:6:\"2.3.11\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.11.zip\";}i:43;a:2:{s:7:\"version\";s:6:\"2.3.12\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.12.zip\";}i:44;a:2:{s:7:\"version\";s:6:\"2.3.14\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.14.zip\";}i:45;a:2:{s:7:\"version\";s:6:\"2.3.15\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.15.zip\";}i:46;a:2:{s:7:\"version\";s:6:\"2.3.17\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.17.zip\";}i:47;a:2:{s:7:\"version\";s:6:\"2.3.19\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.19.zip\";}i:48;a:2:{s:7:\"version\";s:6:\"2.3.20\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.20.zip\";}i:49;a:2:{s:7:\"version\";s:6:\"2.3.21\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.21.zip\";}i:50;a:2:{s:7:\"version\";s:6:\"2.3.22\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.3.22.zip\";}i:51;a:2:{s:7:\"version\";s:5:\"2.4.0\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.4.0.zip\";}i:52;a:2:{s:7:\"version\";s:5:\"2.4.1\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.4.1.zip\";}i:53;a:2:{s:7:\"version\";s:5:\"2.4.2\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.4.2.zip\";}i:54;a:2:{s:7:\"version\";s:5:\"2.4.3\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.4.3.zip\";}i:55;a:2:{s:7:\"version\";s:5:\"2.5.1\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.5.1.zip\";}i:56;a:2:{s:7:\"version\";s:5:\"2.5.2\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.5.2.zip\";}i:57;a:2:{s:7:\"version\";s:5:\"2.5.3\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.5.3.zip\";}i:58;a:2:{s:7:\"version\";s:5:\"2.5.4\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.5.4.zip\";}i:59;a:2:{s:7:\"version\";s:5:\"2.6.0\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.6.0.zip\";}i:60;a:2:{s:7:\"version\";s:5:\"2.6.1\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.6.1.zip\";}i:61;a:2:{s:7:\"version\";s:5:\"2.6.2\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.6.2.zip\";}i:62;a:2:{s:7:\"version\";s:5:\"2.6.3\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.6.3.zip\";}i:63;a:2:{s:7:\"version\";s:5:\"2.6.4\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.6.4.zip\";}i:64;a:2:{s:7:\"version\";s:5:\"2.6.5\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.6.5.zip\";}i:65;a:2:{s:7:\"version\";s:5:\"2.6.6\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.6.6.zip\";}i:66;a:2:{s:7:\"version\";s:5:\"2.7.0\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.7.0.zip\";}i:67;a:2:{s:7:\"version\";s:5:\"2.7.1\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.7.1.zip\";}i:68;a:2:{s:7:\"version\";s:5:\"2.7.2\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.7.2.zip\";}i:69;a:2:{s:7:\"version\";s:5:\"2.7.3\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.7.3.zip\";}i:70;a:2:{s:7:\"version\";s:5:\"2.7.4\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.7.4.zip\";}i:71;a:2:{s:7:\"version\";s:5:\"2.7.5\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.7.5.zip\";}i:72;a:2:{s:7:\"version\";s:5:\"2.7.6\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.7.6.zip\";}i:73;a:2:{s:7:\"version\";s:5:\"2.7.7\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.7.7.zip\";}i:74;a:2:{s:7:\"version\";s:5:\"2.8.0\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.8.0.zip\";}i:75;a:2:{s:7:\"version\";s:5:\"2.8.1\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.8.1.zip\";}i:76;a:2:{s:7:\"version\";s:5:\"2.8.2\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.8.2.zip\";}i:77;a:2:{s:7:\"version\";s:5:\"2.8.3\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.8.3.zip\";}i:78;a:2:{s:7:\"version\";s:5:\"2.8.4\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.8.4.zip\";}i:79;a:2:{s:7:\"version\";s:5:\"2.9.0\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.9.0.zip\";}i:80;a:2:{s:7:\"version\";s:5:\"2.9.1\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.9.1.zip\";}i:81;a:2:{s:7:\"version\";s:5:\"2.9.2\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.9.2.zip\";}i:82;a:2:{s:7:\"version\";s:5:\"2.9.3\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.9.3.zip\";}i:83;a:2:{s:7:\"version\";s:5:\"2.9.4\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.9.4.zip\";}i:84;a:2:{s:7:\"version\";s:5:\"2.9.5\";s:3:\"url\";s:52:\"https://downloads.wordpress.org/theme/neve.2.9.5.zip\";}i:85;a:2:{s:7:\"version\";s:6:\"2.10.0\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.10.0.zip\";}i:86;a:2:{s:7:\"version\";s:6:\"2.10.1\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.10.1.zip\";}i:87;a:2:{s:7:\"version\";s:6:\"2.10.2\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.10.2.zip\";}i:88;a:2:{s:7:\"version\";s:6:\"2.10.3\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.10.3.zip\";}i:89;a:2:{s:7:\"version\";s:6:\"2.10.4\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.10.4.zip\";}i:90;a:2:{s:7:\"version\";s:6:\"2.11.0\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.11.0.zip\";}i:91;a:2:{s:7:\"version\";s:6:\"2.11.1\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.11.1.zip\";}i:92;a:2:{s:7:\"version\";s:6:\"2.11.2\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.11.2.zip\";}i:93;a:2:{s:7:\"version\";s:6:\"2.11.3\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.11.3.zip\";}i:94;a:2:{s:7:\"version\";s:6:\"2.11.4\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.11.4.zip\";}i:95;a:2:{s:7:\"version\";s:6:\"2.11.5\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.11.5.zip\";}i:96;a:2:{s:7:\"version\";s:6:\"2.11.6\";s:3:\"url\";s:53:\"https://downloads.wordpress.org/theme/neve.2.11.6.zip\";}}","no"),
("625","_transient_timeout_orders-all-statuses","1623150066","no"),
("626","_transient_orders-all-statuses","a:2:{s:7:\"version\";s:10:\"1619687030\";s:5:\"value\";a:0:{}}","no"),
("627","_transient_timeout_wc_onboarding_themes","1622631666","no"),
("628","_transient_wc_onboarding_themes","a:32:{s:4:\"neve\";a:6:{s:4:\"slug\";s:4:\"neve\";s:5:\"title\";s:4:\"Neve\";s:5:\"price\";s:4:\"0.00\";s:12:\"is_installed\";b:1;s:5:\"image\";s:59:\"http://localhost:8888/wp-content/themes/neve/screenshot.png\";s:23:\"has_woocommerce_support\";b:1;}s:10:\"storefront\";a:6:{s:4:\"slug\";s:10:\"storefront\";s:5:\"title\";s:10:\"Storefront\";s:5:\"price\";s:4:\"0.00\";s:12:\"is_installed\";b:1;s:5:\"image\";s:65:\"http://localhost:8888/wp-content/themes/storefront/screenshot.png\";s:23:\"has_woocommerce_support\";b:1;}s:10:\"smart-home\";a:11:{s:5:\"title\";s:10:\"Smart Home\";s:5:\"image\";s:62:\"https://woocommerce.com/wp-content/uploads/2021/04/browser.jpg\";s:7:\"excerpt\";s:131:\"Smart Home is a beautiful Gutenberg-powered theme with a technology-style look suitable for all stores selling smart home products.\";s:4:\"link\";s:103:\"https://woocommerce.com/products/smart-home/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:33:\"https://smarthome.fuelthemes.net/\";s:5:\"price\";s:10:\"&#36;79.00\";s:4:\"hash\";s:36:\"d1d581ad-3efa-40c2-b7e0-bb6722779a0b\";s:4:\"slug\";s:10:\"smart-home\";s:2:\"id\";i:7916465;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:6:\"skinny\";a:11:{s:5:\"title\";s:6:\"Skinny\";s:5:\"image\";s:71:\"https://woocommerce.com/wp-content/uploads/2021/04/SKfeatured.png?w=800\";s:7:\"excerpt\";s:123:\"Create a beautiful online shop with Skinny, and optionally allow your site visitors to switch between light and dark skins.\";s:4:\"link\";s:99:\"https://woocommerce.com/products/skinny/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:32:\"https://demo.codestag.com/skinny\";s:5:\"price\";s:10:\"&#36;69.00\";s:4:\"hash\";s:36:\"a21bf5b9-3c45-4d6c-bf24-74ddae21023f\";s:4:\"slug\";s:6:\"skinny\";s:2:\"id\";i:7753168;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:12:\"pure-fashion\";a:11:{s:5:\"title\";s:12:\"Pure Fashion\";s:5:\"image\";s:62:\"https://woocommerce.com/wp-content/uploads/2021/03/browser.jpg\";s:7:\"excerpt\";s:88:\"Beautiful WooCommerce theme with soft colors and a unique layout using Gutenberg editor.\";s:4:\"link\";s:105:\"https://woocommerce.com/products/pure-fashion/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:35:\"https://purefashion.fuelthemes.net/\";s:5:\"price\";s:10:\"&#36;79.00\";s:4:\"hash\";s:36:\"9d7ed165-8435-4b0f-8315-8e4a5868f0b0\";s:4:\"slug\";s:12:\"pure-fashion\";s:2:\"id\";i:7704815;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:8:\"overline\";a:11:{s:5:\"title\";s:8:\"Overline\";s:5:\"image\";s:63:\"https://woocommerce.com/wp-content/uploads/2020/11/overline.jpg\";s:7:\"excerpt\";s:171:\"Overline is designed for the new generation of beauty brands and influencers opening their own e-commerce shops. Custom Gutenberg elements allow for increased flexibility.\";s:4:\"link\";s:101:\"https://woocommerce.com/products/overline/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:32:\"https://overline.fuelthemes.net/\";s:5:\"price\";s:10:\"&#36;79.00\";s:4:\"hash\";s:36:\"6eab91f2-ca09-4f7e-9022-df55fd8540a9\";s:4:\"slug\";s:8:\"overline\";s:2:\"id\";i:7320744;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:6:\"agency\";a:11:{s:5:\"title\";s:6:\"Agency\";s:5:\"image\";s:70:\"https://woocommerce.com/wp-content/uploads/2020/10/agency-featured.jpg\";s:7:\"excerpt\";s:134:\"Agency is a Gutenberg and WooCommerce optimized WordPress theme for marketing, advertising, and creative agencies. Sell your services!\";s:4:\"link\";s:99:\"https://woocommerce.com/products/agency/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:38:\"https://organicthemes.com/demo/agency/\";s:5:\"price\";s:10:\"&#36;79.00\";s:4:\"hash\";s:36:\"4a3a3a22-a5f0-4fa4-8c09-4f37575602ef\";s:4:\"slug\";s:6:\"agency\";s:2:\"id\";i:6674855;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:6:\"rhodes\";a:11:{s:5:\"title\";s:6:\"Rhodes\";s:5:\"image\";s:66:\"https://woocommerce.com/wp-content/uploads/2020/09/rhodes-home.jpg\";s:7:\"excerpt\";s:193:\"The perfect WooCommerce theme for retailers. Whether you\'re selling high-street fashion, beauty products, or home accessories, Rhodes will just stand out of the way letting your products shine.\";s:4:\"link\";s:99:\"https://woocommerce.com/products/rhodes/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:34:\"https://www.cssigniter.com/rhodes/\";s:5:\"price\";s:10:\"&#36;79.00\";s:4:\"hash\";s:36:\"b95c0103-23b9-43f3-af49-ee7eaa35e49b\";s:4:\"slug\";s:6:\"rhodes\";s:2:\"id\";i:6509339;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:11:\"restoration\";a:11:{s:5:\"title\";s:11:\"Restoration\";s:5:\"image\";s:78:\"https://woocommerce.com/wp-content/uploads/2020/09/restoration-woocommerce.jpg\";s:7:\"excerpt\";s:90:\"An elegant and sophisticated mobile-first, Gutenberg-powered theme for WooCommerce stores.\";s:4:\"link\";s:104:\"https://woocommerce.com/products/restoration/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:35:\"https://restoration.fuelthemes.net/\";s:5:\"price\";s:10:\"&#36;79.00\";s:4:\"hash\";s:36:\"e793e6af-f338-4e92-b268-e0576ddb137b\";s:4:\"slug\";s:11:\"restoration\";s:2:\"id\";i:6454820;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:7:\"matthew\";a:11:{s:5:\"title\";s:7:\"Matthew\";s:5:\"image\";s:73:\"https://woocommerce.com/wp-content/uploads/2020/07/matthew-screenshot.jpg\";s:7:\"excerpt\";s:145:\"Matthew is a Gutenberg-powered WooCommerce theme designed for building a professional online store so that you can sell goods or services online.\";s:4:\"link\";s:100:\"https://woocommerce.com/products/matthew/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:38:\"https://demo.themesharbor.com/matthew/\";s:5:\"price\";s:11:\"&#36;129.00\";s:4:\"hash\";s:36:\"b3983408-c4f6-4751-8bd7-ae65ae34cf3b\";s:4:\"slug\";s:7:\"matthew\";s:2:\"id\";i:6214538;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:11:\"fifthavenue\";a:11:{s:5:\"title\";s:12:\"Fifth Avenue\";s:5:\"image\";s:78:\"https://woocommerce.com/wp-content/uploads/2020/06/fifthavenue-woocommerce.jpg\";s:7:\"excerpt\";s:103:\"Beautiful Gutenberg powered WooCommerce theme designed to be easily customized for all types of stores.\";s:4:\"link\";s:105:\"https://woocommerce.com/products/fifth-avenue/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:35:\"https://fifthavenue.fuelthemes.net/\";s:5:\"price\";s:10:\"&#36;79.00\";s:4:\"hash\";s:36:\"9e093a9f-3d49-4fcd-bec7-c87b097d9df8\";s:4:\"slug\";s:11:\"fifthavenue\";s:2:\"id\";i:5989481;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:7:\"artisan\";a:11:{s:5:\"title\";s:7:\"Artisan\";s:5:\"image\";s:71:\"https://woocommerce.com/wp-content/uploads/2020/03/artisan-featured.jpg\";s:7:\"excerpt\";s:79:\"Sell your hand-crafted products online using the Artisan Theme for WooCommerce.\";s:4:\"link\";s:100:\"https://woocommerce.com/products/artisan/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:39:\"https://organicthemes.com/demo/artisan/\";s:5:\"price\";s:10:\"&#36;79.00\";s:4:\"hash\";s:36:\"64529812-81f6-4efd-9686-ecb34e527421\";s:4:\"slug\";s:7:\"artisan\";s:2:\"id\";i:5576887;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:7:\"threads\";a:11:{s:5:\"title\";s:7:\"Threads\";s:5:\"image\";s:75:\"https://woocommerce.com/wp-content/uploads/2019/08/threads-home-cropped.jpg\";s:7:\"excerpt\";s:79:\"Create a stunning website for your apparel brand using Threads for WooCommerce.\";s:4:\"link\";s:100:\"https://woocommerce.com/products/threads/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:39:\"https://organicthemes.com/demo/threads/\";s:5:\"price\";s:10:\"&#36;79.00\";s:4:\"hash\";s:36:\"7ca579a6-6aaf-498c-9ee7-e15280ace9e9\";s:4:\"slug\";s:7:\"threads\";s:2:\"id\";i:4663191;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:10:\"block-shop\";a:11:{s:5:\"title\";s:10:\"Block Shop\";s:5:\"image\";s:79:\"https://woocommerce.com/wp-content/uploads/2019/08/block-shop-theme-preview.jpg\";s:7:\"excerpt\";s:81:\"A hassle-free Block-Editor-Era theme for your next WooCommerce project.

&nbsp;\";s:4:\"link\";s:103:\"https://woocommerce.com/products/block-shop/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:34:\"https://blockshop.wp-theme.design/\";s:5:\"price\";s:10:\"&#36;59.00\";s:4:\"hash\";s:36:\"21fa433c-6c31-4be7-83ab-8d2cc8986130\";s:4:\"slug\";s:10:\"block-shop\";s:2:\"id\";i:4660093;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:6:\"bistro\";a:11:{s:5:\"title\";s:6:\"Bistro\";s:5:\"image\";s:61:\"https://woocommerce.com/wp-content/uploads/2016/07/bistro.png\";s:7:\"excerpt\";s:174:\"Bistro is a Storefront child theme designed for stores selling organic goods and other consumables. It features a friendly and warm design that lends itself to this industry.\";s:4:\"link\";s:99:\"https://woocommerce.com/products/bistro/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:37:\"https://themes.woocommerce.com/bistro\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"58e753f91fddf40abe8ebe4486f8c378\";s:4:\"slug\";s:6:\"bistro\";s:2:\"id\";i:1822936;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:10:\"stationery\";a:11:{s:5:\"title\";s:10:\"Stationery\";s:5:\"image\";s:65:\"https://woocommerce.com/wp-content/uploads/2016/04/stationery.jpg\";s:7:\"excerpt\";s:186:\"Stationery is a Storefront child theme designed for stores selling office supplies and/or arts &amp; crafts. The design has subtle tactile decorations while also being clean and elegant.\";s:4:\"link\";s:103:\"https://woocommerce.com/products/stationery/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:42:\"https://themes.woocommerce.com/stationery/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"b939225b8b8ccdc7b14ffb6d7eab2ac2\";s:4:\"slug\";s:10:\"stationery\";s:2:\"id\";i:1629126;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:7:\"petshop\";a:11:{s:5:\"title\";s:7:\"Petshop\";s:5:\"image\";s:62:\"https://woocommerce.com/wp-content/uploads/2016/03/petshop.png\";s:7:\"excerpt\";s:181:\"Petshop is a Storefront child theme designed for stores selling products in the pet industry. The design is organic and friendly, featuring many details that point to pet ownership.\";s:4:\"link\";s:100:\"https://woocommerce.com/products/petshop/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:39:\"https://themes.woocommerce.com/petshop/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"8060743c9031974326850f539aba5196\";s:4:\"slug\";s:7:\"petshop\";s:2:\"id\";i:1587689;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:5:\"hotel\";a:11:{s:5:\"title\";s:5:\"Hotel\";s:5:\"image\";s:69:\"https://woocommerce.com/wp-content/uploads/2016/03/hotel-featured.jpg\";s:7:\"excerpt\";s:246:\"Hotel is designed for businesses selling time, services and accommodation, offering unique integration with WooCommerce Bookings and Accommodation Bookings. The design is bold yet simple, allowing your content and imagery to do all the talking.\";s:4:\"link\";s:98:\"https://woocommerce.com/products/hotel/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:37:\"https://themes.woocommerce.com/hotel/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"0b0df891aa46f289f4e49bae2389bb04\";s:4:\"slug\";s:5:\"hotel\";s:2:\"id\";i:1554532;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:8:\"bookshop\";a:11:{s:5:\"title\";s:8:\"Bookshop\";s:5:\"image\";s:63:\"https://woocommerce.com/wp-content/uploads/2016/02/featured.png\";s:7:\"excerpt\";s:183:\"Bookshop comes with a unique homepage layout that prominently displays product categories and a variety of products in an arrangement that is popular with bookstores and collectibles.\";s:4:\"link\";s:101:\"https://woocommerce.com/products/bookshop/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:40:\"https://themes.woocommerce.com/bookshop/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"9fe861227e3e82fde8fe5d7e8cc3340e\";s:4:\"slug\";s:8:\"bookshop\";s:2:\"id\";i:1508713;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:6:\"arcade\";a:11:{s:5:\"title\";s:6:\"Arcade\";s:5:\"image\";s:61:\"https://woocommerce.com/wp-content/uploads/2016/01/arcade.png\";s:7:\"excerpt\";s:216:\"Upgrade your video game shops look and feel with Arcade. It\'s bold and modern design will engage visitors and the unique homepage layout will present them with a variety of products as soon as they hit your homepage.\";s:4:\"link\";s:99:\"https://woocommerce.com/products/arcade/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:38:\"https://themes.woocommerce.com/arcade/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"5af09d4e590eec977c6b9519b517f479\";s:4:\"slug\";s:6:\"arcade\";s:2:\"id\";i:1418260;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:9:\"homestore\";a:11:{s:5:\"title\";s:9:\"Homestore\";s:5:\"image\";s:64:\"https://woocommerce.com/wp-content/uploads/2015/12/homestore.jpg\";s:7:\"excerpt\";s:166:\"Give your Department Store a classic look with Homestore. Its clean and efficient design will work well whether you\'re a boutique independent or a high street giant.\";s:4:\"link\";s:102:\"https://woocommerce.com/products/homestore/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:41:\"https://themes.woocommerce.com/homestore/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"d79fe7a1beba26523aafa6ce6d3e1e85\";s:4:\"slug\";s:9:\"homestore\";s:2:\"id\";i:1365559;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:8:\"pharmacy\";a:11:{s:5:\"title\";s:8:\"Pharmacy\";s:5:\"image\";s:63:\"https://woocommerce.com/wp-content/uploads/2015/12/pharmacy.jpg\";s:7:\"excerpt\";s:235:\"Give your health store a professional, trust-worthy design with the Pharmacy Storefront Child Theme. Built upon our rock solid Storefront Parent theme you\'ll also enjoy reliable integration with current and future WooCommerce releases.\";s:4:\"link\";s:101:\"https://woocommerce.com/products/pharmacy/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:40:\"https://themes.woocommerce.com/pharmacy/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"ebeff3c0f89cd3169fb6b3e7e137e513\";s:4:\"slug\";s:8:\"pharmacy\";s:2:\"id\";i:1365557;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:7:\"toyshop\";a:11:{s:5:\"title\";s:7:\"ToyShop\";s:5:\"image\";s:62:\"https://woocommerce.com/wp-content/uploads/2015/09/toyshop.jpg\";s:7:\"excerpt\";s:269:\"Add some fun to your store with ToyShop. The engaging and colorful design of ToyShop makes it a perfect child theme or any store that sells exciting products that are aimed at customers that like to have fun. The outdoorsy style would even be perfect for a flower shop.\";s:4:\"link\";s:100:\"https://woocommerce.com/products/toyshop/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:39:\"https://themes.woocommerce.com/toyshop/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"3e2520021b41ee49a55b93362aaced98\";s:4:\"slug\";s:7:\"toyshop\";s:2:\"id\";i:1230716;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:6:\"outlet\";a:11:{s:5:\"title\";s:6:\"Outlet\";s:5:\"image\";s:61:\"https://woocommerce.com/wp-content/uploads/2015/09/outlet.jpg\";s:7:\"excerpt\";s:221:\"Overclock your tech store with Outlet! Whether you sell boutique iPad jewellery or the nuts and bolts of hardware itself, Outlet will give your shop a stylish look and feel while enjoying the stability of Storefront core.\";s:4:\"link\";s:99:\"https://woocommerce.com/products/outlet/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:38:\"https://themes.woocommerce.com/outlet/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"4c311cb3a3131570946b8799715a0991\";s:4:\"slug\";s:6:\"outlet\";s:2:\"id\";i:1212805;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:7:\"proshop\";a:11:{s:5:\"title\";s:7:\"ProShop\";s:5:\"image\";s:62:\"https://woocommerce.com/wp-content/uploads/2015/06/proshop.jpg\";s:7:\"excerpt\";s:176:\"Unlock the true potential of your sports clothing and equipment store with ProShop! It\'s metropolitan design provides an active aesthetic giving your store oodles of character.\";s:4:\"link\";s:100:\"https://woocommerce.com/products/proshop/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:39:\"https://themes.woocommerce.com/proshop/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"1d51b8633bbd1782dc17fce15f8bd2af\";s:4:\"slug\";s:7:\"proshop\";s:2:\"id\";i:1000757;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:8:\"galleria\";a:11:{s:5:\"title\";s:8:\"Galleria\";s:5:\"image\";s:68:\"https://woocommerce.com/wp-content/uploads/2015/05/galleria-hero.png\";s:7:\"excerpt\";s:162:\"Galleria is a Storefront child theme perfect for fashion and design stores. Stylish and minimalist, it gives sites a classy look and keeps products center stage.\";s:4:\"link\";s:101:\"https://woocommerce.com/products/galleria/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:40:\"https://themes.woocommerce.com/galleria/\";s:5:\"price\";s:10:\"&#36;39.00\";s:4:\"hash\";s:32:\"2429c1dde521031cd053886b15844bbf\";s:4:\"slug\";s:8:\"galleria\";s:2:\"id\";i:887931;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:4:\"deli\";a:11:{s:5:\"title\";s:4:\"Deli\";s:5:\"image\";s:59:\"https://woocommerce.com/wp-content/uploads/2015/03/deli.jpg\";s:7:\"excerpt\";s:135:\"Deli is a Storefront child theme featuring a texturised, earthy design, perfect for stores selling natural, organic or hand made goods.\";s:4:\"link\";s:97:\"https://woocommerce.com/products/deli/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:36:\"https://themes.woocommerce.com/deli/\";s:5:\"price\";s:9:\"&#36;0.00\";s:4:\"hash\";s:32:\"83c6db94c8ebf9da56b59fb97f724e88\";s:4:\"slug\";s:4:\"deli\";s:2:\"id\";i:784823;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:8:\"boutique\";a:11:{s:5:\"title\";s:8:\"Boutique\";s:5:\"image\";s:63:\"https://woocommerce.com/wp-content/uploads/2015/01/boutique.png\";s:7:\"excerpt\";s:168:\"Boutique is a simple, traditionally designed Storefront child theme, ideal for small stores or boutiques. Add your logo, create a unique color scheme and start selling!\";s:4:\"link\";s:101:\"https://woocommerce.com/products/boutique/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons\";s:8:\"demo_url\";s:40:\"https://themes.woocommerce.com/boutique/\";s:5:\"price\";s:9:\"&#36;0.00\";s:4:\"hash\";s:32:\"71815288e266d58031727d48d6deee25\";s:4:\"slug\";s:8:\"boutique\";s:2:\"id\";i:605777;s:12:\"is_installed\";b:0;s:23:\"has_woocommerce_support\";b:1;}s:7:\"oceanwp\";a:6:{s:4:\"slug\";s:7:\"oceanwp\";s:5:\"title\";s:7:\"OceanWP\";s:5:\"price\";s:4:\"0.00\";s:12:\"is_installed\";b:1;s:5:\"image\";s:62:\"http://localhost:8888/wp-content/themes/oceanwp/screenshot.png\";s:23:\"has_woocommerce_support\";b:1;}s:14:\"twentynineteen\";a:6:{s:4:\"slug\";s:14:\"twentynineteen\";s:5:\"title\";s:15:\"Twenty Nineteen\";s:5:\"price\";s:4:\"0.00\";s:12:\"is_installed\";b:1;s:5:\"image\";s:69:\"http://localhost:8888/wp-content/themes/twentynineteen/screenshot.png\";s:23:\"has_woocommerce_support\";b:1;}s:12:\"twentytwenty\";a:6:{s:4:\"slug\";s:12:\"twentytwenty\";s:5:\"title\";s:13:\"Twenty Twenty\";s:5:\"price\";s:4:\"0.00\";s:12:\"is_installed\";b:1;s:5:\"image\";s:67:\"http://localhost:8888/wp-content/themes/twentytwenty/screenshot.png\";s:23:\"has_woocommerce_support\";b:1;}s:15:\"twentytwentyone\";a:6:{s:4:\"slug\";s:15:\"twentytwentyone\";s:5:\"title\";s:17:\"Twenty Twenty-One\";s:5:\"price\";s:4:\"0.00\";s:12:\"is_installed\";b:1;s:5:\"image\";s:70:\"http://localhost:8888/wp-content/themes/twentytwentyone/screenshot.png\";s:23:\"has_woocommerce_support\";b:1;}}","no"),
("629","_transient_timeout_wc_report_orders_stats_e3e37c2a72fc23fe00ec6708246fb936","1623150069","no"),
("630","_transient_wc_report_orders_stats_e3e37c2a72fc23fe00ec6708246fb936","a:2:{s:7:\"version\";s:10:\"1619687030\";s:5:\"value\";O:8:\"stdClass\":5:{s:6:\"totals\";O:8:\"stdClass\":15:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"products\";i:0;s:8:\"segments\";a:0:{}}s:9:\"intervals\";a:1:{i:0;a:6:{s:8:\"interval\";s:7:\"2021-22\";s:10:\"date_start\";s:19:\"2021-06-01 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2021-06-01 00:00:00\";s:8:\"date_end\";s:19:\"2021-06-01 13:01:00\";s:12:\"date_end_gmt\";s:19:\"2021-06-01 13:01:00\";s:9:\"subtotals\";O:8:\"stdClass\":14:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"segments\";a:0:{}}}}s:5:\"total\";i:1;s:5:\"pages\";i:1;s:7:\"page_no\";i:1;}}","no"),
("631","_transient_timeout_wc_report_orders_stats_5eec1a11b2ad9ec87abe27acea18bb59","1623150069","no"),
("632","_transient_wc_report_orders_stats_5eec1a11b2ad9ec87abe27acea18bb59","a:2:{s:7:\"version\";s:10:\"1619687030\";s:5:\"value\";O:8:\"stdClass\":5:{s:6:\"totals\";O:8:\"stdClass\":15:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"products\";i:0;s:8:\"segments\";a:0:{}}s:9:\"intervals\";a:1:{i:0;a:6:{s:8:\"interval\";s:7:\"2021-22\";s:10:\"date_start\";s:19:\"2021-06-01 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2021-06-01 00:00:00\";s:8:\"date_end\";s:19:\"2021-06-01 13:01:00\";s:12:\"date_end_gmt\";s:19:\"2021-06-01 13:01:00\";s:9:\"subtotals\";O:8:\"stdClass\":14:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"segments\";a:0:{}}}}s:5:\"total\";i:1;s:5:\"pages\";i:1;s:7:\"page_no\";i:1;}}","no"),
("633","_transient_timeout_wc_report_orders_stats_608f895fa7bfb858b0ed4c72ed50afa0","1623150069","no"),
("634","_transient_wc_report_orders_stats_608f895fa7bfb858b0ed4c72ed50afa0","a:2:{s:7:\"version\";s:10:\"1619687030\";s:5:\"value\";O:8:\"stdClass\":5:{s:6:\"totals\";O:8:\"stdClass\":15:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"products\";i:0;s:8:\"segments\";a:0:{}}s:9:\"intervals\";a:1:{i:0;a:6:{s:8:\"interval\";s:7:\"2021-22\";s:10:\"date_start\";s:19:\"2021-05-31 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2021-05-31 00:00:00\";s:8:\"date_end\";s:19:\"2021-05-31 23:59:59\";s:12:\"date_end_gmt\";s:19:\"2021-05-31 23:59:59\";s:9:\"subtotals\";O:8:\"stdClass\":14:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"segments\";a:0:{}}}}s:5:\"total\";i:1;s:5:\"pages\";i:1;s:7:\"page_no\";i:1;}}","no"),
("635","_transient_timeout_wc_report_orders_stats_76d5583fe512a51f8e464a0e944c0097","1623150069","no"),
("636","_transient_wc_report_orders_stats_76d5583fe512a51f8e464a0e944c0097","a:2:{s:7:\"version\";s:10:\"1619687030\";s:5:\"value\";O:8:\"stdClass\":5:{s:6:\"totals\";O:8:\"stdClass\":15:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"products\";i:0;s:8:\"segments\";a:0:{}}s:9:\"intervals\";a:1:{i:0;a:6:{s:8:\"interval\";s:7:\"2021-22\";s:10:\"date_start\";s:19:\"2021-05-31 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2021-05-31 00:00:00\";s:8:\"date_end\";s:19:\"2021-05-31 23:59:59\";s:12:\"date_end_gmt\";s:19:\"2021-05-31 23:59:59\";s:9:\"subtotals\";O:8:\"stdClass\":14:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"segments\";a:0:{}}}}s:5:\"total\";i:1;s:5:\"pages\";i:1;s:7:\"page_no\";i:1;}}","no"),
("637","woocommerce_task_list_welcome_modal_dismissed","yes","yes"),
("639","_transient_timeout_mollie-wc-e202d02678d036ae17750ca5b1d61832","1622548911","no"),
("640","_transient_mollie-wc-e202d02678d036ae17750ca5b1d61832","a:3:{i:0;a:10:{s:2:\"id\";s:5:\"ideal\";s:11:\"description\";s:5:\"iDEAL\";s:13:\"minimumAmount\";O:8:\"stdClass\":2:{s:5:\"value\";s:4:\"0.01\";s:8:\"currency\";s:3:\"EUR\";}s:13:\"maximumAmount\";O:8:\"stdClass\":2:{s:5:\"value\";s:8:\"50000.00\";s:8:\"currency\";s:3:\"EUR\";}s:5:\"image\";O:8:\"stdClass\":3:{s:6:\"size1x\";s:63:\"https://www.mollie.com/external/icons/payment-methods/ideal.png\";s:6:\"size2x\";s:68:\"https://www.mollie.com/external/icons/payment-methods/ideal%402x.png\";s:3:\"svg\";s:63:\"https://www.mollie.com/external/icons/payment-methods/ideal.svg\";}s:7:\"issuers\";N;s:7:\"pricing\";N;s:6:\"status\";s:9:\"activated\";s:6:\"_links\";O:8:\"stdClass\":1:{s:4:\"self\";O:8:\"stdClass\":2:{s:4:\"href\";s:39:\"https://api.mollie.com/v2/methods/ideal\";s:4:\"type\";s:20:\"application/hal+json\";}}s:8:\"resource\";s:6:\"method\";}i:1;a:10:{s:2:\"id\";s:12:\"banktransfer\";s:11:\"description\";s:13:\"Bank transfer\";s:13:\"minimumAmount\";O:8:\"stdClass\":2:{s:5:\"value\";s:4:\"0.01\";s:8:\"currency\";s:3:\"EUR\";}s:13:\"maximumAmount\";O:8:\"stdClass\":2:{s:5:\"value\";s:10:\"1000000.00\";s:8:\"currency\";s:3:\"EUR\";}s:5:\"image\";O:8:\"stdClass\":3:{s:6:\"size1x\";s:70:\"https://www.mollie.com/external/icons/payment-methods/banktransfer.png\";s:6:\"size2x\";s:75:\"https://www.mollie.com/external/icons/payment-methods/banktransfer%402x.png\";s:3:\"svg\";s:70:\"https://www.mollie.com/external/icons/payment-methods/banktransfer.svg\";}s:7:\"issuers\";N;s:7:\"pricing\";N;s:6:\"status\";s:9:\"activated\";s:6:\"_links\";O:8:\"stdClass\":1:{s:4:\"self\";O:8:\"stdClass\":2:{s:4:\"href\";s:46:\"https://api.mollie.com/v2/methods/banktransfer\";s:4:\"type\";s:20:\"application/hal+json\";}}s:8:\"resource\";s:6:\"method\";}i:2;a:10:{s:2:\"id\";s:7:\"voucher\";s:11:\"description\";s:8:\"Vouchers\";s:13:\"minimumAmount\";O:8:\"stdClass\":2:{s:5:\"value\";s:4:\"1.00\";s:8:\"currency\";s:3:\"EUR\";}s:13:\"maximumAmount\";O:8:\"stdClass\":2:{s:5:\"value\";s:9:\"100000.00\";s:8:\"currency\";s:3:\"EUR\";}s:5:\"image\";O:8:\"stdClass\":3:{s:6:\"size1x\";s:65:\"https://www.mollie.com/external/icons/payment-methods/voucher.png\";s:6:\"size2x\";s:70:\"https://www.mollie.com/external/icons/payment-methods/voucher%402x.png\";s:3:\"svg\";s:65:\"https://www.mollie.com/external/icons/payment-methods/voucher.svg\";}s:7:\"issuers\";N;s:7:\"pricing\";N;s:6:\"status\";N;s:6:\"_links\";O:8:\"stdClass\":1:{s:4:\"self\";O:8:\"stdClass\":2:{s:4:\"href\";s:41:\"https://api.mollie.com/v2/methods/voucher\";s:4:\"type\";s:20:\"application/hal+json\";}}s:8:\"resource\";s:6:\"method\";}}","no"),
("641","_transient_timeout_mollie-wc-12e3e61bd6cc295a13d0e703c29d14f4","1622548911","no"),
("642","_transient_mollie-wc-12e3e61bd6cc295a13d0e703c29d14f4","a:2:{i:0;a:10:{s:2:\"id\";s:10:\"creditcard\";s:11:\"description\";s:11:\"Credit card\";s:13:\"minimumAmount\";O:8:\"stdClass\":2:{s:5:\"value\";s:4:\"0.01\";s:8:\"currency\";s:3:\"EUR\";}s:13:\"maximumAmount\";O:8:\"stdClass\":2:{s:5:\"value\";s:7:\"2000.00\";s:8:\"currency\";s:3:\"EUR\";}s:5:\"image\";O:8:\"stdClass\":3:{s:6:\"size1x\";s:68:\"https://www.mollie.com/external/icons/payment-methods/creditcard.png\";s:6:\"size2x\";s:73:\"https://www.mollie.com/external/icons/payment-methods/creditcard%402x.png\";s:3:\"svg\";s:68:\"https://www.mollie.com/external/icons/payment-methods/creditcard.svg\";}s:7:\"issuers\";N;s:7:\"pricing\";N;s:6:\"status\";N;s:6:\"_links\";O:8:\"stdClass\":1:{s:4:\"self\";O:8:\"stdClass\":2:{s:4:\"href\";s:44:\"https://api.mollie.com/v2/methods/creditcard\";s:4:\"type\";s:20:\"application/hal+json\";}}s:8:\"resource\";s:6:\"method\";}i:1;a:10:{s:2:\"id\";s:11:\"directdebit\";s:11:\"description\";s:17:\"SEPA Direct Debit\";s:13:\"minimumAmount\";O:8:\"stdClass\":2:{s:5:\"value\";s:4:\"0.01\";s:8:\"currency\";s:3:\"EUR\";}s:13:\"maximumAmount\";O:8:\"stdClass\":2:{s:5:\"value\";s:7:\"1000.00\";s:8:\"currency\";s:3:\"EUR\";}s:5:\"image\";O:8:\"stdClass\":3:{s:6:\"size1x\";s:69:\"https://www.mollie.com/external/icons/payment-methods/directdebit.png\";s:6:\"size2x\";s:74:\"https://www.mollie.com/external/icons/payment-methods/directdebit%402x.png\";s:3:\"svg\";s:69:\"https://www.mollie.com/external/icons/payment-methods/directdebit.svg\";}s:7:\"issuers\";N;s:7:\"pricing\";N;s:6:\"status\";N;s:6:\"_links\";O:8:\"stdClass\":1:{s:4:\"self\";O:8:\"stdClass\":2:{s:4:\"href\";s:45:\"https://api.mollie.com/v2/methods/directdebit\";s:4:\"type\";s:20:\"application/hal+json\";}}s:8:\"resource\";s:6:\"method\";}}","no"),
("644","_transient_timeout_wc_shipping_method_count","1625137375","no"),
("645","_transient_wc_shipping_method_count","a:2:{s:7:\"version\";s:10:\"1622544205\";s:5:\"value\";i:0;}","no"),
("648","_transient_timeout_wc_addons_sections","1623150250","no"),
("649","_transient_wc_addons_sections","a:9:{i:0;O:8:\"stdClass\":2:{s:4:\"slug\";s:9:\"_featured\";s:5:\"label\";s:8:\"Featured\";}i:1;O:8:\"stdClass\":2:{s:4:\"slug\";s:4:\"_all\";s:5:\"label\";s:3:\"All\";}i:2;O:8:\"stdClass\":2:{s:4:\"slug\";s:18:\"product-extensions\";s:5:\"label\";s:12:\"Enhancements\";}i:3;O:8:\"stdClass\":2:{s:4:\"slug\";s:15:\"free-extensions\";s:5:\"label\";s:4:\"Free\";}i:4;O:8:\"stdClass\":2:{s:4:\"slug\";s:20:\"marketing-extensions\";s:5:\"label\";s:9:\"Marketing\";}i:5;O:8:\"stdClass\":2:{s:4:\"slug\";s:16:\"payment-gateways\";s:5:\"label\";s:8:\"Payments\";}i:6;O:8:\"stdClass\":2:{s:4:\"slug\";s:12:\"product-type\";s:5:\"label\";s:12:\"Product Type\";}i:7;O:8:\"stdClass\":2:{s:4:\"slug\";s:16:\"shipping-methods\";s:5:\"label\";s:8:\"Shipping\";}i:8;O:8:\"stdClass\":2:{s:4:\"slug\";s:10:\"operations\";s:5:\"label\";s:16:\"Store Management\";}}","no"),
("650","_transient_timeout_wc_addons_featured","1622631850","no"),
("651","_transient_wc_addons_featured","O:8:\"stdClass\":1:{s:8:\"sections\";a:12:{i:0;O:8:\"stdClass\":4:{s:6:\"module\";s:12:\"banner_block\";s:5:\"title\";s:50:\"Take your store beyond the typical - sell anything\";s:11:\"description\";s:81:\"From services to content, there\'s no limit to what you can sell with WooCommerce.\";s:5:\"items\";a:9:{i:0;O:8:\"stdClass\":6:{s:4:\"href\";s:128:\"https://woocommerce.com/products/woocommerce-subscriptions/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:13:\"Subscriptions\";s:5:\"image\";s:71:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/subscriptions-icon@2x.png\";s:11:\"description\";s:98:\"Let customers subscribe to your products or services and pay on a weekly, monthly or annual basis.\";s:6:\"button\";s:10:\"From: $199\";s:6:\"plugin\";s:55:\"woocommerce-subscriptions/woocommerce-subscriptions.php\";}i:1;O:8:\"stdClass\":6:{s:4:\"href\";s:123:\"https://woocommerce.com/products/woocommerce-bookings/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:8:\"Bookings\";s:5:\"image\";s:66:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/bookings-icon@2x.png\";s:11:\"description\";s:76:\"Allow customers to book appointments for services without leaving your site.\";s:6:\"button\";s:10:\"From: $249\";s:6:\"plugin\";s:45:\"woocommerce-bookings/woocommerce-bookings.php\";}i:2;O:8:\"stdClass\":6:{s:4:\"href\";s:126:\"https://woocommerce.com/products/woocommerce-memberships/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:11:\"Memberships\";s:5:\"image\";s:69:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/memberships-icon@2x.png\";s:11:\"description\";s:76:\"Give members access to restricted content or products, for a fee or for free\";s:6:\"button\";s:10:\"From: $199\";s:6:\"plugin\";s:51:\"woocommerce-memberships/woocommerce-memberships.php\";}i:3;O:8:\"stdClass\":6:{s:4:\"href\";s:118:\"https://woocommerce.com/products/product-bundles/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:15:\"Product Bundles\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:50:\"Offer customizable bundles and assembled products.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:59:\"woocommerce-product-bundles/woocommerce-product-bundles.php\";}i:4;O:8:\"stdClass\":6:{s:4:\"href\";s:121:\"https://woocommerce.com/products/composite-products/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:18:\"Composite Products\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:59:\"Create and offer product kits with configurable components.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:65:\"woocommerce-composite-products/woocommerce-composite-products.php\";}i:5;O:8:\"stdClass\":6:{s:4:\"href\";s:118:\"https://woocommerce.com/products/product-vendors/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:15:\"Product Vendors\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:47:\"Turn your store into a multi-vendor marketplace\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:59:\"woocommerce-product-vendors/woocommerce-product-vendors.php\";}i:6;O:8:\"stdClass\":6:{s:4:\"href\";s:121:\"https://woocommerce.com/products/groups-woocommerce/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:22:\"Groups for WooCommerce\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:94:\"Sell memberships using the free &#039;Groups&#039; plugin, Groups integration and WooCommerce.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:41:\"groups-woocommerce/groups-woocommerce.php\";}i:7;O:8:\"stdClass\":6:{s:4:\"href\";s:125:\"https://woocommerce.com/products/woocommerce-pre-orders/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:22:\"WooCommerce Pre-Orders\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:60:\"Allow customers to order products before they are available.\";s:6:\"button\";s:10:\"From: $129\";s:6:\"plugin\";s:49:\"woocommerce-pre-orders/woocommerce-pre-orders.php\";}i:8;O:8:\"stdClass\":6:{s:4:\"href\";s:119:\"https://woocommerce.com/products/chained-products/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:16:\"Chained Products\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:69:\"Create and sell pre-configured product bundles and discounted combos.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:61:\"woocommerce-chained-products/woocommerce-chained-products.php\";}}}i:1;O:8:\"stdClass\":1:{s:6:\"module\";s:18:\"wcpay_banner_block\";}i:2;O:8:\"stdClass\":1:{s:6:\"module\";s:16:\"wcs_banner_block\";}i:3;O:8:\"stdClass\":2:{s:6:\"module\";s:12:\"column_start\";s:9:\"container\";s:22:\"column_container_start\";}i:4;O:8:\"stdClass\":4:{s:6:\"module\";s:12:\"column_block\";s:5:\"title\";s:46:\"Improve the main features of your online store\";s:11:\"description\";s:71:\"Sell more by helping customers find the products and options they want.\";s:5:\"items\";a:9:{i:0;O:8:\"stdClass\":6:{s:4:\"href\";s:118:\"https://woocommerce.com/products/product-add-ons/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:15:\"Product Add-ons\";s:5:\"image\";s:73:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/product-add-ons-icon@2x.png\";s:11:\"description\";s:82:\"Give your customers the option to customize their purchase or add personalization.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:57:\"woocommerce-product-addons/woocommerce-product-addons.php\";}i:1;O:8:\"stdClass\":6:{s:4:\"href\";s:129:\"https://woocommerce.com/products/woocommerce-product-search/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:14:\"Product Search\";s:5:\"image\";s:72:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/product-search-icon@2x.png\";s:11:\"description\";s:67:\"Make sure customers find what they want when they search your site.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:57:\"woocommerce-product-search/woocommerce-product-search.php\";}i:2;O:8:\"stdClass\":6:{s:4:\"href\";s:131:\"https://woocommerce.com/products/woocommerce-checkout-add-ons/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:16:\"Checkout Add-ons\";s:5:\"image\";s:74:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/checkout-add-ons-icon@2x.png\";s:11:\"description\";s:89:\"Highlight relevant products, offers like free shipping and other upsells during checkout.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:61:\"woocommerce-checkout-add-ons/woocommerce-checkout-add-ons.php\";}i:3;O:8:\"stdClass\":6:{s:4:\"href\";s:136:\"https://woocommerce.com/products/woocommerce-checkout-field-editor/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:21:\"Checkout Field Editor\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:128:\"The checkout field editor provides you with an interface to add, edit and remove fields shown on your WooCommerce checkout page.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:71:\"woocommerce-checkout-field-editor/woocommerce-checkout-field-editor.php\";}i:4;O:8:\"stdClass\":6:{s:4:\"href\";s:127:\"https://woocommerce.com/products/woocommerce-social-login/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:24:\"WooCommerce Social Login\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:62:\"Enable Social Login for Seamless Checkout and Account Creation\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:53:\"woocommerce-social-login/woocommerce-social-login.php\";}i:5;O:8:\"stdClass\":6:{s:4:\"href\";s:124:\"https://woocommerce.com/products/woocommerce-wishlists/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:21:\"WooCommerce Wishlists\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:113:\"WooCommerce Wishlists allows guests and customers to create and add products to an unlimited number of Wishlists.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:47:\"woocommerce-wishlists/woocommerce-wishlists.php\";}i:6;O:8:\"stdClass\":6:{s:4:\"href\";s:115:\"https://woocommerce.com/products/cart-notices/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:12:\"Cart Notices\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:73:\"Display dynamic, actionable messages to your customers as they check out.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:53:\"woocommerce-cart-notices/woocommerce-cart-notices.php\";}i:7;O:8:\"stdClass\":6:{s:4:\"href\";s:115:\"https://woocommerce.com/products/cart-add-ons/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:12:\"Cart Add-ons\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:109:\"A powerful tool for driving incremental and impulse purchases by customers once they are in the shopping cart\";s:6:\"button\";s:9:\"From: $29\";s:6:\"plugin\";s:53:\"woocommerce-cart-add-ons/woocommerce-cart-add-ons.php\";}i:8;O:8:\"stdClass\":6:{s:4:\"href\";s:123:\"https://woocommerce.com/products/woocommerce-waitlist/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:20:\"WooCommerce Waitlist\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:117:\"With WooCommerce Waitlist customers can register for email notifications when out-of-stock products become available.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:45:\"woocommerce-waitlist/woocommerce-waitlist.php\";}}}i:5;O:8:\"stdClass\":5:{s:6:\"module\";s:17:\"small_light_block\";s:5:\"title\";s:34:\"Get the official WooCommerce theme\";s:11:\"description\";s:128:\"Storefront is the lean, flexible, and free theme, built by the people who make WooCommerce - everything you need to get started.\";s:5:\"image\";s:70:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/storefront-screen@2x.png\";s:7:\"buttons\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"href\";s:44:\"/wp-admin/theme-install.php?theme=storefront\";s:4:\"text\";s:7:\"Install\";}i:1;O:8:\"stdClass\":2:{s:4:\"href\";s:104:\"https://woocommerce.com/storefront/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:4:\"text\";s:9:\"Read More\";}}}i:6;O:8:\"stdClass\":1:{s:6:\"module\";s:10:\"column_end\";}i:7;O:8:\"stdClass\":1:{s:6:\"module\";s:12:\"column_start\";}i:8;O:8:\"stdClass\":4:{s:6:\"module\";s:16:\"small_dark_block\";s:5:\"title\";s:20:\"WooCommerce + Zapier\";s:11:\"description\";s:76:\"Save time. Avoid busywork. Connect your store to more than 2,000 cloud apps.\";s:5:\"items\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"href\";s:121:\"https://woocommerce.com/products/woocommerce-zapier/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:6:\"button\";s:9:\"From: $59\";}}}i:9;O:8:\"stdClass\":4:{s:6:\"module\";s:12:\"column_block\";s:5:\"title\";s:19:\"Get deeper insights\";s:11:\"description\";s:58:\"Learn how your store is performing with enhanced reporting\";s:5:\"items\";a:8:{i:0;O:8:\"stdClass\":6:{s:4:\"href\";s:131:\"https://woocommerce.com/products/woocommerce-google-analytics/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:16:\"Google Analytics\";s:5:\"image\";s:60:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/ga-icon@2x.png\";s:11:\"description\";s:93:\"Understand your customers and increase revenue with the world’s leading analytics platform.\";s:6:\"button\";s:4:\"Free\";s:6:\"plugin\";s:85:\"woocommerce-google-analytics-integration/woocommerce-google-analytics-integration.php\";}i:1;O:8:\"stdClass\":6:{s:4:\"href\";s:127:\"https://woocommerce.com/products/woocommerce-cart-reports/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:12:\"Cart reports\";s:5:\"image\";s:70:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/cart-reports-icon@2x.png\";s:11:\"description\";s:66:\"Get real-time reports on what customers are leaving in their cart.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:53:\"woocommerce-cart-reports/woocommerce-cart-reports.php\";}i:2;O:8:\"stdClass\":6:{s:4:\"href\";s:128:\"https://woocommerce.com/products/woocommerce-cost-of-goods/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:13:\"Cost of Goods\";s:5:\"image\";s:71:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/cost-of-goods-icon@2x.png\";s:11:\"description\";s:64:\"Easily track profit by including  cost of goods in your reports.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:55:\"woocommerce-cost-of-goods/woocommerce-cost-of-goods.php\";}i:3;O:8:\"stdClass\":6:{s:4:\"href\";s:135:\"https://woocommerce.com/products/woocommerce-google-analytics-pro/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:32:\"WooCommerce Google Analytics Pro\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:85:\"Add advanced event tracking and enhanced eCommerce tracking to your WooCommerce site.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:69:\"woocommerce-google-analytics-pro/woocommerce-google-analytics-pro.php\";}i:4;O:8:\"stdClass\":6:{s:4:\"href\";s:131:\"https://woocommerce.com/products/woocommerce-customer-history/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:28:\"WooCommerce Customer History\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:125:\"Observe how your customers use your store, keep a full purchase history log, and calculate the total customer lifetime value.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:61:\"woocommerce-customer-history/woocommerce-customer-history.php\";}i:5;O:8:\"stdClass\":6:{s:4:\"href\";s:115:\"https://woocommerce.com/products/kiss-metrics/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:11:\"Kissmetrics\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:79:\"Easily add Kissmetrics event tracking to your WooCommerce store with one click.\";s:6:\"button\";s:10:\"From: $149\";s:6:\"plugin\";s:52:\"woocommerce-kiss-metrics/woocommerce-kissmetrics.php\";}i:6;O:8:\"stdClass\":6:{s:4:\"href\";s:111:\"https://woocommerce.com/products/mixpanel/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:8:\"Mixpanel\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:65:\"Add event tracking powered by Mixpanel to your WooCommerce store.\";s:6:\"button\";s:10:\"From: $149\";s:6:\"plugin\";s:45:\"woocommerce-mixpanel/woocommerce-mixpanel.php\";}i:7;O:8:\"stdClass\":6:{s:4:\"href\";s:133:\"https://woocommerce.com/products/woocommerce-sales-report-email/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:30:\"WooCommerce Sales Report Email\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:107:\"Receive emails daily, weekly or monthly with meaningful information about how your products are performing.\";s:6:\"button\";s:9:\"From: $29\";s:6:\"plugin\";s:65:\"woocommerce-sales-report-email/woocommerce-sales-report-email.php\";}}}i:10;O:8:\"stdClass\":2:{s:6:\"module\";s:10:\"column_end\";s:9:\"container\";s:20:\"column_container_end\";}i:11;O:8:\"stdClass\":4:{s:6:\"module\";s:12:\"banner_block\";s:5:\"title\";s:40:\"Promote your products and increase sales\";s:11:\"description\";s:77:\"From coupons to emails, these extensions can power up your marketing efforts.\";s:5:\"items\";a:9:{i:0;O:8:\"stdClass\":6:{s:4:\"href\";s:116:\"https://woocommerce.com/products/smart-coupons/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:13:\"Smart Coupons\";s:5:\"image\";s:71:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/smart-coupons-icon@2x.png\";s:11:\"description\";s:106:\"Enhance your coupon options - create gift certificates, store credit, coupons based on purchases and more.\";s:6:\"button\";s:9:\"From: $99\";s:6:\"plugin\";s:55:\"woocommerce-smart-coupons/woocommerce-smart-coupons.php\";}i:1;O:8:\"stdClass\":6:{s:4:\"href\";s:114:\"https://woocommerce.com/products/automatewoo/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:11:\"AutomateWoo\";s:5:\"image\";s:74:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/follow-up-emails-icon@2x.png\";s:11:\"description\";s:121:\"Powerful marketing automation for WooCommerce. AutomateWoo has the tools you need to grow your store and make more money.\";s:6:\"button\";s:9:\"From: $99\";s:6:\"plugin\";s:27:\"automatewoo/automatewoo.php\";}i:2;O:8:\"stdClass\":6:{s:4:\"href\";s:122:\"https://woocommerce.com/products/google-product-feed/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:19:\"Google Product Feed\";s:5:\"image\";s:77:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/google-product-feed-icon@2x.png\";s:11:\"description\";s:61:\"Let customers find you when shopping for products via Google.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:45:\"woocommerce-product-feeds/woocommerce-gpf.php\";}i:3;O:8:\"stdClass\":6:{s:4:\"href\";s:118:\"https://woocommerce.com/products/dynamic-pricing/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:15:\"Dynamic Pricing\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:48:\"Bulk discounts, role-based pricing and much more\";s:6:\"button\";s:10:\"From: $129\";s:6:\"plugin\";s:59:\"woocommerce-dynamic-pricing/woocommerce-dynamic-pricing.php\";}i:4;O:8:\"stdClass\":6:{s:4:\"href\";s:133:\"https://woocommerce.com/products/woocommerce-points-and-rewards/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:30:\"WooCommerce Points and Rewards\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:102:\"Reward your customers for purchases and other actions with points which can be redeemed for discounts.\";s:6:\"button\";s:10:\"From: $129\";s:6:\"plugin\";s:65:\"woocommerce-points-and-rewards/woocommerce-points-and-rewards.php\";}i:5;O:8:\"stdClass\":6:{s:4:\"href\";s:115:\"https://woocommerce.com/products/store-credit/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:24:\"WooCommerce Store Credit\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:152:\"Generate store credit coupons that enable customers to make multiple purchases until the total value specified is exhausted or the coupons life expires.\";s:6:\"button\";s:9:\"From: $29\";s:6:\"plugin\";s:53:\"woocommerce-store-credit/woocommerce-store-credit.php\";}i:6;O:8:\"stdClass\":6:{s:4:\"href\";s:111:\"https://woocommerce.com/products/facebook/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:24:\"Facebook for WooCommerce\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:89:\"Get the Facebook for WooCommerce plugin for two powerful ways to help grow your business.\";s:6:\"button\";s:4:\"Free\";s:6:\"plugin\";s:53:\"facebook-for-woocommerce/facebook-for-woocommerce.php\";}i:7;O:8:\"stdClass\":6:{s:4:\"href\";s:126:\"https://woocommerce.com/products/newsletter-subscription/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:23:\"Newsletter Subscription\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:127:\"Allow customers to subscribe to your MailChimp or CampaignMonitor mailing list(s) via a widget or by opting in during checkout.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:63:\"woocommerce-subscribe-to-newsletter/subscribe-to-newsletter.php\";}i:8;O:8:\"stdClass\":6:{s:4:\"href\";s:131:\"https://woocommerce.com/products/woocommerce-email-customizer/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:28:\"WooCommerce Email Customizer\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:125:\"Connect with your customers with each email you send by visually modifying your email templates via the WordPress Customizer.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:61:\"woocommerce-email-customizer/woocommerce-email-customizer.php\";}}}}}","no"),
("664","_transient_timeout_wc_term_counts","1625141166","no"),
("665","_transient_wc_term_counts","a:1:{i:15;s:1:\"0\";}","no"),
("677","_transient_timeout_wc_blocks_query_1c7a2836f3eaa33d22200383465d373e","1625141753","no"),
("678","_transient_wc_blocks_query_1c7a2836f3eaa33d22200383465d373e","a:2:{s:7:\"version\";s:10:\"1622543932\";s:5:\"value\";a:0:{}}","no"),
("680","_transient_timeout_feed_71a7765c3d553e44aaa308159b5a2ba6","1622593003","no"),
("681","_transient_feed_71a7765c3d553e44aaa308159b5a2ba6","a:3:{s:3:\"url\";s:22:\"https://wordpress.org/\";s:8:\"feed_url\";s:31:\"http://wordpress.org/news/feed/\";s:5:\"build\";s:14:\"20201016152008\";}","no"),
("682","_transient_timeout_feed_mod_71a7765c3d553e44aaa308159b5a2ba6","1622593003","no"),
("683","_transient_feed_mod_71a7765c3d553e44aaa308159b5a2ba6","1622549803","no"),
("684","_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca","1622593003","no"),
("685","_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"News –  – WordPress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"https://wordpress.org/news\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 26 May 2021 23:36:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=5.8-alpha-51050\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:57:\"
		
		
		
		
		
				
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"WordPress at 18\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/news/2021/05/wordpress-at-18/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 27 May 2021 06:00:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Meta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10380\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:338:\"Today marks the 18th anniversary of WordPress&#8217; launch, a day that I fondly refer to as WordPress&#8217; birthday, which means WordPress is 6,575 days old. To celebrate another turn around the sun, the community has had parties, we have shared data, and we have told our story. Since our last birthday we developed our 40th [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Josepha\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1526:\"
<p>Today marks the 18th anniversary of WordPress&#8217; launch, a day that I fondly refer to as WordPress&#8217; birthday, which means WordPress is 6,575 days old. To celebrate another turn around the sun, the <a href=\"https://wordpress.org/news/2008/05/birthday-party/\">community</a> has had <a href=\"https://wp15.wordpress.net/\">parties</a>, we have <a href=\"https://wordpress.org/news/2010/05/lucky-seven/\">shared data</a>, and we have <a href=\"https://wordpress.org/news/2013/05/ten-good-years/\">told our story</a>.</p>



<p>Since our last birthday we developed our 40th release and now also support over 40% of the web. So it seems fitting that this year&#8217;s celebration should be a list of 40 milestones that have helped us get there.</p>



<figure class=\"wp-block-embed is-type-wp-embed is-provider-wordpress-org wp-block-embed-wordpress-org\"><div class=\"wp-block-embed__wrapper\">
<blockquote class=\"wp-embedded-content\" data-secret=\"jfhsKLBL8n\"><a href=\"https://wordpress.org/40-percent-of-web/\">WordPress and the Journey to 40% of the Web</a></blockquote><iframe class=\"wp-embedded-content\" sandbox=\"allow-scripts\" security=\"restricted\" title=\"&#8220;WordPress and the Journey to 40% of the Web&#8221; &#8212; WordPress.org\" src=\"https://wordpress.org/40-percent-of-web/embed/#?secret=jfhsKLBL8n\" data-secret=\"jfhsKLBL8n\" width=\"600\" height=\"338\" frameborder=\"0\" marginwidth=\"0\" marginheight=\"0\" scrolling=\"no\"></iframe>
</div></figure>



<p>Grab a slice of cake or festive beverage and give it a scroll!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10380\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:68:\"
		
		
		
		
		
				
		
		
		
		

					
										
					
		
		


			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"Coloring Your Images With Duotone Filters\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"https://wordpress.org/news/2021/05/coloring-your-images-with-duotone-filters/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 26 May 2021 12:17:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:4:{i:0;a:5:{s:4:\"data\";s:8:\"Features\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:13:\"Uncategorized\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:9:\"Gutenberg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:3;a:5:{s:4:\"data\";s:9:\"tutorials\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10349\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:336:\"Created by Alex Lende Beginning with WordPress 5.8, you can colorize your image and cover blocks with duotone filters! Duotone can add a pop of color to your designs and style your images to integrate well with your themes. Filters? Like on Instagram? Duotone doesn’t work in quite the same way as Instagram filters. Whereas [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"enclosure\";a:2:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:58:\"https://wordpress.org/news/files/2021/05/duotone_howto.mov\";s:6:\"length\";s:8:\"10231737\";s:4:\"type\";s:15:\"video/quicktime\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:58:\"https://wordpress.org/news/files/2021/05/waves_trimmed.mov\";s:6:\"length\";s:7:\"1165292\";s:4:\"type\";s:15:\"video/quicktime\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Chloe Bringmann\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6911:\"
<p><em>Created by <a href=\"https://profiles.wordpress.org/ajlende/\">Alex Lende</a></em></p>



<p>Beginning with WordPress 5.8, you can colorize your image and cover blocks with duotone filters! Duotone can add a pop of color to your designs and style your images to integrate well with your themes.</p>



<h2>Filters? Like on Instagram?</h2>



<p>Duotone doesn’t work in quite the same way as Instagram filters. Whereas Instagram filters do color adjustments (color levels/curves and sometimes a vignette for the photo editors among us), the new duotone filters entirely replace the colors of your images.</p>



<figure class=\"wp-block-jetpack-image-compare\"><div class=\"juxtapose\" data-mode=\"horizontal\"><img loading=\"lazy\" id=\"10350\" src=\"https://i1.wp.com/wordpress.org/news/files/2021/05/image7.png?resize=632%2C622&#038;ssl=1\" alt=\"\" width=\"632\" height=\"622\" class=\"image-compare__image-before\" data-recalc-dims=\"1\" /><img loading=\"lazy\" id=\"10351\" src=\"https://i0.wp.com/wordpress.org/news/files/2021/05/image4.png?resize=632%2C621&#038;ssl=1\" alt=\"\" width=\"632\" height=\"621\" class=\"image-compare__image-after\" data-recalc-dims=\"1\" /></div><figcaption>Photo by <a href=\"https://www.pexels.com/photo/grey-cat-close-up-photography-2524164/\">Charles Pragnell</a>.<br></figcaption></figure>



<p>You can think of the duotone effect as a black and white filter, but instead of the shadows being black and the highlights being white, you pick your own colors for the shadows and highlights.</p>



<p>For example, a grayscale filter can be created by selecting black and white as shadow/highlight colors, and a sepia filter by choosing brown and tan.</p>



<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"632\" height=\"622\" src=\"https://i2.wp.com/wordpress.org/news/files/2021/05/image6.png?resize=632%2C622&#038;ssl=1\" alt=\"\" class=\"wp-image-10352\" srcset=\"https://i2.wp.com/wordpress.org/news/files/2021/05/image6.png?resize=1024%2C1008&amp;ssl=1 1024w, https://i2.wp.com/wordpress.org/news/files/2021/05/image6.png?resize=300%2C295&amp;ssl=1 300w, https://i2.wp.com/wordpress.org/news/files/2021/05/image6.png?resize=768%2C756&amp;ssl=1 768w, https://i2.wp.com/wordpress.org/news/files/2021/05/image6.png?w=1368&amp;ssl=1 1368w, https://i2.wp.com/wordpress.org/news/files/2021/05/image6.png?w=1264&amp;ssl=1 1264w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure>



<p>Analogous colors can add a subtle effect and work well for cover backgrounds where the overlaid text still needs to stand out.</p>



<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"632\" height=\"622\" src=\"https://i1.wp.com/wordpress.org/news/files/2021/05/image1.png?resize=632%2C622&#038;ssl=1\" alt=\"\" class=\"wp-image-10353\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2021/05/image1.png?resize=1024%2C1008&amp;ssl=1 1024w, https://i1.wp.com/wordpress.org/news/files/2021/05/image1.png?resize=300%2C295&amp;ssl=1 300w, https://i1.wp.com/wordpress.org/news/files/2021/05/image1.png?resize=768%2C756&amp;ssl=1 768w, https://i1.wp.com/wordpress.org/news/files/2021/05/image1.png?w=1368&amp;ssl=1 1368w, https://i1.wp.com/wordpress.org/news/files/2021/05/image1.png?w=1264&amp;ssl=1 1264w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure>



<p>Much more vibrant and interesting effects can be made with complementary colors.</p>



<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"632\" height=\"622\" src=\"https://i2.wp.com/wordpress.org/news/files/2021/05/image2.png?resize=632%2C622&#038;ssl=1\" alt=\"\" class=\"wp-image-10354\" srcset=\"https://i2.wp.com/wordpress.org/news/files/2021/05/image2.png?resize=1024%2C1008&amp;ssl=1 1024w, https://i2.wp.com/wordpress.org/news/files/2021/05/image2.png?resize=300%2C295&amp;ssl=1 300w, https://i2.wp.com/wordpress.org/news/files/2021/05/image2.png?resize=768%2C756&amp;ssl=1 768w, https://i2.wp.com/wordpress.org/news/files/2021/05/image2.png?w=1368&amp;ssl=1 1368w, https://i2.wp.com/wordpress.org/news/files/2021/05/image2.png?w=1264&amp;ssl=1 1264w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure>



<h2>How Do I Add Duotone Filter?</h2>



<p>The duotone effect works best on high-contrast images, so start with an image with a lot of large dark and light areas. From the block toolbar, use the filter button and choose a preset:</p>



<figure class=\"wp-block-video\"><video controls src=\"https://wordpress.org/news/files/2021/05/duotone_howto.mov\"></video></figure>



<p>You can also choose colors from your theme’s palette, or a custom color of your choice.</p>



<p>In addition to the image block, duotone can be applied to both images and video in the cover block.</p>



<div class=\"wp-block-cover has-background-dim has-custom-content-position is-position-center-left\"><video class=\"wp-block-cover__video-background intrinsic-ignore\" autoplay muted loop playsinline src=\"https://wordpress.org/news/files/2021/05/waves_trimmed.mov\" data-object-fit=\"cover\"></video><div class=\"wp-block-cover__inner-container\">
<p class=\"has-text-align-center has-large-font-size\">Duotone</p>
</div></div>



<h2>Will This Overwrite Images in My Media Library?</h2>



<p>Images and videos in your media library will remain unchanged. The duotone effect works using <a href=\"https://www.w3.org/TR/SVG11/filters.html\">SVG filters</a> and the <a href=\"https://www.w3.org/TR/filter-effects-1/\">CSS filter property</a>, so the image or video is never modified in your library. On the one hand, this means that you can apply a filter to an image that you link to that doesn’t exist in your media library. On the other hand, this means that the filter won’t show up in RSS feeds or places that use the image URL directly.</p>



<h2>Can I Add Duotone Colors to Blocks or Themes That I Develop?</h2>



<p>The API for adding duotone colors to blocks is experimental in Gutenberg v10.6. Still, the documentation for using it in your own blocks can be found and will be updated under <a href=\"https://developer.wordpress.org/block-editor/reference-guides/block-api/block-supports/#color\">Supports Color</a> in the Block Editor Handbook. Themes can add duotone presets with theme.json. More information can be found under <a href=\"https://developer.wordpress.org/block-editor/how-to-guides/themes/theme-json/#presets\">Global Settings &amp; Styles Presets</a> in the Block Editor Handbook.</p>



<h2>Try it Out Now Using the Gutenberg plugin</h2>



<p>The duotone feature was released in version 10.6 of the Gutenberg plugin, so you can try it out now prior to the WordPress 5.8 release in July.</p>



<hr class=\"wp-block-separator\" />



<p><em>Thanks to <a href=\"https://profiles.wordpress.org/joen/\">@joen</a> and <em><em><a href=\"https://profiles.wordpress.org/mkaz/\">@mkaz</a></em></em></em> <em>for assistance writing and reviewing this post.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10349\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:58:\"
		
		
		
		
		
				
		

					
										
					
		
		

			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"WP Briefing: Episode 9: The Cartography of WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://wordpress.org/news/2021/05/episode-9-the-cartography-of-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 24 May 2021 11:55:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"wp-briefing\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/news/?post_type=podcast&p=10373\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:159:\"In this episode, Josepha Haden Chomphosy provides a map of how to navigate WordPress teams and communication channels, along with her small list of big things.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"enclosure\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:62:\"https://wordpress.org/news/files/2021/05/WP-Briefining-009.mp3\";s:6:\"length\";s:1:\"0\";s:4:\"type\";s:0:\"\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Chloe Bringmann\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:12611:\"
<p>In this episode, Josepha Haden Chomphosy provides a map of how to navigate WordPress teams and communication channels, along with her small list of big things.</p>



<p><em><strong>Have a question you&#8217;d like answered? You can submit them to <a href=\"mailto:wpbriefing@wordpress.org\">wpbriefing@wordpress.org</a>, either written or as a voice recording.</strong></em></p>



<h2>Credits</h2>



<ul><li>Editor:<a href=\"https://profiles.wordpress.org/dustinhartzler/\"> Dustin Hartzler</a></li><li>Logo:<a href=\"https://profiles.wordpress.org/beafialho/\"> Beatriz Fialho</a></li><li>Production:<a href=\"https://profiles.wordpress.org/mkaz/\"> </a><a href=\"https://profiles.wordpress.org/cbringmann/\">Chloé Bringmann</a></li><li>Song: Fearless First by Kevin MacLeod</li></ul>



<h2>References</h2>



<ul><li><a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://www.meetup.com/pro/wordpress/\">https://www.meetup.com/pro/wordpress/</a></li><li><a rel=\"noreferrer noopener\" href=\"https://make.wordpress.org/\" target=\"_blank\">https://make.wordpress.org/</a></li><li><a rel=\"noreferrer noopener\" href=\"https://make.wordpress.org/chat/\" target=\"_blank\">https://chat.wordpress.org/</a></li><li><a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://make.wordpress.org/\">Make WordPress</a> Slack</li><li><a href=\"https://europe.wordcamp.org/2021/\">WordCamp Europe</a>, June 7-9</li><li><a href=\"https://japan.wordcamp.org/2021/\">WordCamp Japan</a>, June 20-26</li><li>The Sixth<a href=\"https://make.wordpress.org/test/2021/05/12/fse-program-testing-call-6-stick-the-landing-pages/\"> call for testing</a> on Template Editing&nbsp;</li><li>The <a href=\"https://wordpress.org/news/2021/05/dropping-support-for-internet-explorer-11/\">upcoming drop of Internet Explorer 11 support</a></li></ul>



<h2>Transcript</h2>



<span id=\"more-10373\"></span>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>00:10</p>



<p>Hello, everyone, and welcome to the WordPress briefing, the podcast where you can catch quick explanations of some of the ideas behind the WordPress open source project and the community around it, as well as get a small list of big things coming up in the next two weeks. I&#8217;m your host, Joseph Haden Chomphosy. Here we go!</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>00:40</p>



<p>Almost every episode of this podcast, you can hear me invite you to join in the WordPress project, to contribute back, to get involved. And I&#8217;m sure that every time I say that there&#8217;s at least one of you who&#8217;s like “Yes. Challenge accepted!” And you wade in sight unseen, to immerse yourselves in the cheerful cacophony of open source at scale that is WordPress. You see before you all 158 ways you can start contributing and you are exhilarated by this lostness. This you think, is the lostness of infinite possibility. And for you, I&#8217;m really thankful. My work here today would not be possible if it weren&#8217;t for the brave souls who leap into something with hope as their primary plan and tactic. You are heroes, and I thank you very much for your service. For everyone else, I&#8217;m going to give you a quick tour of where WordPress collaborates and a little bit of how they collaborate. We&#8217;ll cover the Make network, the Making WordPress Slack, events for WordPress, and a rundown of the teams.&nbsp;</p>



<p>First, the Make network. The Make network of sites can be found at make.wordpress.org. That page includes information on most of our teams. Teams like Core and Design and Community. All of those teams require some technical skills since we&#8217;re a project built around a piece of software. However, some require a little more than others. You can think of this set of sites as the desk of each team in the WordPress project. It&#8217;s where they update each other, where they host discussions, where they refine proposals, and where they coordinate admin tasks. Contributors can write posts on most sites in the network as long as they follow the guidelines and best practices. And anyone with a wordpress.org profile can join in discussions in the comments. Most work on the Make network is asynchronous, and discussions stay open for a long enough time to allow anyone in the world to weigh in when they have the time. It&#8217;s how we try to remember that we are a globally-minded project.&nbsp;</p>



<p>The second area is the Making WordPress Slack instance. The Making WordPress Slack instance can be found at wordpress.slack.com, and it requires an account that is associated with your wordpress.org profile. Each team in the project has a channel, although not all channels in that Slack instance, represent a standalone team. You can think of this Slack instance as a set of conference rooms. It&#8217;s where contributors connect, gain a more nuanced understanding of problems that we&#8217;re trying to solve. They host synchronous meetings and also coordinate working groups.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>03:31</p>



<p>Contributors can post in most channels, although there are a few that are restricted. We don&#8217;t have any social channels in this Slack instance, but most WordPress-ers do tend to find friends that they connect with. The work done here is synchronous, and most meetings last about an hour. There are about 35+ meetings a week, so you can basically always find someone around.&nbsp;</p>



<p>The last area we work is actually at WordPress events. Word Camps and WordPress meetups happen all over the world. Unless there&#8217;s a global pandemic, then they&#8217;re kind of all over the computer and at all times of day and night. You can keep track of those on wordcamp.org or on WordPress’s meetup page, which I&#8217;ve linked in the notes below. These events bring together all sorts of facets of the WordPress project. And they are an event where local WordPress communities aim to connect, inspire and educate each other. There&#8217;s always someone at these events, who knows a little bit more about WordPress than you do. If you&#8217;re headed to want to learn more about contribution, look out for any that have a contributor day or are hosting a contribution drive. These are clearly synchronous events. And when we do get back to doing them in person, they&#8217;re also tied to physical locations. When we get back to them, I encourage you to find one that&#8217;s close to you. They are incredibly valuable.&nbsp;</p>



<p>Okay, so that&#8217;s the map of the area. Those are the three big places where we get this stuff done. Let&#8217;s do a quick map of the teams themselves. If you&#8217;re a developer and you&#8217;re looking to work inside the technology space, work with code a bit, then your best chances for teams are Core and all of its related components. They&#8217;re like 50 components, including core editor and various other things. There&#8217;s also the Mobile team WP CLI, the Tide team, Security, our brand new team, Openverse, and Meta. Those all take a fairly high amount of code knowledge to contribute there.&nbsp;</p>



<p>If you&#8217;re more into design and product work, then we have a few teams for that as well. There&#8217;s of course, the Design team, but we also have Accessibility, Test, Triage, Polyglots kind of falls in there for me. But if you are a programs person, and we&#8217;re talking like programs, getting people together programs, not programs, as in programming or code. So if you&#8217;re a programs person, you&#8217;re looking more at the Community team, at the Themes team, the Plugin team, Polyglots, again, Training support, probably a number of others that have like program components in it as well.</p>



<p>If you are really interested in learning more about contributor experience, which is how we build tools, and again, programs for all of the contributors who are showing up, then the teams for you will be teams like Meta and Documentation, Hosting, the Community team, the Training team, arguably any team that has a program as part of it is considered contributor experience because that&#8217;s how we help our contributors know what to do, what not to do, how to help them get onboarded, find their way, stuff like that.&nbsp;</p>



<p>And if you&#8217;re more in the communications area of things, we have quite a few teams there as well. We do have Marketing, of course, but also I think that Support ends up in our communications area, WordPress TV, obviously ends up in communications. But I think Training, Meta, Documentation, and arguably, maybe also Testing ends up in that space as well.&nbsp;</p>



<p>I realize that there are a handful of teams that I mentioned multiple times, especially Polyglots, Support, Test, Triage, Meta, Community. The reason they end up in a number of different places is that all of those teams also have a fair amount of admin and infrastructure stuff that goes into the WordPress project and community as a whole. So it touches a lot of other teams, and so they get a lot of mentions. All right. So WordPress adventurers, you now have a beginner&#8217;s map. I hope it helps, and I hope we see you around the community.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>07:54</p>



<p>If you&#8217;re still with me, that brings us today to my small list of big things. I&#8217;ve got four things for you, and I&#8217;m excited about all of them. The first two are events actually. WordCamp Europe is coming up from June seventh through the ninth. It will include a presentation from the WordPress project co-founder, Matt Mullenweg, so I encourage you to hop over, grab a ticket to check out the rest of the sessions that are happening while you&#8217;re there. The next one is WordCamp, Japan, which is happening June 20th through the 26th. And you heard that right that is seven whole days of WordCamp. It&#8217;s a little bit of a different format than we normally take, but it&#8217;s five days actually of contribution on ten specific projects. Then that&#8217;s bookended on either side of those contribution days, with full days of sessions. There&#8217;s some in English, but it&#8217;s primarily in Japanese. But either way, I think it&#8217;s going to be a really excellent event, and I encourage everyone to check it out.&nbsp;</p>



<p>The rest of my list is not events. We have opened our sixth call for testing, it&#8217;s specifically looking at the template editing mode for Full Site Editing. It is an iteration on one of our earliest tests for the Full Site Editing outreach program. And so it has incorporated a lot of the feedback that we got in that test the first time around. So if you look at that test, which by the way, are all guided, if you&#8217;ve never tested anything before, don&#8217;t let this scare you. It&#8217;s really well written, it&#8217;s got a good guide on it and, and also allows for a little bit of exploration. But if you participated in the landing page test that we did early on, this is the follow-up to that. It incorporates a lot of the feedback that we got, so this is closing that feedback loop and I encourage you to stop by and participate in that test. It will be linked in the show notes and also I tweet about it a bit so you can run over there and find it also.</p>



<p>&nbsp;WordPress is dropping support for Internet Explorer 11. That&#8217;s happening over the summer, so around the middle of July is when that&#8217;s going to happen. If you&#8217;ve been using WordPress for a while you&#8217;ve been getting notifications. If you happen to get to WordPress with IE11, letting you know that that this particular browser is reaching the end of its life for support in general on the web, but now WordPress also is making the choice to drop support for that. And so there&#8217;s a post out on wordpress.org/news, which I will also link to in the show notes in case you have not heard about this yet. It shouldn&#8217;t have any immediate and noticeable effects on anyone who&#8217;s visiting a site that&#8217;s built using WordPress. There might be a few things in the dashboard that don&#8217;t work if you are administering a WordPress site from IE11. So there&#8217;s a lot of good information in that post. Give it a read and if you have questions, always feel free to stop by the Core chat and ask those as we go.&nbsp;</p>



<p>And that my friends is your smallest of big things. Thank you for tuning in today for the WordPress Briefing. I&#8217;m your host, Josepha Haden Chomphosy, and I&#8217;ll see you again in a couple of weeks!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10373\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:57:\"
		
		
		
		
		
				
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"Dropping support for Internet Explorer 11\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"https://wordpress.org/news/2021/05/dropping-support-for-internet-explorer-11/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 19 May 2021 12:00:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"General\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10369\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:337:\"Internet Explorer 11 (IE11) was released over 7 years ago and is currently used by less than 1% of all users on the Internet with usage rapidly declining. A large majority of popular websites have already stopped supporting IE11 (including Microsoft Teams in 2020), and even the Microsoft 365 apps and services will be dropping [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Jonathan Desrosiers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3645:\"
<p>Internet Explorer 11 (IE11) was released over 7 years ago and is currently used by less than <a href=\"https://gs.statcounter.com/browser-version-partially-combined-market-share#monthly-202104-202105-bar\" rel=\"nofollow\">1% of all users on the Internet</a> with usage rapidly declining. A large majority of popular websites have already stopped supporting IE11 (including <a href=\"https://docs.microsoft.com/en-us/lifecycle/announcements/m365-ie11-microsoft-edge-legacy\" rel=\"nofollow\">Microsoft Teams in 2020</a>), and even the Microsoft 365 apps and services will be <a href=\"https://docs.microsoft.com/en-us/lifecycle/announcements/m365-ie11-microsoft-edge-legacy\" rel=\"nofollow\">dropping support later this year</a>.</p>



<p><strong>When WordPress 5.8 is released in July of this year, Internet Explorer 11 will no longer be supported.</strong></p>



<p>If you are currently using IE11, it is strongly recommended that you switch to a more modern browser, such as Google Chrome, Mozilla Firefox, Safari, or Microsoft Edge. IE11 users have been shown a warning that IE11 is considered outdated in the WordPress dashboard for the last 17+ months.</p>



<p>If you are already using one of the more modern browsers above, you will only be positively impacted by this change, as there are performance benefits to dropping IE11 support. However, if any other users of your site are still using IE11, it’s possible they will be affected.</p>



<h2>What does “dropping support” mean?</h2>



<p>When support for a browser is removed from WordPress, new features are no longer tested on those browsers and are not guaranteed to function optimally.</p>



<p>Automated tools that generate parts of the WordPress Core source code are also updated to exclude unsupported browsers. This means that any feature relying on these generated files will likely have bugs or stop working for users of those browsers.</p>



<p>The block editor will be the area of WordPress most heavily impacted by this change because almost all of the files related to the block editor are compiled using these automated tools. Other areas of the WordPress dashboard also use CSS built with these tools and their appearance will potentially be impacted when using IE11.</p>



<p>All other areas of the code base that are IE11 specific will need to be identified, evaluated, and removed on a case-by-case basis as the rest are manually maintained. This process will begin in the WordPress 5.9 release, and will likely happen gradually over several major releases. Additionally, any bugs which are reported for IE11 will not be fixed.</p>



<h2>How will this affect themes?</h2>



<p>No changes will be made to any of the default bundled themes as a result of this plan. No code related to IE11 support (or any other browser that may have been supported when each theme was released) will be removed from default themes. However, any new features added going forward will not be tested in IE11.</p>



<p>If you are not using a default theme, it’s still unlikely that your theme will be affected by this change. Themes typically have their own browser support policies, and changes in WordPress Core do not affect those. It’s possible that your theme author may have removed support for IE11 already.</p>



<p>If IE11 support is important to you and you are unsure whether your theme supports IE11, it is recommended that you reach out to your theme’s developer to confirm.</p>



<p>More information on this change can be found on the <a href=\"https://make.wordpress.org/core/2021/04/22/ie-11-support-phase-out-plan/\">Making WordPress Core blog</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10369\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"WordPress 5.7.2 Security Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wordpress.org/news/2021/05/wordpress-5-7-2-security-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 13 May 2021 01:04:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10334\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:356:\"WordPress 5.7.2 is now available. This security release features one security fix. Because this is a security release, it is recommended that you update your sites immediately. All versions since WordPress 3.7 have also been updated. WordPress 5.7.2 is a short-cycle security release. The next major release will be version 5.8. You can update to [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Peter Wilson\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2091:\"
<p>WordPress 5.7.2 is now available.</p>



<p>This security release features one security fix. Because this is a security release, it is recommended that you update your sites immediately. All versions since WordPress 3.7 have also been updated.</p>



<p>WordPress 5.7.2 is a short-cycle security release. The next major release will be version 5.8.</p>



<p>You can update to WordPress 5.7.2 by downloading from WordPress.org, or visit your Dashboard → Updates and click Update Now.</p>



<p>If you have sites that support automatic background updates, they’ve already started the update process.</p>



<h3>Security Updates</h3>



<p>One security issue affecting WordPress versions between 3.7 and 5.7. If you haven’t yet updated to 5.7, all WordPress versions since 3.7 have also been updated to fix the following security issue:</p>



<ul><li>Object injection in PHPMailer, <a href=\"https://nvd.nist.gov/vuln/detail/CVE-2020-36326\">CVE-2020-36326</a> and <a href=\"https://nvd.nist.gov/vuln/detail/CVE-2018-19296\">CVE-2018-19296</a>.</li></ul>



<p>Thank you to the members of the WordPress security team for implementing these fixes in WordPress.</p>



<p>For more information refer to <a href=\"https://wordpress.org/support/wordpress-version/version-5-7-2/\">the version 5.7.2 HelpHub documentation</a> page.</p>



<h3>Thanks and props!</h3>



<p>The 5.7.2 release was led by <a href=\"https://profiles.wordpress.org/peterwilsoncc/\">@peterwilsoncc</a> and <a href=\"https://profiles.wordpress.org/audrasjb/\">@audrasjb</a>.</p>



<p>Thank you to everyone who helped make WordPress 5.7.2 happen: <a href=\"https://profiles.wordpress.org/audrasjb\">@audrasjb</a>, <a href=\"https://profiles.wordpress.org/ayeshrajans\">@ayeshrajans</a>, <a href=\"https://profiles.wordpress.org/desrosj\">@desrosj</a>, <a href=\"https://profiles.wordpress.org/dd32\">@dd32</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc\">@peterwilsoncc</a>, <a href=\"https://profiles.wordpress.org/SergeyBiryukov\">@SergeyBiryukov</a>, and <a href=\"https://profiles.wordpress.org/xknown\">@xknown</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10334\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:63:\"
		
		
		
		
		
				
		
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Welcome to Openverse\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2021/05/welcome-to-openverse/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 11 May 2021 12:42:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:9:\"Community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Features\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:7:\"General\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10325\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:369:\"Following the recent statement by WordPress&#8217;s co-founder Matt Mullenweg and the Creative Commons CEO, Catherine Stihler’s post, I&#8217;m happy to formally announce that CC Search (with the new name Openverse) is now part of the WordPress open source project. Both Matt and I are long-time supporters of Creative Commons. I hope that this will provide [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Josepha\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2211:\"
<p>Following the <a href=\"https://ma.tt/2021/04/cc-search-to-join-wordpress-org/\">recent statement by WordPress&#8217;s co-founder Matt Mullenweg</a> and the <a href=\"https://creativecommons.org/2021/05/03/cc-search-to-join-wordpress/\">Creative Commons CEO, Catherine Stihler’s post</a>, I&#8217;m happy to formally announce that CC Search (with the new name Openverse) is now part of the WordPress open source project. Both Matt and I are long-time supporters of Creative Commons. I hope that this will provide a long-term, sustainable challenger to closed source photo libraries and further enhance the WordPress ecosystem.</p>



<h3><strong>How Does This Affect Current Users?</strong></h3>



<p>Current CC Search users will continue searching and using openly licensed images from around the internet. WordPress plans to continue the great work started by the Creative Commons project and expand search capabilities and features.</p>



<h3><strong>What’s Next?</strong></h3>



<p>We look forward to indexing and searching additional media, such as audio and video. As we expand our capabilities and grow the project, we look forward to integrating directly into WordPress and the media library. We hope to not only allow search and embeds of openly licensed media but pay it forward by additionally licensing and sharing your media back.</p>



<h3><strong>How Can You Contribute?&nbsp;</strong></h3>



<p>Stop by the Slack channel, <a href=\"https://wordpress.slack.com/archives/C02012JB00N\">#openverse</a>, and take a look at the code repositories moved under the WordPress organization <a href=\"https://github.com/wordpress/?q=openverse\">here on GitHub</a>. You can also follow along with the project on its own make page at: <a href=\"https://make.wordpress.org/openverse\">https://make.wordpress.org/openverse</a>. We are working on setting up the new team, process, and procedures.<br></p>



<p>Join us in welcoming the team and community. As a treat, check out the most recent WP Briefing episode, <a href=\"https://wordpress.org/news/2021/05/the-commons-of-images/\">The Commons of Images</a>, in which Matt and I discuss CC Search and our hopes for it as part of the WordPress community.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10325\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"People of WordPress: Fike Komala\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2021/05/people-of-wordpress-fike-komala/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 10 May 2021 22:50:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:9:\"heropress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:16:\"ContributorStory\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10270\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:158:\"Discover Fike Komala‘s story of using #WordPress to enjoy a remote working career across the globe in this month’s People of WordPress feature. #Indonesia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"webcommsat AbhaNonStopNewsUK\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:11106:\"
<p><em>WordPress is open source software, maintained by a global network of contributors. There are many examples of how WordPress has changed people’s lives for the better. In this monthly series, we share some of the amazing stories that are not as well known.</em><br><br>Creating content with WordPress and blogging helped Fike Komala, from Indonesia, build a career where she can work remotely from different locations in the world. <br></p>



<p>In 2020, Fike joined a US-based company that specializes in form building to work as a content marketer. Using her experience as a freelancer and later a full time employee, she encourages others, particularly women in Asia, to consider remote work as a career option. She is so impressed by remote working benefits, that she is now considering writing about it for a thesis for her Master&#8217;s Degree, which she started this year in Europe.<br></p>



<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"632\" height=\"387\" src=\"https://i0.wp.com/wordpress.org/news/files/2021/05/B5939AF2-DFFD-4471-B3F1-7738F82CEF8A.png?resize=632%2C387&#038;ssl=1\" alt=\"Fike pictured with a snow background\" class=\"wp-image-10291\" srcset=\"https://i0.wp.com/wordpress.org/news/files/2021/05/B5939AF2-DFFD-4471-B3F1-7738F82CEF8A.png?w=1024&amp;ssl=1 1024w, https://i0.wp.com/wordpress.org/news/files/2021/05/B5939AF2-DFFD-4471-B3F1-7738F82CEF8A.png?resize=300%2C184&amp;ssl=1 300w, https://i0.wp.com/wordpress.org/news/files/2021/05/B5939AF2-DFFD-4471-B3F1-7738F82CEF8A.png?resize=768%2C470&amp;ssl=1 768w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure>



<p>As a keen blogger, WordPress immediately impressed Fike. Her dad is a programmer, and he helped her create the first of many blogs starting when she was 10 years old. She had private and public blogs, and even an English language one to help her practice and improve her skills. </p>



<figure class=\"wp-block-pullquote\"><blockquote><p><strong>“I got satisfaction and happiness from pouring my thoughts in writing and publishing them in my blog. Writing my thoughts and feelings often helped me process them, and does even now.”</strong></p><cite>Fike Komala</cite></blockquote></figure>



<p>With a natural talent and love for languages, Fike pursued an Information Systems degree after graduating from high school. Her course covered business learning Java, HTML, CSS, Javascript, and Android programming. She also took courses to learn Bootstrap and Ruby on Rails.&nbsp;</p>



<h2>Earning Through Building With WordPress</h2>



<p>Fike’s parents had a business building websites. She was drawn to this work and would help proofread and format the articles. This is how she first encountered WordPress, which was to play a pivotal role in her future career. <br></p>



<blockquote class=\"wp-block-quote\"><p>“I saw WordPress as something more advanced than other platforms, with more themes and plugins to choose from. The default WordPress websites already looked more professional than others.”</p><cite>Fike Komala</cite></blockquote>



<p>Throughout school, Fike’s experience with WordPress and blogging helped her earn extra money safely online, including translating texts from English to Indonesia, online surveys, and writing articles in English.</p>



<h2>Discovering Work You Enjoy&nbsp;</h2>



<p>The last year at University required a year-long full-time internship. Fike worked as an intern at a big general insurance company within the IT quality control staff. She enjoyed working with the people she met and learned a lot through this opportunity, but she declined the offer of a full-time position.&nbsp;</p>



<p>Fike is a good student who loves learning and did well in her education. Through her traditional internship experience,  she found that programming in an office job did not fulfill her. It strengthened her belief in a finding a career where she could have the freedom and creativity of working remotely.</p>



<p>“I was a good student, I love learning algorithms, but I didn’t love programming. I’m not that person who can stay calm finding errors in their codes, and then finding out that it’s only missing a character,” said Fike. She added: “I don’t really like the fact that I have to wake up at 6 AM and be back home at 7 PM, and do it all over again the next day.”</p>



<h2>Adventure Into Remote Work&nbsp;</h2>



<p>Fike spent time improving her freelance profile, revising it, and applying to jobs as a virtual assistant. She was willing to do any small website jobs such as formatting WordPress posts, designing social media posts, and processing orders for online shops. Through a freelance job submission site, she was able to work with people from across the globe, including Singapore, Australia, Europe, and America. Through the site, Fike was able to gain experience with remote working tools like Slack, Asana, Trello, and Google Suites, and the work gave her practice writing in English.&nbsp;</p>



<p>It was through this site that Fike saw a job opportunity with a WordPress plugin company. She sent in her profile and blog.&nbsp;</p>



<p>“This was my first time being interviewed via a video call. I was ecstatic but panicked. On the day, I woke up at 4 AM, got dressed, and opened my laptop. Weirdly, my wi-fi died that morning. So I went to the nearest cafe to get the interview done, and it went great!”</p>



<p>She was hired to deliver consistency on the company’s blog.&nbsp;</p>



<p>Through her job, Fike first began to contribute within the WordPress community and was able to attend her first WordCamp, WordCamp Jakarta 2018, sponsored by her firm. Through WordPress, Fike has met many generous, trusting, and helpful people. </p>



<p>She said: “Because I’ve experienced the generosity of the WordPress people, I wanted to give back to the community.”</p>



<figure class=\"wp-block-image\"><img src=\"https://lh5.googleusercontent.com/ZDAmqCcebOQII99V2RMYmJikoQ3u-tjy6BcCT39QWsOUrAqq2_HeqJ1735UoxVyQHTO_S_V9lzZEJ7WayLb8kY3or78oqG4Xt5ujbNUpt7Vcz7r20lp9XopkPwh85imnvRxjpWTx\" alt=\"WordCamp swag\" /><figcaption>Swag from WordCamp Jakarta 2018, that’s Wapuu ondel-ondel!</figcaption></figure>



<figure class=\"wp-block-pullquote\"><blockquote><p><strong>“I got to know the amazing community behind WordPress. How people voluntarily contribute their time, energy, and skills to the community, from development, marketing to translating.</strong> <strong>It was really inspiring.”</strong></p><cite>Fike Komala</cite></blockquote></figure>



<h2>You Can Inspire Others Through Contributing</h2>



<p>Fike has been an inspiration to people in her local community and globally within the WordPress community through her enthusiasm and energy.&nbsp;</p>



<p>She <a href=\"https://www.youtube.com/watch?v=KHSAV_NJtTA\">talks about her joy in contributing</a> during a live interview as part of WordPress Translation Day in 2020.&nbsp;</p>



<p>So determined to encourage others to become translators of WordPress, she joined the Global Translation Day event with the Indonesian Community last year and took part in wider marketing of the event. She is pictured below with some of the Indonesian polyglots team.</p>



<p>She continues to support the polyglots and is a General Translation Editor for the Indonesian language. Last year, she also voiced an <a href=\"https://youtu.be/Ifqabp-36_c\">Indonesian translation of the onboarding video</a> for new contributors joining WordPress.org. She has been a regular contributor to the PerempuanWP, an initiative for Indonesian women working in the WordPress world. Working with a firm which uses the WordPress platform has strengthened her familiarity with projects in the community and encourages her interest in contributing.</p>



<figure class=\"wp-block-image\"><img src=\"https://lh4.googleusercontent.com/H-8VelQbbEb9f5MM-SUXNudVD9U1DNs546yt_cWGRU--GSLm-PCUunnHDNFmquv9w3rWOUadxkbYr9bYsRU1Ecmhb6Ee_Deg_paNEIyyqs91_3DjgtlmfgCA_P45GNA5nf5rmpCe\" alt=\"Indonesian translation team \" /></figure>



<p>To learn more about contributing to WordPress, visit <a href=\"https://make.wordpress.org/\">make.wordpress.org/</a> and follow the “get involved” link. You can join any of the weekly team meetings to get started, and there is a lot of help available.&nbsp;</p>



<p>Fike says, “I want to represent Asian women. In the future, I hope I can inspire more women, especially Asians, to work remotely.” She is now studying in Europe for a Master&#8217;s in Digital Communication Leadership. She hopes to use her learning to help other women, particularly back in her home country of Indonesia.</p>



<p>She continues to share her energy for learning and remote working. </p>



<p>“<strong>Just learn things. As much as you can. From anywhere, about anything. Keep an open mind. Read books, listen to podcasts, and learn new skills.”</strong></p>



<p><strong>She added: “If you’re working in the WordPress world, join the WordPress community. It’s a great place to learn from and connect with great people.”</strong></p>



<h2>Contributors</h2>



<p>Thanks to Abha Thakor (<a href=\"https://profiles.wordpress.org/webcommsat/\">@webcommsat</a>) and Meg Phillips (<a href=\'https://profiles.wordpress.org/megphillips91/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>megphillips91</a>) for writing this feature, to Surendra Thakor (<a href=\'https://profiles.wordpress.org/sthakor/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>sthakor</a>), Meher Bala (<a href=\'https://profiles.wordpress.org/meher/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>meher</a>), Larissa Murillo (<a href=\'https://profiles.wordpress.org/lmurillom/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>lmurillom</a>), Josepha Haden (<a href=\"https://profiles.wordpress.org/chanthaboune/\">@chanthaboune</a>), Chloé Bringmann (<a href=\'https://profiles.wordpress.org/cbringmann/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>cbringmann</a>) for additional support and graphics, and to Topher DeRosia (<a href=\"https://profiles.wordpress.org/topher1kenobe/\">@topher1kenobe</a>) who created HeroPress. Thank you to Fike Komala (<a href=\'https://profiles.wordpress.org/fikekomala/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>fikekomala</a>) for sharing her #ContributorStory.</p>



<figure class=\"wp-block-image\"><img src=\"https://lh4.googleusercontent.com/FEZ2FQJ0vQ311YoPfh6ny15NXh8saTLH_RjyDO4pUOuEGBTa-Czk63PGoWL04FawKviRfNx0QXePx-goK04X12ry1BR_WXh-kVPIfsEeItPAX6reN5fHS96q6-8dUI506ZO38Z0G\" alt=\"HeroPress logo\" /></figure>



<p><em>This post is based on an article originally published on HeroPress.com. It highlights people in the WordPress community who have overcome barriers and whose stories would otherwise go unheard.</em></p>



<p><em>Meet more WordPress community members in our <a href=\"https://wordpress.org/news/category/heropress/\">People of WordPress series</a>.</em></p>



<p><em>#ContributorStory #HeroPress #WPTranslationDay</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10270\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:58:\"
		
		
		
		
		
				
		

					
										
					
		
		

			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"WP Briefing: The Commons of Images\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://wordpress.org/news/2021/05/the-commons-of-images/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 10 May 2021 12:00:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"wp-briefing\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/news/?post_type=podcast&p=10266\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:238:\"In this episode, Josepha is joined by the co-founder and project lead of WordPress, Matt Mullenweg. Tune in to hear Matt and Josepha discuss the relaunch of CC Search (Openverse) in WordPress and the facets of the open source ecosystem. \";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"enclosure\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:60:\"https://wordpress.org/news/files/2021/05/WP-Briefing-008.mp3\";s:6:\"length\";s:1:\"0\";s:4:\"type\";s:0:\"\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Chloe Bringmann\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:24991:\"
<p>In this episode, Josepha is joined by the co-founder and project lead of WordPress, Matt Mullenweg. Tune in to hear Matt and Josepha discuss the relaunch of CC Search (Openverse) in WordPress and the facets of the open source ecosystem.&nbsp;</p>



<p><em><strong>Have a question you&#8217;d like answered? You can submit them to <a href=\"mailto:wpbriefing@wordpress.org\">wpbriefing@wordpress.org</a>, either written or as a voice recording.</strong></em></p>



<h2>Credits</h2>



<ul><li>Editor:<a href=\"https://profiles.wordpress.org/dustinhartzler/\"> Dustin Hartzler</a></li><li>Logo:<a href=\"https://profiles.wordpress.org/beafialho/\"> Beatriz Fialho</a></li><li>Production:<a href=\"https://profiles.wordpress.org/mkaz/\"> </a><a href=\"https://profiles.wordpress.org/cbringmann/\">Chloé Bringmann</a></li><li>Song: Fearless First by Kevin MacLeod</li></ul>



<h2>References</h2>



<p><strong>Openverse Repositories </strong></p>



<ul><li>Catalog:&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://github.com/wordpress/openverse-catalog\">https://github.com/wordpress/openverse-catalog</a></li><li>API:&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://github.com/wordpress/openverse-api\">https://github.com/wordpress/openverse-api</a></li><li>Frontend:&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://github.com/wordpress/openverse-frontend\">https://github.com/wordpress/openverse-frontend</a></li></ul>



<p><strong>Tech Stack Outline</strong></p>



<ul><li><strong>Frontend</strong>&#8211; Languages: <ul><li>JavaScript, CSS/SCSS</li><li>Libraries/Services: Vue.js, Nuxt.js#&nbsp;</li></ul></li><li><strong>API</strong>&#8211; Languages: <ul><li>Python, PostgreSQL</li><li>Libraries/Services: Django, Elasticsearch, Redis</li></ul></li><li><strong>Catalogue</strong>&#8211; Languages: <ul><li>Python, PostgreSQL</li><li>Libraries/Services: Apache Airflow, PySpark</li></ul></li></ul>



<p>Join the WordPress Slack instance, #openverse</p>



<h2>Transcript</h2>



<span id=\"more-10266\"></span>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>00:10</p>



<p>Hello, everyone, and welcome to the WordPress Briefing. This is usually the podcast where you can catch quick explanations of some of the ideas is behind the WordPress open source project. Today, I have a little bit of a different topic. It&#8217;s still WordPress, it&#8217;s still open source, but it&#8217;s kind of peering into some stuff for the future as opposed to looking at where we are today or how we got to where we are today.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>00:36</p>



<p>You might have recently seen an announcement from Matt that CC Search is joining the WordPress project. This is a really exciting thing for open source, for sure, and definitely, from my perspective, for WordPress. And so I invited Matt to join me today to take a look at what he had in mind with bringing that particular project into our project and what we have in mind for the future. And so, today, this is the WordPress Briefing with Matt and Josepha. And I hope you enjoy the conversation we had. Here we go!</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>01:22</p>



<p>So, we recently announced for WordPress that we essentially acquired CC Search, a project that&#8217;s been part of Creative Commons. And they recently chose a different kind of roadmap for the work they&#8217;re doing in the future. And so it seemed like a really great opportunity to bring this tool and this, I don&#8217;t know, this kind of experience for our users into the WordPress project. So Matt, what are your thoughts about how, like this commitment to images with CC licenses, with Creative Commons licenses, can impact WordPress and how we work in the open web.</p>



<p><strong>Matt Mullenweg&nbsp; </strong>02:09</p>



<p>I think it&#8217;s pretty exciting because Creative Commons exists to do for media, you know, images, audio, etc., what open source has done for code. And so for people who choose to want to donate their creative work under these licenses, much like anyone who contributes a plugin, or code or documentation or translations for WordPress, now people for whom their method of expression is, let&#8217;s say, photography, can put that into the comments like literally, I like why it&#8217;s called the Creative Commons, it&#8217;s such a good name. It can be accessed within everyone&#8217;s dashboard for WordPress. And those images can start to really be part of the fabric of the web the same way that code that runs WordPress or its plugins is part of the fabric of the web.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>02:57</p>



<p>For anyone who&#8217;s listening who&#8217;s not actually already familiar with this concept of the tragedy of the commons, do you want to give us the elevator pitch of what that means and why it&#8217;s so important for WordPress to try to counterbalance that in our work?</p>



<p><strong>Matt Mullenweg&nbsp; </strong>03:12</p>



<p>Sure, the tragedy of the commons, you know, I think the canonical example is as a shared field in a town, and it doesn&#8217;t belong to anyone, so anyone can use it. And when too many farmers took their sheep there, they would overeat the grass, and then there was no more grass left because it was being overutilized, and there was no one owning the field to say, Hey, we need to practice a more sustainable amount of sheep. grass in</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>03:39</p>



<p>Put more grass in there.</p>



<p><strong>Matt Mullenweg&nbsp; </strong>03:41</p>



<p>So basically, the idea is like a shared resource that gets overused and then disappears. With software, we have the opportunity to have the opposite, which is a wealth of comments where every person using the thing actually has the opportunity to make it a little bit better. And that is really beauty of like Wikipedia, open source where every person using it might contribute a small fix, or a translation or a bug report or tell a friend about it, or basically be part of making this thing better, which you know, WordPress is history is very much an example of, and then as it gets better, more people want to use it. And the beautiful thing about software is you can have economics of abundance versus the economics of scarcity. There&#8217;s not one field used, but every additional incremental user of WordPress makes this community stronger and creates a larger market for the products inside it. So those types of dynamics can have the opposite of the tragedy of the commons.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>04:39</p>



<p>Absolutely. I love this idea that you brought it up in your question, not your question, in your answer right at the top. I love this idea of acknowledging that code isn&#8217;t the only fabric available in open source and certainly not the only fabric of the internet as we know it. This idea of like, let&#8217;s bring Creative Commons licensed images into a more long-term space for WordPress. Do you think that that at some point can apply to videos and other sorts of audio files?</p>



<p><strong>Matt Mullenweg&nbsp; </strong>05:21</p>



<p>Absolutely. There already is a ton of Creative Commons licensed content out there that people can use. But there&#8217;s a discoverability problem, you know? Each individual image or audio file or video is, is a little bit of an island. So that&#8217;s why it&#8217;s so important that there&#8217;s the equivalent of a search engine that allows people to discover all the great stuff that&#8217;s out there. And what happens today is there&#8217;s stock photography sites, some of which used to be Creative Commons-based, but many have moved away from that. So they essentially relicense their user contributions. Or people, if we&#8217;re being real, people just go to Google images, and they might utilize images that they don&#8217;t actually have rights to. It&#8217;s not the end of the world, but it&#8217;s not ideal. And so we can create this really compelling directory experience of imagery, which people have chosen to share and want to be used. I think that&#8217;s a much better outcome than the equivalent of piracy.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>06:21</p>



<p>Yeah, yeah, absolutely. So I leapt right into this and didn&#8217;t really give any context to what CC Search is or anything, but for anyone who is not familiar with this tool already, CC Search is, as Matt mentioned, a search engine that currently is focused specifically on images that use open licenses. The Creative Commons licenses are like the content-specific version of GPL for code, which is a really big deal, I think. If wishes were fishes, Matt, and you had your total hope ahead of you, what is your hope for the relaunch of this product and this tool in WordPress?</p>



<p><strong>Matt Mullenweg&nbsp; </strong>07:15</p>



<p>Well, first and foremost, I think we can improve the experience of designing and contributing themes and then modifying them with this really fantastic image directory if we&#8217;re able to build it in the media library. And lots of plugins like Jetpack do some version of this. I think that Jetpack uses Pexels or one of the proprietary, but open libraries. And so we can make it fully, like you said, the equivalent of GPL and open source, all the better. I think longer-term, I&#8217;d love to have a way for people who are adding media to the WordPress site to set it to be available under a Creative Commons license. So just to make it easy and built-in for people to create more Creative Commons license imagery. And then, you know, with the integration of Gutenberg and other things, we can make it easy for other people to use it and credit back the original author if they choose to. And what we find is that even though with CC0, which is essentially a kind of like putting something into the public domain, credit is not required. If you make it the default to link back to the original photographer, author, most people believe that because they like creating things that they use. So you get the best of both worlds; you have the freedom of use for any purpose, including not requiring the credit. But then, just by having it by default, when you insert one of these images, a lot of people are going to leave that and link back to the original author, which I think is also really cool. Like you&#8217;re not required to have a credit link on WordPress, but most people leave the Powered BY WordPress on there.&nbsp;</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>08:45</p>



<p>One of the interesting areas, you mentioned Pexels in this case. One of those interesting areas that we, as a project, can really explore here is how to make it so that the metadata gives you confidence in the origin of the image. Like I don&#8217;t believe that there are any set standards for that. I&#8217;ve just started my research, obviously, because they&#8217;re brand new to us, but I just don&#8217;t think there are any standards available there. And, I think that there is an opportunity for WordPress as a true supporter of the open web to help change the fact that we don&#8217;t have that’s one of the main competitive disadvantages that open source libraries have been trying to combat and especially with Unsplash, who eventually did get purchased by Getty Images. Still, I feel like part of what must have driven that decision to change the licensing terms had to be that they are up against that behemoth of Getty Images where people know where the things came from. They know where the images came from, and they can trust that lineage and model releases and all that stuff. I&#8217;m just really interested to see how we can; I don&#8217;t know; I hate to say dignify contributors who are offering their contributions to open source in this way. But, it also is kind of that there&#8217;s no sense in saying that just because you did not accept payment from getting images, your photos weren&#8217;t any good, or your images did not have an excellent path to where they are housed at that moment.</p>



<p><strong>Matt Mullenweg&nbsp; </strong>10:39</p>



<p>I mean, it&#8217;s really fun to contribute to something larger than yourself. And for many folks, you know, their gift, their craft is something like photography. And so there&#8217;s always going to be the sort of paid marketplaces and, and something like Shutterstock, I think really fantastic companies and services. I think a marketplace for paid content. But we just want to make an alternative, so those who want to donate their work to the world, much like engineers, and designers, and translators of WordPress, donate their work some of that effort to the world, they can do so. Right now, there are some places for that, but we&#8217;re going to try to create one that is fully open, has no advertising, has an open API. So other CMSs can access it too.&nbsp; You know, we&#8217;re going to try to bring the WordPress philosophy to this space.&nbsp;</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>11:29</p>



<p>Gosh, I just love that. While we&#8217;re on the question of contributing to something bigger than yourself, bringing the WordPress philosophy into this space, how do you think CC Search will impact the current media library and how WordPress handles media in general? Or do you have an idea about how it will impact that? Sometimes we don&#8217;t know until we get in?</p>



<p><strong>Matt Mullenweg&nbsp; </strong>11:53</p>



<p>Yeah, I think within Gutenberg, the idea of adding an image from an online library or a search is something we&#8217;ve wanted to do for a while. But either the licensing made it a little tricky, or, you know, some of the sites that did have open things, maybe the site itself had like a lot of advertising or pop-ups or things like that. So by having this hosted by wordpress.org, we&#8217;ll have a clean, open source, and ad-free place that people can access. I suppose it&#8217;s also worth saying that CC Search, which we&#8217;re rebranding as Openverse, is actually all the code behind is open source as well. So there is going to be a new project on WordPress&#8217;s GitHub that will be this open source search engine. So that&#8217;s also part of the contributions; we&#8217;ll be pointing this search engine to try to index and collect Creative Commons license media, but perhaps it could also provide a base for someone else wanting to build a different characters engine or just host Openverse themselves and run it themselves; that is totally fine.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>13:00</p>



<p>I should probably mention, for any of the WP Briefing listeners who are contributing to the WordPress project itself, there is a brand new team that we&#8217;re working on building, and for one wander over and welcome everybody, we are welcoming in an open source community into our open source community. And so, of course, we want to make sure that they know how to get around and feel welcome in the space. But also, anything that you are interested in helping to contribute to that particular project, I think would be helpful. WordPress is big; we have a long history. And so I think I feel confident in saying that, if I were on that team that&#8217;s bringing in this new tool, I would hope that there were some OG WordPressers, who were available to help me discover the ins and outs of things, especially as its 18 years of us.</p>



<p><strong>Matt Mullenweg&nbsp; </strong>14:04</p>



<p>Yeah, it&#8217;s also a new technology stack. So let&#8217;s say you want to be involved in WordPress, but your expertise is more on the Python side, or Elastic Search or something like that. We now have a project where people who are into that or want to learn about it can get involved. Because, of course, you know, contributing and being involved with open source is probably the best way to learn a technology, better than any college degree.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>14:28</p>



<p>I was just talking to some folks about that; our active learning opportunities and our passive learning opportunities get into a different balance as we get older. And active learning opportunities are for real in school, right? And our passive learning opportunities where you get to look at someone else&#8217;s code, you get to review proposals on user flows, and things are harder and harder to come by unless you happen to be in an open source project where we&#8217;re just working on that in the open all day, every day. And I&#8217;ll put a link to the repos in the show notes, and also, I&#8217;ll include a list of the tech stack that we&#8217;re looking at there, just so that no one has to like, chase it down. But yeah, I&#8217;m excited about this new integration, not only for the CMS but also for the community.</p>



<p><strong>Matt Mullenweg&nbsp; </strong>15:26</p>



<p>And the whole library will be available to any plug-in who wants to call to it. And like we said, even other CMSs, much like we designed Gutenberg to be able to be used by other CMSs, how cool would it be if Drupal or Joomla or others were also able to leverage this library and allow their users to contribute to it as well?</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>15:47</p>



<p>Yeah, absolutely. Absolutely. There is a burning question that I feel like we probably should just go ahead and answer here. I&#8217;ve been asked a few times, and I think you have been asked a few times whether this is an actual acquisition. And If yes, then what entity is it under? Is it under the WordPress Foundation? Is it under Automattic?</p>



<p><strong>Matt Mullenweg&nbsp; </strong>16:10</p>



<p>It&#8217;s a little complicated because, as you know, WordPress.org is not part of the Foundation. So basically, Automattic paid Creative Commons, the nonprofit. They will essentially redirect the old URL, so old links to Creative Commons Search won&#8217;t break. And we ended up hiring some of the people that they were parting ways with into Automattic. And then we put that open source code, and we&#8217;ll run the service on WordPress.org, and then those we hired, Automattic hired, will contribute to WordPress.org and the open source projects that power what we&#8217;re calling Openverse now.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>16:54</p>



<p>I am.</p>



<p><strong>Matt Mullenweg&nbsp; </strong>16:56</p>



<p>That&#8217;s kind of an acquisition, but also from a nonprofit, and then going into something, which is not a nonprofit, but is open source and sort of freely available, which is WordPress.org, the website.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>17:06</p>



<p>Yeah, that has been hard for me to answer because you&#8217;re right, it&#8217;s not like it was donated to WordPress or something. But everything that we&#8217;re doing is being donated back to the project, and of course, hopefully, really living into that WordPress ethos that we have of giving back to, to the project, something that made your work and your life better. So there&#8217;s some, some finger-crossing going on in there.</p>



<p><strong>Matt Mullenweg&nbsp; </strong>17:37</p>



<p>We could have skipped some of the steps because the code was open source; we could have just used it or something like that. But it was also a good opportunity, I think, to support the Creative Commons organization. And like we said, as part of that donation, there&#8217;ll be redirecting Creative Commons Search to WordPress.org. And honestly, we don&#8217;t need that, but it just from the point of view of keeping links workings, which is a big passion of mine. I like that none of the links will break or things to the Creative Commons Search, which I think has been around for&#8230; I don&#8217;t actually know the exact timeline, but a very long time. It&#8217;s been part of the internet for a long time. So we&#8217;re happy that it can now continue and be something that can plausibly be around for many decades to come.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>18:23</p>



<p>Yeah, we&#8217;re going to build ourselves a little sustainable program around this project, and it&#8217;s going to be beautiful; I&#8217;m excited.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>18:31</p>



<p>I did want to give everybody a cultural heads up. When I say crossing my fingers, I know that for some of our cultures, that means I was lying. That is not what I&#8217;m saying—crossing my fingers and moving forward on this with a lot of hope.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>18:51</p>



<p>I tried to be careful about my local idioms when I&#8217;m talking to folks who don&#8217;t know that I&#8217;m from Arkansas, so I sometimes say weird things. But I&#8217;ve given up on y&#8217;all, for instance, like that has made its way right back into my language.&nbsp;</p>



<p><strong>Matt Mullenweg&nbsp; </strong>19:09</p>



<p>Y&#8217;all is great. In Texas, we had a funny thing, which maybe applies to you now, which is &#8220;more nervous than a long-tailed cat in a room full of rocking chairs.&#8221; I bet you haven&#8217;t heard that one.&nbsp;</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>19:21</p>



<p>I have not, but I love it, and I&#8217;m going to fold it into my personal vocabulary for later use.&nbsp;</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>19:30</p>



<p>The response to this has been overwhelmingly positive, and I know that I am incredibly positive. I just mentioned like I&#8217;m moving forward through this with hope, even though there&#8217;s a lot of stuff that I don&#8217;t actually know about how we can implement it. I have never brought an existing open source community into an open source community that I&#8217;m currently working with. So there&#8217;s a lot of learning to be done in there. But, from your side Matt, like, are there any things that you are feeling anxiously hopeful about for this? Anything that you hope is right, but you&#8217;re not sure about?</p>



<p><strong>Matt Mullenweg&nbsp; </strong>20:14</p>



<p>Oh, this is just the first step of many. So just having the search engine, is I think good to provide a service to the internet. But where we can really leverage it is those next steps we already talked about, which is really building out the API and integrating the API with the WordPress admin to make it easily accessible within people&#8217;s dashboards. And the Gutenberg blocks to embed these images, quickly and easily, and with all the proper credit and everything. And then the next step, which was probably the one I&#8217;m most excited about, which is enabling folks to contribute to the Creative Commons. And by that, I mean the Commons of Images, which have open licenses and are encouraged for reuse and remixing and all those sorts of great things. And I think that anything we can do to increase more of that stuff on the internet also enables a lot of creativity and innovation.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>21:10</p>



<p>All right. Well, that was an excellent conversation. I am really excited about this. I want to, for my work, just say a huge welcome to the folks over at CC Search and our brand new group around Openverse, and a big thanks to the folks over at the Creative Commons group. Matt, do you have anything else you want to share with any of our audience?</p>



<p><strong>Matt Mullenweg&nbsp; </strong>21:39</p>



<p>No, I feel great that we could support the Creative Commons, keep this going for the open internet, and so excited to work alongside the folks who have been working on Openverse and take it to the next iterations and the next level.&nbsp;</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>21:56</p>



<p>Beautiful. Well, Matt, thank you so much for joining me today. This was a wonderful conversation. My friends, this has been Matt Mullenweg, WordPress project co-founder, and project lead.</p>



<p><strong>Matt Mullenweg&nbsp; </strong>22:08</p>



<p>Thank you so much for having me.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>22:17</p>



<p>Thank you for tuning in today to the WordPress Briefing. I hope that conversation made you as excited as I am about this new adventure that we&#8217;re embarking on with CC Search and that whole team. I&#8217;m going to put in the show notes a few links to where you can find them, where they&#8217;re doing their work, what you can collaborate on, and also some notes about the tech stack that goes into it. I&#8217;m your host, Josepha Haden Chomphosy.Thanks again for joining me and I&#8217;ll see you in a couple of weeks.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10266\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:57:\"
		
		
		
		
		
				
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"The Month in WordPress: April 2021\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wordpress.org/news/2021/05/the-month-in-wordpress-april-2021/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 04 May 2021 15:00:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10253\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:297:\"As WordPress grows, both in usage as a CMS and in participation as a community, it’s important for us to shed the idea that software creation is only about what literally can be done to code or what literally can be done to core or what literally can be done to the CMS.&#160; That was [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Hari Shanker R\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:11530:\"
<blockquote class=\"wp-block-quote\"><p>As WordPress grows, both in usage as a CMS and in participation as a community, it’s important for us to shed the idea that software creation is only about what literally can be done to code or what literally can be done to core or what literally can be done to the CMS.&nbsp;</p></blockquote>



<p class=\"has-drop-cap\">That was <a href=\"https://profiles.wordpress.org/chanthaboune/\">Josepha Haden Chomphosy</a> on the “<a href=\"https://wordpress.org/news/2021/04/your-opinion-is-our-opportunity/\">Your Opinion is Our Opportunity</a>” episode of the <a href=\"https://wordpress.org/news/podcast/\">WP Briefing Podcast</a>, speaking about the importance of co-development and testing for the continued growth and maintenance of WordPress. This month’s updates align closely with these ideas. Read on and see for yourself.&nbsp;</p>



<hr class=\"wp-block-separator\" />



<h2>WordPress 5.7.1 is launched</h2>



<p>WordPress security and maintenance release &#8211; <a href=\"https://wordpress.org/news/2021/04/wordpress-5-7-1-security-and-maintenance-release/\">5.7.1</a> came out in April. The release fixes two major security issues and includes 26 bug fixes. You can update to the latest version directly from your WordPress dashboard or by <a href=\"https://wordpress.org/download/\">downloading</a> it from WordPress.org.</p>



<p>Want to contribute to WordPress 5.8? Check out the <a href=\"https://make.wordpress.org/core/5-8/\">5.8 Development Cycle</a>. To contribute to core, head over to <a href=\"https://core.trac.wordpress.org/\">Trac</a>, and<a href=\"https://core.trac.wordpress.org/report/6\"> pick a 5.8 ticket</a> –– more info in the <a href=\"https://make.wordpress.org/core/handbook/\">Core Contributor Handbook</a>. Don’t forget to join the WordPress <a href=\"https://wordpress.slack.com/archives/C02RQBWTW\">#core</a> channel in the <a href=\"https://make.wordpress.org/chat/\">Make WordPress Slack</a> and follow the <a href=\"https://make.wordpress.org/core/\">Core Team blog</a>. The Core Team hosts weekly chats on Wednesdays at <a href=\"https://www.timeanddate.com/worldclock/fixedtime.html?hour=5&amp;min=00&amp;sec=0\">5 AM</a> and <a href=\"https://www.timeanddate.com/worldclock/fixedtime.html?hour=20&amp;min=00&amp;sec=0\">8 PM</a> UTC.&nbsp;</p>



<h2>Gutenberg Version 10.3, 10.4, and 10.5 are out</h2>



<p>Contributor teams released Gutenberg <a href=\"https://make.wordpress.org/core/2021/04/02/whats-new-in-gutenberg-10-3-31-march/\">version 10.3</a> on April 2, <a href=\"https://make.wordpress.org/core/2021/04/14/whats-new-in-gutenberg-10-4-14-april/\">version 10.4</a> on April 14, and <a href=\"https://make.wordpress.org/core/2021/04/30/whats-new-in-gutenberg-10-5-28-april/\">version 10.5</a> on April 30! <a href=\"https://make.wordpress.org/core/2021/04/02/whats-new-in-gutenberg-10-3-31-march/\">Version 10.3</a> improves the block toolbar and the navigation editor, whereas <a href=\"https://make.wordpress.org/core/2021/04/14/whats-new-in-gutenberg-10-4-14-april/\">version 10.4</a> adds block widgets to the customizer and improvements to the site editor list view. In <a href=\"https://make.wordpress.org/core/2021/04/30/whats-new-in-gutenberg-10-5-28-april/\">version 10.5</a>, you will find a set of new block patterns and enhancements to the template editing mode, along with the ability to embed PDFs.&nbsp;</p>



<p>Want to get involved in building Gutenberg? Follow <a href=\"https://make.wordpress.org/core/\">the Core Team blog</a>, contribute to <a href=\"https://github.com/WordPress/gutenberg/\">Gutenberg on GitHub</a>, and join the <a href=\"https://wordpress.slack.com/archives/C02QB2JS7\">#core-editor</a> channel in the <a href=\"https://make.wordpress.org/chat/\">Make WordPress Slack</a>. The “<a href=\"https://make.wordpress.org/core/2021/03/08/whats-next-in-gutenberg-march-2021/\">What’s next in Gutenberg</a>” post offers more details on the latest updates. If you are unfamiliar with the Gutenberg plugin, <a href=\"https://wordpress.org/news/2021/04/become-an-early-adopter-with-the-gutenberg-plugin/\">learn more in this post</a>.</p>



<h2>Full Site Editing updates</h2>



<p>Following the <a href=\"https://make.wordpress.org/core/2021/04/15/full-site-editing-go-no-go-april-14-2021/\">Full Site Editing (FSE) feature demo</a> hosted by <a href=\"https://profiles.wordpress.org/matveb/\" target=\"_blank\" rel=\"noreferrer noopener\">Matías Ventura</a>, the project leadership decided that WordPress 5.8 will only include some FSE features, such as a template editor for pages/blank templates, a widget editor screen, and the theme.json mechanism. Other features like the Global Styles interface and Site Editor (managing all templates) will be made available later. The team has <a href=\"https://make.wordpress.org/core/2021/04/20/full-site-editing-go-no-go-next-steps/\">started working on the next steps</a> in shipping these chosen FSE features with version 5.8.</p>



<p>New to FSE? Check out <a href=\"https://wordpress.org/news/2021/04/curious-about-full-site-editing/\">this blog post</a> for a high-level overview of the project. You can help test FSE by participating in the <a href=\"https://make.wordpress.org/test/2021/04/14/fse-program-testing-call-5-query-quest/\">latest FSE Outreach Program testing call </a>–– leave your feedback by May 5th. Want to participate in future testing calls? Stay updated by following the <a href=\"https://make.wordpress.org/test/2021/04/22/upcoming-fse-outreach-program-schedule/\">FSE outreach schedule</a>. You can also <a href=\"https://make.wordpress.org/test/2021/04/28/fse-program-bring-your-questions-round-two/\">submit your questions</a> around FSE right now.</p>



<h2>WordCamp Europe 2021 is on the calendar</h2>



<p>One of the most exciting WordPress events,&nbsp; <a href=\"https://europe.wordcamp.org/2021/\">WordCamp Europe 2021</a>, will be held online on June 7-9, 2021! Event organizers have opened up calls for <a href=\"https://europe.wordcamp.org/2021/call-for-sponsors/\">sponsors</a> and <a href=\"https://europe.wordcamp.org/2021/call-for-media-partners-and-supporters/\">media partners</a>. Free tickets for the event will be available soon — <a href=\"https://europe.wordcamp.org/2021/#subscribe-email\">sign up for email updates</a> to be notified when they are out!</p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading</h2>



<ul><li>WordPress now powers <a href=\"https://w3techs.com/technologies/details/cm-wordpress\">41% of the web</a>!</li><li><a href=\"https://make.wordpress.org/updates/2021/04/15/quarterly-updates-q1-2021/\">Q1 2021 updates from the WordPress project</a> have been published.</li><li>The Core Team discussed a <a href=\"https://make.wordpress.org/core/2021/04/18/proposal-treat-floc-as-a-security-concern/\">proposal</a> to treat Federated Learning of Cohorts (FLoC), a Google Chrome feature, as a security concern. The team <a href=\"https://make.wordpress.org/core/2021/04/18/proposal-treat-floc-as-a-security-concern/#comment-41207\">eventually decided</a> to track the status of the FLoC trial/implementation in a <a href=\"https://core.trac.wordpress.org/ticket/53069\">Trac ticket</a> and monitor periodically.&nbsp;</li><li>The Core Team will <a href=\"https://make.wordpress.org/core/2021/04/22/ie-11-support-phase-out-plan/\">remove Internet Explorer 11 support in WordPress version 5.8</a>.&nbsp;</li><li>The Community Team has opened up a <a href=\"https://make.wordpress.org/community/2021/04/26/discussing-the-path-to-in-person-wordcamps/\">discussion on the path to in-person WordCamps</a> and is requesting feedback from community members.</li><li>The Community Team is also <a href=\"https://make.wordpress.org/community/2021/04/19/discussion-companies-who-run-competitive-ads-against-wordpress-and-apply-to-sponsor-wordcamps/\">requesting feedback</a> on whether companies who run competitive ads against WordPress can apply to sponsor WordCamps.&nbsp;</li><li><a href=\"https://centroamerica.wordcamp.org/2021/\">WordCamp Centroamérica 2021</a> and <a href=\"https://greece.wordcamp.org/2021/\">WordCamp Greece 2021</a> were held successfully in April. Videos of WordCamp Centroamérica are now available <a href=\"https://wordpress.tv/event/wordcamp-centroamerica-2021/\">on WordPress.tv</a>! While you are at it, don&#8217;t miss this<a href=\"https://central.wordcamp.org/news/2021/04/29/making-a-great-online-conference-experience-at-wordcamp-prague/#\"> excellent recap of WordCamp Prague 2021</a> on the WordCamp Central blog.</li><li>Contributor teams are actively working on building the <a href=\"https://wordpress.org/patterns/\">Block Pattern Directory</a>. You can read about work updates on this project from the <a href=\"https://make.wordpress.org/meta/2021/04/28/block-pattern-directory-update/\">Meta Team</a> and the <a href=\"https://make.wordpress.org/design/2021/03/30/wordpress-org-patterns-directory/\">Design Team</a>.</li><li>Check out the <a href=\"https://wordpress.org/news/2021/04/getting-started-with-the-figma-wordpress-design-library/\">blog post on getting started with the Figma WordPress Design Library</a>. You can use the library to create design prototypes for the WordPress UI in <a href=\"https://www.figma.com/\">Figma</a>.</li><li>The Polyglots Team is making significant progress on the <a href=\"https://make.wordpress.org/polyglots/2021/04/26/polyglots-training-working-group-update-3/\">Polyglots Training course</a>.</li><li>The Training Team has <a href=\"https://make.wordpress.org/training/2021/04/23/discussion-contributor-ladders-for-the-training-team-and-learn-wordpress/\">proposed a contributor ladder</a> as a resource for team contributors to understand ways to participate and find growth opportunities.&nbsp;</li><li>The <a href=\"https://github.com/WordPress/Requests\">Requests library</a> has moved to the WordPress GitHub organization and has a new release: <a href=\"https://github.com/WordPress/Requests/releases/tag/v1.8.0\">version 1.8.0</a>.&nbsp;</li><li>The Docs Team is<a href=\"https://make.wordpress.org/docs/2021/04/05/update-on-the-revision-of-documentation/\"> working on redesigning HelpHub</a> by reviewing its content and design.</li><li>The Themes Team has shared a proposal on <a href=\"https://make.wordpress.org/themes/2021/04/22/removing-blockers-for-block-themes/\">fixing upload issues for block themes</a>.</li><li><a href=\"https://wordpress.org/news/2021/04/people-of-wordpress-tyler-lau/\">Tyler Lau</a> from the U.S. was featured in April’s <a href=\"https://wordpress.org/news/category/heropress/\">People of WordPress</a>.</li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it using this form</em></a><em>.</em></p>



<p><em>The following folks contributed to April’s Month in WordPress: <a href=\'https://profiles.wordpress.org/andreamiddleton/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>andreamiddleton</a> <a href=\'https://profiles.wordpress.org/cbringmann/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>cbringmann</a> <a href=\'https://profiles.wordpress.org/chaion07/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>chaion07</a> <a href=\'https://profiles.wordpress.org/hlashbrooke/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>hlashbrooke</a> and <a href=\'https://profiles.wordpress.org/jrf/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>jrf</a>&nbsp;</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10253\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:57:\"
		
		
		
		
		
				
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"Getting Started with the Figma WordPress Design Library\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"https://wordpress.org/news/2021/04/getting-started-with-the-figma-wordpress-design-library/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 28 Apr 2021 17:52:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Uncategorized\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10173\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"Get Started with the Figma WordPress Design Library! \";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Chloe Bringmann\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:26010:\"
<p>Created by James Koster, (<a href=\'https://profiles.wordpress.org/jameskoster/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>jameskoster</a>)</p>



<p>As the name suggests, the WordPress Design Library is a library of WordPress design assets, enabling anyone to quickly create design prototypes for WordPress UI in Figma.</p>



<p>These tools are useful for designers when creating new UI and for anyone looking to contribute ideas, enhancements, or even solutions to bug reports. Sometimes pictures really do speak a thousand words.</p>



<p>In this post, we&#8217;ll talk about some key features of Figma before diving into a practical example that demonstrates some of the WordPress Design Library utilities.</p>



<h2><strong>What Is Figma?</strong></h2>



<div class=\"wp-block-image\"><figure class=\"aligncenter size-large is-resized\"><img loading=\"lazy\" src=\"https://i2.wp.com/wordpress.org/news/files/2021/04/image8.png?resize=632%2C296&#038;ssl=1\" alt=\"\" class=\"wp-image-10174\" width=\"632\" height=\"296\" srcset=\"https://i2.wp.com/wordpress.org/news/files/2021/04/image8.png?resize=1024%2C481&amp;ssl=1 1024w, https://i2.wp.com/wordpress.org/news/files/2021/04/image8.png?resize=300%2C141&amp;ssl=1 300w, https://i2.wp.com/wordpress.org/news/files/2021/04/image8.png?resize=768%2C361&amp;ssl=1 768w, https://i2.wp.com/wordpress.org/news/files/2021/04/image8.png?resize=1536%2C722&amp;ssl=1 1536w, https://i2.wp.com/wordpress.org/news/files/2021/04/image8.png?w=1770&amp;ssl=1 1770w, https://i2.wp.com/wordpress.org/news/files/2021/04/image8.png?w=1264&amp;ssl=1 1264w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure></div>



<p><a rel=\"nofollow\" href=\"https://www.figma.com/\">Figma</a> is a collaborative design tool that members of the WordPress project&#8217;s design team have<a href=\"https://make.wordpress.org/design/2018/11/19/figma-for-wordpress/\"> been using</a> for several years to work on and share design concepts. It offers a variety of handy features such as: in-browser access, rich prototyping tools, component libraries, code inspectors, live embeds, inline commenting, plugins, and much much more.</p>



<p>Perhaps best of all, it is totally free to sign up and start playing around. If you join the WordPress.org Figma organization (instructions below), you&#8217;ll gain access to the WordPress Design Library enabling you to design WordPress UI in no time.</p>



<h2><strong>What Is the WordPress Design Library?</strong></h2>



<blockquote class=\"wp-block-quote\"><p>In Figma, you can share components and styles by publishing them, transforming your file into a library so that you can use instances of those components in other files.</p><p></p><p></p><cite><a rel=\"nofollow\" href=\"https://www.figma.com/best-practices/components-styles-and-shared-libraries/#:~:text=Libraries%3A%20In%20Figma%2C%20you%20can,instances%20of%20your%20components%20live.\">Figma.com</a></cite></blockquote>



<p>It may be easiest to think of the WordPress Design Library as a visual representation of all the javascript components that compose UI in the WordPress codebase. As an end user of the library, you can use those components in a self-contained environment to create new interface designs. It&#8217;s kind of like a big LEGO box containing all the UI pieces (buttons, form inputs, etc.) that you can use to create and try out new designs.</p>



<figure class=\"wp-block-jetpack-image-compare\"><div class=\"juxtapose\" data-mode=\"horizontal\"><img loading=\"lazy\" id=\"10175\" src=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image13.png?resize=632%2C340&#038;ssl=1\" alt=\"\" width=\"632\" height=\"340\" class=\"image-compare__image-before\" data-recalc-dims=\"1\" /><img loading=\"lazy\" id=\"10176\" src=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image6.png?resize=632%2C340&#038;ssl=1\" alt=\"\" width=\"632\" height=\"340\" class=\"image-compare__image-after\" data-recalc-dims=\"1\" /></div></figure>



<p>Creating designs with these assets enables rapid ideation on new interfaces by removing mundane processes that one would ordinarily have to work through. Nobody wants to repeatedly double-check that the button they made perfectly matches the buttons rendered by the code! And on the flip-side of that coin, anyone sharing a design with others will generally endeavor to make specific elements (like buttons) match what exists in the code as closely as possible. The WordPress Design Library solves both these headaches and more.</p>



<p>An additional benefit to these assets visually matching what exists in the codebase is that any designs you create with them will inherently make use of the latest WordPress design language and consequently <em>feel</em> like WordPress with almost no effort required. Passing such designs on to developers makes them easier to interpret and implement too.</p>



<h2><strong>Figma Fundamentals</strong></h2>



<p>Before getting into the practical section of this post, let&#8217;s quickly cover some of the fundamental features of Figma libraries. This will help prepare us for working with the WordPress Design Library.</p>



<h3><strong>Components</strong></h3>



<p>As we touched on above, the library consists of &#8220;components&#8221; that serve as visual counterparts to their code-based equivalents. That is to say, there is a Button component in Figma, <em>and</em> a matching Button component in the WordPress codebase.</p>



<p>But what <em>is</em> a Figma component?</p>



<blockquote class=\"wp-block-quote\"><p>Components are elements you can reuse across your designs. They help to create and manage consistent designs across projects.</p><p></p><cite><a rel=\"nofollow\" href=\"https://help.figma.com/hc/en-us/articles/360038662654-Guide-to-Components-in-Figma\">help.figma.com</a></cite></blockquote>



<p>Let&#8217;s quickly explore some of the properties of Figma components to understand the ways they help when working on our next design.</p>



<h3><strong>Variants</strong></h3>



<p>Some Figma components offer variants. One example is Button(s) which all have the following states:</p>



<ul><li>Resting</li><li>Hover</li><li>Focus</li><li>Disabled</li></ul>



<p>These can be manipulated via the variants interface in Figma:</p>



<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"632\" height=\"449\" src=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image7-2.gif?resize=632%2C449&#038;ssl=1\" alt=\"\" class=\"wp-image-10179\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image7-2.gif?resize=1024%2C727&amp;ssl=1 1024w, https://i1.wp.com/wordpress.org/news/files/2021/04/image7-2.gif?resize=300%2C213&amp;ssl=1 300w, https://i1.wp.com/wordpress.org/news/files/2021/04/image7-2.gif?resize=768%2C545&amp;ssl=1 768w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure>



<p>Other examples of components with variants are form inputs and menu items. Variants are a new feature in Figma, so we&#8217;ll be adding more over time.</p>



<h3><strong>Overrides</strong></h3>



<p>Although any components you insert are intrinsically linked to the master component in the library, it is possible to override some properties.</p>



<p>While working with an instance of the Button component, you can change things like the label, or even the background color, while maintaining the link to the master component in the library. If you&#8217;re familiar with git workflows, this is kind of like creating a local branch. Any changes you make can easily be reset in a couple of clicks.</p>



<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"632\" height=\"527\" src=\"https://i0.wp.com/wordpress.org/news/files/2021/04/image10.gif?resize=632%2C527&#038;ssl=1\" alt=\"\" class=\"wp-image-10180\" srcset=\"https://i0.wp.com/wordpress.org/news/files/2021/04/image10.gif?resize=1024%2C854&amp;ssl=1 1024w, https://i0.wp.com/wordpress.org/news/files/2021/04/image10.gif?resize=300%2C250&amp;ssl=1 300w, https://i0.wp.com/wordpress.org/news/files/2021/04/image10.gif?resize=768%2C641&amp;ssl=1 768w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure>



<p>Overrides made to your local instance will persist even when the master component is updated. So if your design calls for a button with a green background, you can apply that override safely with the knowledge that even if the master component is updated, your button can inherit those updates and remain green.</p>



<hr class=\"wp-block-separator\" />



<p>We&#8217;ve only really scratched the surface of components here. So I would recommend the official <a rel=\"nofollow\" href=\"https://help.figma.com/hc/en-us/articles/360038662654-Guide-to-Components-in-Figma\">Figma documentation</a> for more advanced information.</p>



<h3><strong>Figma Styles</strong></h3>



<p>In addition to components, styles are also published as part of the WordPress Design Library. They have similar properties to components in that a master style exists in the library and can be utilized in your local Figma file. Just like Components, Styles will receive updates when changes to the library are published.</p>



<p>Styles are used to define colors, typographical rules, and effects like drop-shadows present in the WordPress codebase. They enable you to apply things like text or background colors that will match other UI parts.</p>



<p>Using Styles from the library, you ensure that your creations match existing UI elements, making it easier to implement.</p>



<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"632\" height=\"799\" src=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image11.png?resize=632%2C799&#038;ssl=1\" alt=\"\" class=\"wp-image-10181\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image11.png?resize=810%2C1024&amp;ssl=1 810w, https://i1.wp.com/wordpress.org/news/files/2021/04/image11.png?resize=237%2C300&amp;ssl=1 237w, https://i1.wp.com/wordpress.org/news/files/2021/04/image11.png?resize=768%2C971&amp;ssl=1 768w, https://i1.wp.com/wordpress.org/news/files/2021/04/image11.png?w=1152&amp;ssl=1 1152w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure>



<hr class=\"wp-block-separator\" />



<p>To learn more about styles in Figma, I recommend the <a rel=\"nofollow\" href=\"https://help.figma.com/hc/en-us/articles/360039238753-Styles-in-Figma\">official documentation</a>.</p>



<h3><strong>Views and Stickers</strong></h3>



<p>&#8220;Stickers&#8221; are simply arrangements of Components and Styles that have been combined to represent common UI elements. They are not good candidates for full componentization due to their frequent customization needs. Examples of Stickers include the Inspector sidebar and the block inserter:</p>



<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"632\" height=\"770\" src=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image16.png?resize=632%2C770&#038;ssl=1\" alt=\"\" class=\"wp-image-10182\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image16.png?resize=841%2C1024&amp;ssl=1 841w, https://i1.wp.com/wordpress.org/news/files/2021/04/image16.png?resize=246%2C300&amp;ssl=1 246w, https://i1.wp.com/wordpress.org/news/files/2021/04/image16.png?resize=768%2C935&amp;ssl=1 768w, https://i1.wp.com/wordpress.org/news/files/2021/04/image16.png?w=1113&amp;ssl=1 1113w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure>



<p>Their utility is simple: find the sticker you need, peel (copy) it from the WordPress Design Library, and stick (paste) it into your local file before customizing as needed.</p>



<p><em>Stickers</em> are not Figma features like Components and Styles, but any stickers you copy to a working file will stay up to date by virtue of their underlying assets.</p>



<p><em>Views</em> are arrangements of components, styles, <em>and</em> stickers.</p>



<h2><strong>Designing a Block Using the WordPress Design Library</strong></h2>



<p>Okay, now that we have a handle on the basics of Figma libraries and their features and the utilities of the WordPress Design Library like Stickers and Views, let&#8217;s work through a practical example – designing the UI for a brand new block.</p>



<h3><strong>Getting Started</strong></h3>



<p>All you need to get started is a Figma account added to the WordPress.org Figma organization.</p>



<p>Once you&#8217;ve signed up at<a href=\"https://www.figma.com/\"> Figma</a>, simply join the<a href=\"http://wordpress.slack.com/messages/design/\"> #Design</a> channel on the community Slack and request an invite. Include your Figma username, and a friendly community member will help get you set up in no time.</p>



<p>Now the fun begins!</p>



<p>To create a fresh new design file in Figma, visit the<a href=\"https://www.figma.com/files/project/1339415/Gutenberg?fuid=652576565531990233\"> Gutenberg project</a> and click the &#8220;+ New&#8221; button.</p>



<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"632\" height=\"395\" src=\"https://i2.wp.com/wordpress.org/news/files/2021/04/image15.png?resize=632%2C395&#038;ssl=1\" alt=\"\" class=\"wp-image-10183\" srcset=\"https://i2.wp.com/wordpress.org/news/files/2021/04/image15.png?resize=1024%2C640&amp;ssl=1 1024w, https://i2.wp.com/wordpress.org/news/files/2021/04/image15.png?resize=300%2C187&amp;ssl=1 300w, https://i2.wp.com/wordpress.org/news/files/2021/04/image15.png?resize=768%2C480&amp;ssl=1 768w, https://i2.wp.com/wordpress.org/news/files/2021/04/image15.png?w=1469&amp;ssl=1 1469w, https://i2.wp.com/wordpress.org/news/files/2021/04/image15.png?w=1264&amp;ssl=1 1264w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure>



<p>Now let&#8217;s include the WordPress Design Library in our working file so that we have access to all the goodies we&#8217;ll need:</p>



<ol><li>Open the &#8220;Assets&#8221; panel and click the little book icon to view the available Team Libraries.</li><li>In the modal, toggle the WordPress Design Library on. You can leave the others off for now.</li></ol>



<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"632\" height=\"341\" src=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image18.gif?resize=632%2C341&#038;ssl=1\" alt=\"\" class=\"wp-image-10184\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image18.gif?resize=1024%2C553&amp;ssl=1 1024w, https://i1.wp.com/wordpress.org/news/files/2021/04/image18.gif?resize=300%2C162&amp;ssl=1 300w, https://i1.wp.com/wordpress.org/news/files/2021/04/image18.gif?resize=768%2C415&amp;ssl=1 768w, https://i1.wp.com/wordpress.org/news/files/2021/04/image18.gif?resize=1536%2C829&amp;ssl=1 1536w, https://i1.wp.com/wordpress.org/news/files/2021/04/image18.gif?w=1264&amp;ssl=1 1264w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure>



<p>After closing the modal, you&#8217;ll notice a number of components become visible in the assets panel. To insert them, they can be dragged on to the canvas:</p>



<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"632\" height=\"341\" src=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image5.gif?resize=632%2C341&#038;ssl=1\" alt=\"\" class=\"wp-image-10185\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image5.gif?resize=1024%2C553&amp;ssl=1 1024w, https://i1.wp.com/wordpress.org/news/files/2021/04/image5.gif?resize=300%2C162&amp;ssl=1 300w, https://i1.wp.com/wordpress.org/news/files/2021/04/image5.gif?resize=768%2C415&amp;ssl=1 768w, https://i1.wp.com/wordpress.org/news/files/2021/04/image5.gif?resize=1536%2C829&amp;ssl=1 1536w, https://i1.wp.com/wordpress.org/news/files/2021/04/image5.gif?w=1264&amp;ssl=1 1264w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure>



<p>It&#8217;s kind of like inserting a block <img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/1f642.png\" alt=\"?\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>



<h3><strong>Creating a Pizza Block <img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/1f355.png\" alt=\"?\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></strong></h3>



<p>I love to eat pizza, so for fun, I&#8217;m going to design a new block that simply allows the user to display a delicious pizza in their posts and pages. I want the block to include options for a total number of slices and different toppings.</p>



<h3><strong>Work Out the Flow</strong></h3>



<p>I always like to concentrate on individual flows when designing blocks. That is to say, the linear steps a user will take when working with that block. In this case, I want to create visualizations of the following steps/views in our Figma file:</p>



<ol><li>Inserting the block from the Block Inserter</li><li>The Pizza Block placeholder state including options in the block, its Toolbar, and the Inspector</li><li>The configured Pizza Block settings</li><li>The end result – a delicious pizza sitting comfortably on the canvas</li></ol>



<h3><strong>Sketch the New States</strong></h3>



<p>Thanks to the WordPress Design Library, I&#8217;ll be using as many existing UI components as possible, but I still need a rough idea of how they will be composed in the new interfaces that my Pizza block will require. I normally find it helpful to sketch these out on paper.</p>



<p>Here&#8217;s the placeholder state which users will see when they first insert the block. This should be all I need:</p>



<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"632\" height=\"843\" src=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image2.png?resize=632%2C843&#038;ssl=1\" alt=\"\" class=\"wp-image-10186\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image2.png?w=768&amp;ssl=1 768w, https://i1.wp.com/wordpress.org/news/files/2021/04/image2.png?resize=225%2C300&amp;ssl=1 225w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure>



<h3><strong>Prepare the Views and Stickers</strong></h3>



<p>Helpfully, there are Views in the WordPress Design Library I can use for each of the steps in the flow outlined above.</p>



<p>I open the library, navigate to the Views page, find the views I need, copy them, and paste into my working file.</p>



<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"632\" height=\"374\" src=\"https://i2.wp.com/wordpress.org/news/files/2021/04/image3.gif?resize=632%2C374&#038;ssl=1\" alt=\"\" class=\"wp-image-10187\" srcset=\"https://i2.wp.com/wordpress.org/news/files/2021/04/image3.gif?resize=1024%2C606&amp;ssl=1 1024w, https://i2.wp.com/wordpress.org/news/files/2021/04/image3.gif?resize=300%2C178&amp;ssl=1 300w, https://i2.wp.com/wordpress.org/news/files/2021/04/image3.gif?resize=768%2C455&amp;ssl=1 768w, https://i2.wp.com/wordpress.org/news/files/2021/04/image3.gif?resize=1536%2C910&amp;ssl=1 1536w, https://i2.wp.com/wordpress.org/news/files/2021/04/image3.gif?w=1264&amp;ssl=1 1264w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure>



<p>It is very important to <strong>copy</strong> (not cut) Views from the library so that they remain intact and other people can still access them. If you cut them, they&#8217;ll be gone forever, so please don&#8217;t do that <img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/1f642.png\" alt=\"?\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>



<p>I&#8217;m also going to need a block placeholder sticker, so I navigate to the Stickers page, copy the one that most closely resembles my sketch from before, and paste it into my working file.</p>



<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"632\" height=\"374\" src=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image12.gif?resize=632%2C374&#038;ssl=1\" alt=\"\" class=\"wp-image-10188\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image12.gif?resize=1024%2C606&amp;ssl=1 1024w, https://i1.wp.com/wordpress.org/news/files/2021/04/image12.gif?resize=300%2C178&amp;ssl=1 300w, https://i1.wp.com/wordpress.org/news/files/2021/04/image12.gif?resize=768%2C455&amp;ssl=1 768w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure>



<p>As with views, please only <strong>copy</strong> stickers; do not cut them.</p>



<h3><strong>Gather the Components</strong></h3>



<p>Referring back to the placeholder state I sketched out on paper (it can be helpful to import this into your Figma file), I can see that I&#8217;m going to need some form elements to realize the design.</p>



<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"632\" height=\"446\" src=\"https://i2.wp.com/wordpress.org/news/files/2021/04/image4.png?resize=632%2C446&#038;ssl=1\" alt=\"\" class=\"wp-image-10189\" srcset=\"https://i2.wp.com/wordpress.org/news/files/2021/04/image4.png?resize=1024%2C722&amp;ssl=1 1024w, https://i2.wp.com/wordpress.org/news/files/2021/04/image4.png?resize=300%2C211&amp;ssl=1 300w, https://i2.wp.com/wordpress.org/news/files/2021/04/image4.png?resize=768%2C541&amp;ssl=1 768w, https://i2.wp.com/wordpress.org/news/files/2021/04/image4.png?resize=1536%2C1083&amp;ssl=1 1536w, https://i2.wp.com/wordpress.org/news/files/2021/04/image4.png?w=1999&amp;ssl=1 1999w, https://i2.wp.com/wordpress.org/news/files/2021/04/image4.png?w=1264&amp;ssl=1 1264w, https://i2.wp.com/wordpress.org/news/files/2021/04/image4.png?w=1896&amp;ssl=1 1896w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure>



<p>I navigate to the Assets panel, locate the components I need, and drag them into my file:</p>



<figure class=\"wp-block-image\"><img src=\"https://lh5.googleusercontent.com/UDyZdtZGo9N0e2qwgyIyz8V3xu9_zwGW9qBbBnozvwmXmVYURZ-ROLANtW7FafWYbQRnPQNWeRupk_9_1nzmKn8gRBlYDMKYR3QpwAubv8ZKAPMS_uV9VaYHsjfPItfqPiY0d1X5\" alt=\"\" /></figure>



<p>Helpful tip: Once a component has been inserted, you can transform it into another component via its settings panel. Sometimes it is easier to copy/paste a component you already inserted and transform it this way, rather than opening the assets panel over and over.</p>



<h3><strong>Arrange the Views, Stickers, and Components to Create a Coherent Design</strong></h3>



<p>Now that we’ve gathered all the individual pieces we need, it&#8217;s simply a case of arranging them so that they resemble each of the steps of the flow we outlined before. This is done with simple drag and drop.</p>



<p>If you&#8217;re familiar with software like Photoshop, Sketch, and others, this should feel very familiar.</p>



<figure class=\"wp-block-image\"><img src=\"https://lh3.googleusercontent.com/DVeU3I9ajqRvMD_e5q6G5vctb4TGbgA9CsIR9xYZ3yPqtmPhbDP9cODTHH4KS-I8GB9R4UF2DV6SSsayKpy45AEDvvY2gLbMsCA0ivfsqGcm509OWeTOpaMuQcv7TFz6-xoiKFfo\" alt=\"\" /></figure>



<p>Once everything is in place, our flow is complete:</p>



<figure class=\"wp-block-image size-large\"><a href=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image14-1.png?ssl=1\"><img loading=\"lazy\" width=\"632\" height=\"97\" src=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image14-1.png?resize=632%2C97&#038;ssl=1\" alt=\"\" class=\"wp-image-10238\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2021/04/image14-1.png?resize=1024%2C157&amp;ssl=1 1024w, https://i1.wp.com/wordpress.org/news/files/2021/04/image14-1.png?resize=300%2C46&amp;ssl=1 300w, https://i1.wp.com/wordpress.org/news/files/2021/04/image14-1.png?resize=768%2C118&amp;ssl=1 768w, https://i1.wp.com/wordpress.org/news/files/2021/04/image14-1.png?resize=1536%2C235&amp;ssl=1 1536w, https://i1.wp.com/wordpress.org/news/files/2021/04/image14-1.png?w=1999&amp;ssl=1 1999w, https://i1.wp.com/wordpress.org/news/files/2021/04/image14-1.png?w=1264&amp;ssl=1 1264w, https://i1.wp.com/wordpress.org/news/files/2021/04/image14-1.png?w=1896&amp;ssl=1 1896w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></a></figure>



<p>I still find it incredible that we&#8217;re able to do this in just a few short moments.</p>



<h3><strong>Hook up the Prototype</strong></h3>



<p>With each step of our flow created, the last piece of the puzzle is to connect them and form a clickable prototype.</p>



<p>I switch to the Prototype panel and create click behaviors by selecting a layer, then dragging the white dot to the corresponding frame.</p>



<figure class=\"wp-block-image\"><img src=\"https://lh5.googleusercontent.com/i0fLdjWZhRTNFCKvHLLEfUnFx5CIm7p014R1avEV02F_B4DrG1v6Cw-XqYBth9JVYylylM7_mkqcALWEWcUVf0dRhgixJRtmsRIDHyMIZyom2cPdetMAFixgsvsmrqT03Xevync7\" alt=\"\" /></figure>



<p>There are a variety of behaviors that the Figma prototyping tools support, such as a hover, drag, and click. It is even possible to create smart animations. Perhaps that&#8217;s something we can explore in another tutorial, but for now, I will refer you to the <a rel=\"nofollow\" href=\"https://help.figma.com/hc/en-us/articles/360040314193-Guide-to-prototyping-in-Figma\">Figma documentation</a> for more advanced prototyping.</p>



<p>Now that I&#8217;ve connected all the appropriate elements, I am able to take my prototype for a test drive by clicking the Play <img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/25b6.png\" alt=\"▶\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /> icon:</p>



<figure class=\"wp-block-image\"><img src=\"https://lh3.googleusercontent.com/nBmEr4ohZ8RsjLM5wm4u8UY_zzTE0V1bXj-uoNV79WDibl5bgkZXY64ixl_BgNutg74fvxRZokUtLzWuWVlD46W4tAD_-Dcf-TclgIR9UoO73oCmNxmfcSEmUDgDG0e5WYFJ80tH\" alt=\"\" /></figure>



<p>You can try it too; just click <a href=\"https://www.figma.com/proto/BmRYWzfrakFwsmIQa24xqx/Pizza-Block?page-id=0%3A1&amp;node-id=48%3A767&amp;viewport=1792%2C385%2C0.46477335691452026&amp;scaling=min-zoom\">here</a>.</p>



<h2><strong>That&#8217;s All, Folks!</strong></h2>



<p>I tried to keep this tutorial fairly simple and concise; even though we only really got to grips with the basics here, you can see the power of Figma and the WordPress Design Library when it comes to trying out new designs.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10173\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:32:\"https://wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"
	hourly	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"
	1	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:4:\"site\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"14607090\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:9:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Tue, 01 Jun 2021 12:16:43 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Fri, 28 May 2021 06:08:33 GMT\";s:4:\"link\";s:63:\"<https://wordpress.org/news/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 2\";}}s:5:\"build\";s:14:\"20201016152008\";}","no"),
("686","_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca","1622593003","no"),
("687","_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca","1622549803","no"),
("688","_transient_timeout_wc_blocks_query_301f4e91bc493970ae9352226349db65","1625141824","no"),
("689","_transient_wc_blocks_query_301f4e91bc493970ae9352226349db65","a:2:{s:7:\"version\";s:10:\"1622543932\";s:5:\"value\";a:0:{}}","no"),
("691","_transient_timeout_wc_blocks_query_b830d3785c97bb55310e03a8f188db53","1625141838","no"),
("692","_transient_wc_blocks_query_b830d3785c97bb55310e03a8f188db53","a:2:{s:7:\"version\";s:10:\"1622543932\";s:5:\"value\";a:0:{}}","no"),
("695","woocommerce_checkout_address_2_field","optional","yes"),
("727","acf_version","5.7.12","yes"),
("731","limit_login_activation_timestamp","1622550979","no");/*END*/
INSERT INTO webtoffee_options VALUES
("732","limit_login_notice_enable_notify_timestamp","1619786179","no"),
("758","_transient_timeout_wpseo-statistics-totals","1622647951","no"),
("759","_transient_wpseo-statistics-totals","a:1:{i:1;a:2:{s:6:\"scores\";a:1:{i:0;a:4:{s:8:\"seo_rank\";s:2:\"na\";s:5:\"label\";s:53:\"Berichten <strong>zonder</strong> een focus keyphrase\";s:5:\"count\";i:1;s:4:\"link\";s:98:\"http://localhost:8888/wp-admin/edit.php?post_status=publish&#038;post_type=post&#038;seo_filter=na\";}}s:8:\"division\";a:5:{s:3:\"bad\";i:0;s:2:\"ok\";i:0;s:4:\"good\";i:0;s:2:\"na\";i:1;s:7:\"noindex\";i:0;}}}","no"),
("760","_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a","1622572365","no"),
("761","_site_transient_poptags_40cd750bba9870f18aada2478b24840a","O:8:\"stdClass\":100:{s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:4914;}s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4768;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2715;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2593;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:2000;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1856;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1836;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1515;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1504;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1497;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1494;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1479;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1470;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1311;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:1262;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:1250;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1230;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1152;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1125;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:1057;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:955;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:930;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:908;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:887;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:878;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:826;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:819;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:809;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:806;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:783;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:763;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:746;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:727;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:726;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:718;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:714;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:681;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:679;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:665;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:664;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:662;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:660;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:653;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:648;}s:9:\"gutenberg\";a:3:{s:4:\"name\";s:9:\"gutenberg\";s:4:\"slug\";s:9:\"gutenberg\";s:5:\"count\";i:638;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:608;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:598;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:598;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:590;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:589;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:576;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:571;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:566;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:561;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:559;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:557;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:546;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:546;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:544;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:540;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:530;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:520;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:511;}s:9:\"elementor\";a:3:{s:4:\"name\";s:9:\"elementor\";s:4:\"slug\";s:9:\"elementor\";s:5:\"count\";i:510;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:503;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:500;}s:5:\"block\";a:3:{s:4:\"name\";s:5:\"block\";s:4:\"slug\";s:5:\"block\";s:5:\"count\";i:500;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:495;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:488;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:486;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:478;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:466;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:460;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:457;}s:14:\"contact-form-7\";a:3:{s:4:\"name\";s:14:\"contact form 7\";s:4:\"slug\";s:14:\"contact-form-7\";s:5:\"count\";i:449;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:445;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:445;}s:8:\"shipping\";a:3:{s:4:\"name\";s:8:\"shipping\";s:4:\"slug\";s:8:\"shipping\";s:5:\"count\";i:444;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:443;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:443;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:432;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:425;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:420;}s:11:\"performance\";a:3:{s:4:\"name\";s:11:\"performance\";s:4:\"slug\";s:11:\"performance\";s:5:\"count\";i:413;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:410;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:408;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:405;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:400;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:394;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:390;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:388;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:380;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:379;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:378;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:371;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:365;}s:6:\"import\";a:3:{s:4:\"name\";s:6:\"import\";s:4:\"slug\";s:6:\"import\";s:5:\"count\";i:364;}s:5:\"cache\";a:3:{s:4:\"name\";s:5:\"cache\";s:4:\"slug\";s:5:\"cache\";s:5:\"count\";i:356;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:356;}s:16:\"custom-post-type\";a:3:{s:4:\"name\";s:16:\"custom post type\";s:4:\"slug\";s:16:\"custom-post-type\";s:5:\"count\";i:347;}}","no"),
("774","_transient_timeout_as-post-store-dependencies-met","1622649085","no"),
("775","_transient_as-post-store-dependencies-met","yes","no"),
("797","_site_transient_timeout_theme_roots","1622565337","no"),
("798","_site_transient_theme_roots","a:6:{s:4:\"neve\";s:7:\"/themes\";s:7:\"oceanwp\";s:7:\"/themes\";s:10:\"storefront\";s:7:\"/themes\";s:14:\"twentynineteen\";s:7:\"/themes\";s:12:\"twentytwenty\";s:7:\"/themes\";s:15:\"twentytwentyone\";s:7:\"/themes\";}","no"),
("800","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/nl_NL/wordpress-5.7.2.zip\";s:6:\"locale\";s:5:\"nl_NL\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/nl_NL/wordpress-5.7.2.zip\";s:10:\"no_content\";s:0:\"\";s:11:\"new_bundled\";s:0:\"\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"5.7.2\";s:7:\"version\";s:5:\"5.7.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.6\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1622564170;s:15:\"version_checked\";s:5:\"5.7.2\";s:12:\"translations\";a:0:{}}","no"),
("802","_site_transient_update_themes","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1622564213;s:7:\"checked\";a:6:{s:4:\"neve\";s:6:\"2.11.6\";s:7:\"oceanwp\";s:5:\"2.0.8\";s:10:\"storefront\";s:5:\"3.7.0\";s:14:\"twentynineteen\";s:3:\"2.0\";s:12:\"twentytwenty\";s:3:\"1.7\";s:15:\"twentytwentyone\";s:3:\"1.3\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:6:{s:4:\"neve\";a:6:{s:5:\"theme\";s:4:\"neve\";s:11:\"new_version\";s:6:\"2.11.6\";s:3:\"url\";s:34:\"https://wordpress.org/themes/neve/\";s:7:\"package\";s:53:\"https://downloads.wordpress.org/theme/neve.2.11.6.zip\";s:8:\"requires\";b:0;s:12:\"requires_php\";s:5:\"5.4.0\";}s:7:\"oceanwp\";a:6:{s:5:\"theme\";s:7:\"oceanwp\";s:11:\"new_version\";s:5:\"2.0.8\";s:3:\"url\";s:37:\"https://wordpress.org/themes/oceanwp/\";s:7:\"package\";s:55:\"https://downloads.wordpress.org/theme/oceanwp.2.0.8.zip\";s:8:\"requires\";s:3:\"5.3\";s:12:\"requires_php\";s:3:\"7.2\";}s:10:\"storefront\";a:6:{s:5:\"theme\";s:10:\"storefront\";s:11:\"new_version\";s:5:\"3.7.0\";s:3:\"url\";s:40:\"https://wordpress.org/themes/storefront/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/storefront.3.7.0.zip\";s:8:\"requires\";b:0;s:12:\"requires_php\";s:5:\"5.6.0\";}s:14:\"twentynineteen\";a:6:{s:5:\"theme\";s:14:\"twentynineteen\";s:11:\"new_version\";s:3:\"2.0\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentynineteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentynineteen.2.0.zip\";s:8:\"requires\";s:5:\"4.9.6\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:12:\"twentytwenty\";a:6:{s:5:\"theme\";s:12:\"twentytwenty\";s:11:\"new_version\";s:3:\"1.7\";s:3:\"url\";s:42:\"https://wordpress.org/themes/twentytwenty/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/twentytwenty.1.7.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:15:\"twentytwentyone\";a:6:{s:5:\"theme\";s:15:\"twentytwentyone\";s:11:\"new_version\";s:3:\"1.3\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentyone/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentyone.1.3.zip\";s:8:\"requires\";s:3:\"5.3\";s:12:\"requires_php\";s:3:\"5.6\";}}s:12:\"translations\";a:0:{}}","no"),
("809","_site_transient_ai1wm_last_check_for_updates","1622564072","no"),
("810","ai1wm_updater","a:0:{}","yes"),
("811","_transient_timeout__woocommerce_helper_subscriptions","1622564972","no"),
("812","_transient__woocommerce_helper_subscriptions","a:0:{}","no"),
("816","action_scheduler_migration_status","complete","yes"),
("818","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1622564219;s:7:\"checked\";a:12:{s:53:\"apparelcuts-spreadshirt/spreadshirt-for-wordpress.php\";s:6:\"1.0.16\";s:9:\"hello.php\";s:5:\"1.7.2\";s:63:\"limit-login-attempts-reloaded/limit-login-attempts-reloaded.php\";s:6:\"2.22.1\";s:67:\"mollie-payments-for-woocommerce/mollie-payments-for-woocommerce.php\";s:5:\"6.4.0\";s:55:\"printful-shipping-for-woocommerce/printful-shipping.php\";s:6:\"2.1.23\";s:37:\"printify-for-woocommerce/printify.php\";s:3:\"2.4\";s:43:\"siteground-migrator/siteground-migrator.php\";s:6:\"1.0.27\";s:27:\"woocommerce/woocommerce.php\";s:5:\"5.3.0\";s:67:\"woo-single-page-checkout/rg108-woocommerce-single-page-checkout.php\";s:5:\"1.2.7\";s:51:\"wp-migration-duplicator/wp-migration-duplicator.php\";s:5:\"1.2.2\";s:41:\"woo-smart-wishlist/wpc-smart-wishlist.php\";s:5:\"2.7.0\";s:24:\"wordpress-seo/wp-seo.php\";s:4:\"16.4\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:1:{i:0;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:31:\"mollie-payments-for-woocommerce\";s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"6.4.0\";s:7:\"updated\";s:19:\"2021-05-20 08:36:47\";s:7:\"package\";s:98:\"https://downloads.wordpress.org/translation/plugin/mollie-payments-for-woocommerce/6.4.0/nl_NL.zip\";s:10:\"autoupdate\";b:1;}}s:9:\"no_update\";a:12:{s:53:\"apparelcuts-spreadshirt/spreadshirt-for-wordpress.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:37:\"w.org/plugins/apparelcuts-spreadshirt\";s:4:\"slug\";s:23:\"apparelcuts-spreadshirt\";s:6:\"plugin\";s:53:\"apparelcuts-spreadshirt/spreadshirt-for-wordpress.php\";s:11:\"new_version\";s:6:\"1.0.16\";s:3:\"url\";s:54:\"https://wordpress.org/plugins/apparelcuts-spreadshirt/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/apparelcuts-spreadshirt.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:76:\"https://ps.w.org/apparelcuts-spreadshirt/assets/icon-256x256.jpg?rev=2074413\";s:2:\"1x\";s:76:\"https://ps.w.org/apparelcuts-spreadshirt/assets/icon-256x256.jpg?rev=2074413\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:78:\"https://ps.w.org/apparelcuts-spreadshirt/assets/banner-772x250.jpg?rev=2074413\";}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}}s:63:\"limit-login-attempts-reloaded/limit-login-attempts-reloaded.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:43:\"w.org/plugins/limit-login-attempts-reloaded\";s:4:\"slug\";s:29:\"limit-login-attempts-reloaded\";s:6:\"plugin\";s:63:\"limit-login-attempts-reloaded/limit-login-attempts-reloaded.php\";s:11:\"new_version\";s:6:\"2.22.1\";s:3:\"url\";s:60:\"https://wordpress.org/plugins/limit-login-attempts-reloaded/\";s:7:\"package\";s:79:\"https://downloads.wordpress.org/plugin/limit-login-attempts-reloaded.2.22.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:82:\"https://ps.w.org/limit-login-attempts-reloaded/assets/icon-256x256.png?rev=2456910\";s:2:\"1x\";s:82:\"https://ps.w.org/limit-login-attempts-reloaded/assets/icon-128x128.png?rev=2456910\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:85:\"https://ps.w.org/limit-login-attempts-reloaded/assets/banner-1544x500.png?rev=2456910\";s:2:\"1x\";s:84:\"https://ps.w.org/limit-login-attempts-reloaded/assets/banner-772x250.png?rev=2456910\";}s:11:\"banners_rtl\";a:0:{}}s:67:\"mollie-payments-for-woocommerce/mollie-payments-for-woocommerce.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:45:\"w.org/plugins/mollie-payments-for-woocommerce\";s:4:\"slug\";s:31:\"mollie-payments-for-woocommerce\";s:6:\"plugin\";s:67:\"mollie-payments-for-woocommerce/mollie-payments-for-woocommerce.php\";s:11:\"new_version\";s:5:\"6.4.0\";s:3:\"url\";s:62:\"https://wordpress.org/plugins/mollie-payments-for-woocommerce/\";s:7:\"package\";s:80:\"https://downloads.wordpress.org/plugin/mollie-payments-for-woocommerce.6.4.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:84:\"https://ps.w.org/mollie-payments-for-woocommerce/assets/icon-256x256.png?rev=1955096\";s:2:\"1x\";s:84:\"https://ps.w.org/mollie-payments-for-woocommerce/assets/icon-256x256.png?rev=1955096\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:86:\"https://ps.w.org/mollie-payments-for-woocommerce/assets/banner-772x250.png?rev=1955096\";}s:11:\"banners_rtl\";a:0:{}}s:55:\"printful-shipping-for-woocommerce/printful-shipping.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:47:\"w.org/plugins/printful-shipping-for-woocommerce\";s:4:\"slug\";s:33:\"printful-shipping-for-woocommerce\";s:6:\"plugin\";s:55:\"printful-shipping-for-woocommerce/printful-shipping.php\";s:11:\"new_version\";s:6:\"2.1.23\";s:3:\"url\";s:64:\"https://wordpress.org/plugins/printful-shipping-for-woocommerce/\";s:7:\"package\";s:83:\"https://downloads.wordpress.org/plugin/printful-shipping-for-woocommerce.2.1.23.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:86:\"https://ps.w.org/printful-shipping-for-woocommerce/assets/icon-256x256.png?rev=1067891\";s:2:\"1x\";s:86:\"https://ps.w.org/printful-shipping-for-woocommerce/assets/icon-128x128.png?rev=1067891\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:89:\"https://ps.w.org/printful-shipping-for-woocommerce/assets/banner-1544x500.png?rev=1741557\";s:2:\"1x\";s:88:\"https://ps.w.org/printful-shipping-for-woocommerce/assets/banner-772x250.png?rev=1741557\";}s:11:\"banners_rtl\";a:0:{}}s:37:\"printify-for-woocommerce/printify.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:38:\"w.org/plugins/printify-for-woocommerce\";s:4:\"slug\";s:24:\"printify-for-woocommerce\";s:6:\"plugin\";s:37:\"printify-for-woocommerce/printify.php\";s:11:\"new_version\";s:3:\"2.4\";s:3:\"url\";s:55:\"https://wordpress.org/plugins/printify-for-woocommerce/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/printify-for-woocommerce.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:69:\"https://ps.w.org/printify-for-woocommerce/assets/icon.svg?rev=1732780\";s:3:\"svg\";s:69:\"https://ps.w.org/printify-for-woocommerce/assets/icon.svg?rev=1732780\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:43:\"siteground-migrator/siteground-migrator.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:33:\"w.org/plugins/siteground-migrator\";s:4:\"slug\";s:19:\"siteground-migrator\";s:6:\"plugin\";s:43:\"siteground-migrator/siteground-migrator.php\";s:11:\"new_version\";s:6:\"1.0.27\";s:3:\"url\";s:50:\"https://wordpress.org/plugins/siteground-migrator/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/siteground-migrator.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:72:\"https://ps.w.org/siteground-migrator/assets/icon-256x256.png?rev=2117508\";s:2:\"1x\";s:64:\"https://ps.w.org/siteground-migrator/assets/icon.svg?rev=2124389\";s:3:\"svg\";s:64:\"https://ps.w.org/siteground-migrator/assets/icon.svg?rev=2124389\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/siteground-migrator/assets/banner-1544x500.png?rev=2124375\";s:2:\"1x\";s:74:\"https://ps.w.org/siteground-migrator/assets/banner-772x250.png?rev=2124375\";}s:11:\"banners_rtl\";a:0:{}}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"5.3.0\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.5.3.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=2366418\";s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=2366418\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=2366418\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=2366418\";}s:11:\"banners_rtl\";a:0:{}}s:67:\"woo-single-page-checkout/rg108-woocommerce-single-page-checkout.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:38:\"w.org/plugins/woo-single-page-checkout\";s:4:\"slug\";s:24:\"woo-single-page-checkout\";s:6:\"plugin\";s:67:\"woo-single-page-checkout/rg108-woocommerce-single-page-checkout.php\";s:11:\"new_version\";s:5:\"1.2.7\";s:3:\"url\";s:55:\"https://wordpress.org/plugins/woo-single-page-checkout/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/woo-single-page-checkout.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:77:\"https://ps.w.org/woo-single-page-checkout/assets/icon-256x256.jpg?rev=1851495\";s:2:\"1x\";s:77:\"https://ps.w.org/woo-single-page-checkout/assets/icon-128x128.jpg?rev=1851495\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:79:\"https://ps.w.org/woo-single-page-checkout/assets/banner-772x250.jpg?rev=1851505\";}s:11:\"banners_rtl\";a:0:{}}s:51:\"wp-migration-duplicator/wp-migration-duplicator.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:37:\"w.org/plugins/wp-migration-duplicator\";s:4:\"slug\";s:23:\"wp-migration-duplicator\";s:6:\"plugin\";s:51:\"wp-migration-duplicator/wp-migration-duplicator.php\";s:11:\"new_version\";s:5:\"1.2.2\";s:3:\"url\";s:54:\"https://wordpress.org/plugins/wp-migration-duplicator/\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/plugin/wp-migration-duplicator.1.2.2.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:76:\"https://ps.w.org/wp-migration-duplicator/assets/icon-128x128.jpg?rev=1861802\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:78:\"https://ps.w.org/wp-migration-duplicator/assets/banner-772x250.jpg?rev=2063406\";}s:11:\"banners_rtl\";a:0:{}}s:41:\"woo-smart-wishlist/wpc-smart-wishlist.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:32:\"w.org/plugins/woo-smart-wishlist\";s:4:\"slug\";s:18:\"woo-smart-wishlist\";s:6:\"plugin\";s:41:\"woo-smart-wishlist/wpc-smart-wishlist.php\";s:11:\"new_version\";s:5:\"2.7.0\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/woo-smart-wishlist/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/woo-smart-wishlist.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:71:\"https://ps.w.org/woo-smart-wishlist/assets/icon-128x128.png?rev=1857805\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:73:\"https://ps.w.org/woo-smart-wishlist/assets/banner-772x250.png?rev=2425218\";}s:11:\"banners_rtl\";a:0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:4:\"16.4\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/wordpress-seo.16.4.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=2363699\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=2363699\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=2363699\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}}}}","no"),
("819","wtmigrator_start_date","1622564219","yes"),
("820","wt_mgdp_admin_modules","a:8:{s:6:\"logger\";i:1;s:6:\"export\";i:1;s:6:\"import\";i:1;s:7:\"backups\";i:1;s:18:\"uninstall-feedback\";i:1;s:3:\"ftp\";i:1;s:11:\"googledrive\";i:1;s:2:\"s3\";i:1;}","yes"),
("821","siteground_migrator_is_siteground_env","0","yes"),
("822","siteground_migrator_temp_directory","1622564220-7279eb01760ea5a1cf1a23d6573b2cb659670fc9","yes"),
("823","siteground_migrator_encryption_key","de07d4c0dd1e5eb7cff46a35b9476612810c3bc7","yes");/*END*/




DROP TABLE IF EXISTS `webtoffee_postmeta` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_postmeta VALUES
("1","2","_wp_page_template","default"),
("2","3","_wp_page_template","default"),
("3","5","_wp_attached_file","woocommerce-placeholder.png"),
("4","5","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:27:\"woocommerce-placeholder.png\";s:5:\"sizes\";a:7:{s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-600x600.png\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"woocommerce-placeholder-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}"),
("6","12","_menu_item_type","post_type"),
("7","12","_menu_item_menu_item_parent","0"),
("8","12","_menu_item_object_id","10"),
("9","12","_menu_item_object","page"),
("10","12","_menu_item_target",""),
("11","12","_menu_item_classes","a:1:{i:0;s:0:\"\";}"),
("12","12","_menu_item_xfn",""),
("13","12","_menu_item_url",""),
("15","13","_menu_item_type","post_type"),
("16","13","_menu_item_menu_item_parent","0"),
("17","13","_menu_item_object_id","9"),
("18","13","_menu_item_object","page"),
("19","13","_menu_item_target",""),
("20","13","_menu_item_classes","a:1:{i:0;s:0:\"\";}"),
("21","13","_menu_item_xfn",""),
("22","13","_menu_item_url",""),
("24","14","_menu_item_type","post_type"),
("25","14","_menu_item_menu_item_parent","0"),
("26","14","_menu_item_object_id","8"),
("27","14","_menu_item_object","page"),
("28","14","_menu_item_target",""),
("29","14","_menu_item_classes","a:1:{i:0;s:0:\"\";}"),
("30","14","_menu_item_xfn",""),
("31","14","_menu_item_url",""),
("32","14","_menu_item_orphaned","1619688427"),
("33","15","_menu_item_type","post_type"),
("34","15","_menu_item_menu_item_parent","0"),
("35","15","_menu_item_object_id","7"),
("36","15","_menu_item_object","page"),
("37","15","_menu_item_target",""),
("38","15","_menu_item_classes","a:1:{i:0;s:0:\"\";}"),
("39","15","_menu_item_xfn",""),
("40","15","_menu_item_url",""),
("41","17","_wp_attached_file","2021/06/Disbranded_BG-01.jpg"),
("42","17","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1196;s:6:\"height\";i:1068;s:4:\"file\";s:28:\"2021/06/Disbranded_BG-01.jpg\";s:5:\"sizes\";a:11:{s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"Disbranded_BG-01-300x268.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:268;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:29:\"Disbranded_BG-01-1024x914.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:914;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"Disbranded_BG-01-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:28:\"Disbranded_BG-01-768x686.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:686;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"neve-blog\";a:4:{s:4:\"file\";s:28:\"Disbranded_BG-01-930x620.jpg\";s:5:\"width\";i:930;s:6:\"height\";i:620;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:28:\"Disbranded_BG-01-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:28:\"Disbranded_BG-01-600x536.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:28:\"Disbranded_BG-01-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:28:\"Disbranded_BG-01-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:28:\"Disbranded_BG-01-600x536.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:28:\"Disbranded_BG-01-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}"),
("43","18","_wp_attached_file","2021/06/cropped-Disbranded_BG-01.jpg"),
("44","18","_wp_attachment_context","custom-logo"),
("45","18","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1196;s:6:\"height\";i:298;s:4:\"file\";s:36:\"2021/06/cropped-Disbranded_BG-01.jpg\";s:5:\"sizes\";a:11:{s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"cropped-Disbranded_BG-01-300x75.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"cropped-Disbranded_BG-01-1024x255.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:255;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"cropped-Disbranded_BG-01-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"cropped-Disbranded_BG-01-768x191.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:191;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"neve-blog\";a:4:{s:4:\"file\";s:36:\"cropped-Disbranded_BG-01-930x298.jpg\";s:5:\"width\";i:930;s:6:\"height\";i:298;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"cropped-Disbranded_BG-01-300x298.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:298;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:36:\"cropped-Disbranded_BG-01-600x149.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:149;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"cropped-Disbranded_BG-01-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"cropped-Disbranded_BG-01-300x298.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:298;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:36:\"cropped-Disbranded_BG-01-600x149.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:149;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"cropped-Disbranded_BG-01-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}"),
("47","20","_wp_attached_file","2021/06/Disbranded_BG-02.png"),
("48","20","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2134;s:6:\"height\";i:2134;s:4:\"file\";s:28:\"2021/06/Disbranded_BG-02.png\";s:5:\"sizes\";a:13:{s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"Disbranded_BG-02-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:30:\"Disbranded_BG-02-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"Disbranded_BG-02-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:28:\"Disbranded_BG-02-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:30:\"Disbranded_BG-02-1536x1536.png\";s:5:\"width\";i:1536;s:6:\"height\";i:1536;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:30:\"Disbranded_BG-02-2048x2048.png\";s:5:\"width\";i:2048;s:6:\"height\";i:2048;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"neve-blog\";a:4:{s:4:\"file\";s:28:\"Disbranded_BG-02-930x620.png\";s:5:\"width\";i:930;s:6:\"height\";i:620;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:28:\"Disbranded_BG-02-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:28:\"Disbranded_BG-02-600x600.png\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:28:\"Disbranded_BG-02-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:28:\"Disbranded_BG-02-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:28:\"Disbranded_BG-02-600x600.png\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:28:\"Disbranded_BG-02-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}"),
("49","21","_wp_attached_file","2021/06/cropped-Disbranded_BG-02.png"),
("50","21","_wp_attachment_context","site-icon"),
("51","21","_wp_attachment_metadata","a:5:{s:5:\"width\";i:512;s:6:\"height\";i:512;s:4:\"file\";s:36:\"2021/06/cropped-Disbranded_BG-02.png\";s:5:\"sizes\";a:10:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"cropped-Disbranded_BG-02-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"cropped-Disbranded_BG-02-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"cropped-Disbranded_BG-02-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"cropped-Disbranded_BG-02-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"cropped-Disbranded_BG-02-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"cropped-Disbranded_BG-02-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"site_icon-270\";a:4:{s:4:\"file\";s:36:\"cropped-Disbranded_BG-02-270x270.png\";s:5:\"width\";i:270;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"site_icon-192\";a:4:{s:4:\"file\";s:36:\"cropped-Disbranded_BG-02-192x192.png\";s:5:\"width\";i:192;s:6:\"height\";i:192;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"site_icon-180\";a:4:{s:4:\"file\";s:36:\"cropped-Disbranded_BG-02-180x180.png\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"site_icon-32\";a:4:{s:4:\"file\";s:34:\"cropped-Disbranded_BG-02-32x32.png\";s:5:\"width\";i:32;s:6:\"height\";i:32;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}"),
("52","19","_edit_lock","1622549926:1"),
("53","10","_edit_lock","1622549559:1"),
("54","10","_wp_page_template",""),
("55","10","_edit_last","1"),
("56","10","_yoast_wpseo_estimated-reading-time-minutes","1"),
("57","10","neve_meta_sidebar","full-width"),
("58","10","neve_meta_container","full-width"),
("59","10","neve_meta_title_alignment","center"),
("60","10","neve_meta_disable_title","on"),
("61","10","neve_meta_enable_content_width","on"),
("62","10","neve_meta_content_width","75"),
("63","10","_yoast_wpseo_content_score","30"),
("64","7","_edit_lock","1622549684:1"),
("65","7","neve_meta_sidebar","full-width"),
("66","7","neve_meta_enable_content_width","on"),
("67","7","neve_meta_content_width","75"),
("68","7","neve_meta_title_alignment","center"),
("69","7","neve_meta_disable_title","off"),
("70","7","_edit_last","1"),
("71","7","_yoast_wpseo_content_score","30"),
("72","7","_yoast_wpseo_estimated-reading-time-minutes","1"),
("73","6","_edit_lock","1622550560:1"),
("74","6","neve_meta_sidebar","full-width"),
("75","6","neve_meta_title_alignment","center"),
("76","6","neve_meta_disable_title","off"),
("77","6","_edit_last","1"),
("78","6","_yoast_wpseo_estimated-reading-time-minutes","1"),
("79","6","neve_meta_container","full-width"),
("80","6","neve_meta_enable_content_width","on"),
("81","6","neve_meta_content_width","95"),
("82","6","_yoast_wpseo_content_score","90"),
("83","19","_wp_trash_meta_status","publish"),
("84","19","_wp_trash_meta_time","1622549978"),
("85","34","_wp_attached_file","2021/06/DISBRANDE-X-Happycheftv.jpg"),
("86","34","_wp_attachment_metadata","a:5:{s:5:\"width\";i:565;s:6:\"height\";i:284;s:4:\"file\";s:35:\"2021/06/DISBRANDE-X-Happycheftv.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"DISBRANDE-X-Happycheftv-300x151.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:151;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"DISBRANDE-X-Happycheftv-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:35:\"DISBRANDE-X-Happycheftv-300x284.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:284;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:35:\"DISBRANDE-X-Happycheftv-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:35:\"DISBRANDE-X-Happycheftv-300x284.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:284;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:35:\"DISBRANDE-X-Happycheftv-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");/*END*/




DROP TABLE IF EXISTS `webtoffee_posts` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_posts VALUES
("1","1","2021-04-29 08:54:41","2021-04-29 08:54:41","<!-- wp:paragraph -->
<p>Welkom bij WordPress. Dit is je eerste bericht. Bewerk of verwijder het, start dan met schrijven!</p>
<!-- /wp:paragraph -->","Hallo wereld!","","publish","open","open","","hallo-wereld","","","2021-04-29 08:54:41","2021-04-29 08:54:41","","0","http://localhost:8888/?p=1","0","post","","1"),
("2","1","2021-04-29 08:54:41","2021-04-29 08:54:41","<!-- wp:paragraph -->
<p>Dit is een voorbeeldpagina. Het is anders dan een blog bericht omdat het op één plek blijft en tevoorschijn komt in je site navigatie (in de meeste thema\'s). De meeste mensen starten met een Over pagina dat hen voorstelt aan potentiële site bezoekers. Het zou iets als dit kunnen zeggen:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren, en dit is mijn site. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik hou van pi&#241;a coladas. (En overvallen worden door de regen.)</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>...of zoiets als dit:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>De XYZ Doohickey Company is opgericht in 1971 en heeft sindsdien kwalitatieve doohickeys aan het publiek geleverd. Gevestigd in Gotham City, heeft XYZ meer dan 2000 mensen in dienst en doet allerlei fantastische dingen voor de community in Gotham.</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>Als nieuwe WordPress gebruiker kan je naar <a href=\"http://localhost:8888/wp-admin/\">je dashboard</a> gaan om deze pagina te verwijderen en nieuwe pagina\'s toe te voegen voor je inhoud. Veel plezier!</p>
<!-- /wp:paragraph -->","Voorbeeld pagina","","publish","closed","open","","voorbeeld-pagina","","","2021-04-29 08:54:41","2021-04-29 08:54:41","","0","http://localhost:8888/?page_id=2","0","page","","0"),
("3","1","2021-04-29 08:54:41","2021-04-29 08:54:41","<!-- wp:heading --><h2>Wie zijn we</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Voorgestelde tekst: </strong>Ons site-adres is: http://localhost:8888.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Reacties</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Voorgestelde tekst: </strong>Als bezoekers reacties achterlaten op de site, verzamelen we de gegevens getoond in het reactieformulier, het IP-adres van de bezoeker en de browser user agent om te helpen spam te detecteren.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Een geanonimiseerde string, gemaakt op basis van je e-mailadres (dit wordt ook een hash genoemd) kan worden gestuurd naar de Gravatar service indien je dit gebruikt. De privacybeleidspagina kun je hier vinden: https://automattic.com/privacy/. Nadat je reactie is goedgekeurd, is je profielfoto publiekelijk zichtbaar in de context van je reactie.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Voorgestelde tekst: </strong>Als je een geregistreerde gebruiker bent en afbeeldingen naar de site upload, moet je voorkomen dat je afbeeldingen uploadt met daarin EXIF GPS locatie gegevens. Bezoekers van de site kunnen de afbeeldingen van de site downloaden en de locatiegegevens inzien.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Voorgestelde tekst: </strong>Wanneer je een reactie achterlaat op onze site, kun je aangeven of je naam, je e-mailadres en site in een cookie opgeslagen mogen worden. Dit doen we voor je gemak zodat je deze gegevens niet opnieuw hoeft in te vullen voor een nieuwe reactie. Deze cookies zijn een jaar lang geldig. </p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Indien je onze inlogpagina bezoekt, slaan we een tijdelijke cookie op om te controleren of je browser cookies accepteert. Deze cookie bevat geen persoonlijke gegevens en wordt verwijderd zodra je je browser sluit.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Zodra je inlogt, zullen we enkele cookies bewaren in verband met jouw login informatie en schermweergave opties. Login cookies zijn 2 dagen geldig en cookies voor schermweergave opties 1 jaar. Als je &quot;Herinner mij&quot; selecteert, wordt je login 2 weken bewaard. Zodra je uitlogt van jouw account, worden login cookies verwijderd.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Wanneer je een bericht wijzigt of publiceert wordt een aanvullende cookie door je browser opgeslagen. Deze cookie bevat geen persoonlijke data en heeft enkel het post ID van het artikel wat je hebt bewerkt in zich. Deze cookie is na een dag verlopen.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Ingesloten inhoud van andere sites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Voorgestelde tekst: </strong>Berichten op deze site kunnen ingesloten (embedded) inhoud bevatten (bijvoorbeeld video\'s, afbeeldingen, berichten, etc.). Ingesloten inhoud van andere sites gedraagt zich exact hetzelfde alsof de bezoeker deze andere site heeft bezocht.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Deze sites kunnen gegevens over je verzamelen, cookies gebruiken, extra tracking van derde partijen insluiten en je interactie met deze ingesloten inhoud monitoren, inclusief het vastleggen van de interactie met ingesloten inhoud als je een account hebt en ingelogd bent op die site.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Met wie we jouw gegevens delen</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Voorgestelde tekst: </strong>Als je een wachtwoord reset aanvraagt, wordt je IP-adres opgenomen in de reset e-mail.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Hoe lang we jouw gegevens bewaren</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Voorgestelde tekst: </strong>Wanneer je een reactie achterlaat dan wordt die reactie en de metadata van die reactie voor altijd bewaard. Op deze manier kunnen we vervolgreacties automatisch herkennen en goedkeuren in plaats van dat we ze moeten modereren.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Voor gebruikers die zich op onze site registreren (indien aanwezig), slaan we ook de persoonlijke informatie op die ze verstrekken in hun gebruikersprofiel. Alle gebruikers kunnen op ieder moment hun persoonlijke informatie bekijken, bewerken of verwijderen (behalve dat ze hun gebruikersnaam niet kunnen wijzigen). Site beheerders kunnen deze informatie ook bekijken en bewerken.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Welke rechten je hebt over je gegevens</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Voorgestelde tekst: </strong>Als je een account hebt op deze site of je hebt reacties achter gelaten, kan je verzoeken om een exportbestand van je persoonlijke gegevens die we van je hebben, inclusief alle gegevens die je ons opgegeven hebt. Je kan ook verzoeken dat we alle persoonlijke gegevens die we van je hebben wissen. Dit bevat geen gegevens die we verplicht moeten bewaren in verband met administratieve, wettelijke of beveiligings doeleinden.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Waar we jouw gegevens naartoe sturen</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Voorgestelde tekst: </strong>Mogelijk worden reacties van bezoekers gecontroleerd via een geautomatiseerde spamdetectie service.</p><!-- /wp:paragraph -->","Privacybeleid","","draft","closed","open","","privacybeleid","","","2021-04-29 08:54:41","2021-04-29 08:54:41","","0","http://localhost:8888/?page_id=3","0","page","","0"),
("5","1","2021-04-29 09:03:15","2021-04-29 09:03:15","","woocommerce-placeholder","","inherit","open","closed","","woocommerce-placeholder","","","2021-04-29 09:03:15","2021-04-29 09:03:15","","0","http://localhost:8888/wp-content/uploads/2021/04/woocommerce-placeholder.png","0","attachment","image/png","0"),
("6","1","2021-04-29 09:03:16","2021-04-29 09:03:16","<!-- wp:woocommerce/handpicked-products /-->

<!-- wp:columns -->
<div class=\"wp-block-columns\"></div>
<!-- /wp:columns -->

<!-- wp:media-text {\"mediaId\":34,\"mediaLink\":\"http://localhost:8888/winkel/disbrande-x-happycheftv/\",\"mediaType\":\"image\",\"mediaWidth\":36} -->
<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\" style=\"grid-template-columns:36% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost:8888/wp-content/uploads/2021/06/DISBRANDE-X-Happycheftv.jpg\" alt=\"\" class=\"wp-image-34 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":1} -->
<h1><strong>DISBRANDED X HAPPYCHEFtv</strong></h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Check out our amazing collab with the 1 and only <strong><a href=\"https://www.twitch.tv/happycheftv\">Happychef</a>,</strong> A lot of love from us to the <strong>FoodieFam</strong><br><strong>Happychef</strong> his socials:<br><strong><a href=\"https://www.twitch.tv/happycheftv\">Twitch</a>, <a href=\"https://discord.gg/gFSeRk5\">Discord</a>, <a href=\"https://twitter.com/happycheftv\">Twitter</a>, <a href=\"https://www.facebook.com/happycheftv\">Facebook</a><a href=\"https://www.instagram.com/happycheftv/\">, Instagram</a><a href=\"https://www.youtube.com/channel/UCUwkd0hqMVYFTL_GyOMxwQQ\">,</a><a href=\"https://www.youtube.com/channel/UCUwkd0hqMVYFTL_GyOMxwQQ\" target=\"_blank\" rel=\"noreferrer noopener\"> </a><a href=\"https://www.youtube.com/channel/UCUwkd0hqMVYFTL_GyOMxwQQ\"><em>Youtube</em></a></strong></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:woocommerce/featured-product /-->

<!-- wp:woocommerce/product-top-rated {\"categories\":[],\"contentVisibility\":{\"title\":true,\"price\":true,\"rating\":true,\"button\":true}} /-->

<!-- wp:woocommerce/featured-category /-->

<!-- wp:woocommerce/product-best-sellers {\"categories\":[],\"contentVisibility\":{\"title\":true,\"price\":true,\"rating\":true,\"button\":true}} /-->","Winkel","","publish","closed","closed","","winkel","","","2021-06-01 12:28:21","2021-06-01 12:28:21","","0","http://localhost:8888/winkel/","0","page","","0"),
("7","1","2021-04-29 09:03:16","2021-04-29 09:03:16","<!-- wp:shortcode -->
[woocommerce_cart]
<!-- /wp:shortcode -->","Winkelmand","","publish","closed","closed","","winkelwagen","","","2021-06-01 12:14:43","2021-06-01 12:14:43","","0","http://localhost:8888/winkelwagen/","0","page","","0"),
("8","1","2021-04-29 09:03:16","2021-04-29 09:03:16","<!-- wp:shortcode -->[woocommerce_checkout]<!-- /wp:shortcode -->","Afrekenen","","publish","closed","closed","","afrekenen","","","2021-04-29 09:03:16","2021-04-29 09:03:16","","0","http://localhost:8888/afrekenen/","0","page","","0"),
("9","1","2021-04-29 09:03:16","2021-04-29 09:03:16","<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->","Mijn account","","publish","closed","closed","","mijn-account","","","2021-04-29 09:03:16","2021-04-29 09:03:16","","0","http://localhost:8888/mijn-account/","0","page","","0"),
("10","1","2021-04-29 09:03:19","2021-04-29 09:03:19","<!-- wp:spacer -->
<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph -->
<p>[woosw_list]</p>
<!-- /wp:paragraph -->","Wishlist","","publish","closed","closed","","wishlist","","","2021-06-01 12:12:36","2021-06-01 12:12:36","","0","http://localhost:8888/wishlist/","0","page","","0"),
("12","1","2021-04-29 09:27:56","2021-04-29 09:27:47"," ","","","publish","closed","closed","","12","","","2021-04-29 09:27:56","2021-04-29 09:27:56","","0","http://localhost:8888/?p=12","3","nav_menu_item","","0"),
("13","1","2021-04-29 09:27:56","2021-04-29 09:27:47"," ","","","publish","closed","closed","","13","","","2021-04-29 09:27:56","2021-04-29 09:27:56","","0","http://localhost:8888/?p=13","1","nav_menu_item","","0"),
("14","1","2021-04-29 09:27:07","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2021-04-29 09:27:07","0000-00-00 00:00:00","","0","http://localhost:8888/?p=14","1","nav_menu_item","","0"),
("15","1","2021-04-29 09:27:56","2021-04-29 09:27:47"," ","","","publish","closed","closed","","15","","","2021-04-29 09:27:56","2021-04-29 09:27:56","","0","http://localhost:8888/?p=15","2","nav_menu_item","","0"),
("16","1","2021-06-01 10:38:52","0000-00-00 00:00:00","","Automatische concepten","","auto-draft","open","open","","","","","2021-06-01 10:38:52","0000-00-00 00:00:00","","0","http://localhost:8888/?p=16","0","post","","0"),
("17","1","2021-06-01 10:42:08","2021-06-01 10:42:08","","Disbranded_BG-01","","inherit","open","closed","","disbranded_bg-01","","","2021-06-01 10:42:08","2021-06-01 10:42:08","","0","http://localhost:8888/wp-content/uploads/2021/06/Disbranded_BG-01.jpg","0","attachment","image/jpeg","0"),
("18","1","2021-06-01 10:42:13","2021-06-01 10:42:13","http://localhost:8888/wp-content/uploads/2021/06/cropped-Disbranded_BG-01.jpg","cropped-Disbranded_BG-01.jpg","","inherit","open","closed","","cropped-disbranded_bg-01-jpg","","","2021-06-01 10:42:13","2021-06-01 10:42:13","","0","http://localhost:8888/wp-content/uploads/2021/06/cropped-Disbranded_BG-01.jpg","0","attachment","image/jpeg","0"),
("19","1","2021-06-01 12:19:38","2021-06-01 12:19:38","{
    \"neve::custom_logo\": {
        \"value\": 18,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:42:33\"
    },
    \"neve::logo_show_tagline\": {
        \"value\": 0,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 12:19:38\"
    },
    \"neve::logo_show_title\": {
        \"value\": 0,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 12:19:38\"
    },
    \"neve::logo_max_width\": {
        \"value\": \"{\\\"mobile\\\":120,\\\"tablet\\\":204,\\\"desktop\\\":229}\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 12:19:38\"
    },
    \"neve::hfg_header_layout_main_background\": {
        \"value\": {
            \"type\": \"image\",
            \"imageUrl\": \"\",
            \"focusPoint\": {
                \"x\": 0.5,
                \"y\": 0.5
            },
            \"colorValue\": \"var(--nv-site-bg)\",
            \"overlayColorValue\": \"\",
            \"overlayOpacity\": 50,
            \"fixed\": false,
            \"useFeatured\": false
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:42:33\"
    },
    \"site_icon\": {
        \"value\": 21,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:43:33\"
    },
    \"neve::hfg_header_layout\": {
        \"value\": \"{\\\"desktop\\\":{\\\"top\\\":[],\\\"main\\\":[{\\\"x\\\":0,\\\"y\\\":1,\\\"width\\\":4,\\\"height\\\":1,\\\"id\\\":\\\"logo\\\"},{\\\"x\\\":4,\\\"y\\\":1,\\\"width\\\":8,\\\"height\\\":1,\\\"id\\\":\\\"primary-menu\\\"}],\\\"bottom\\\":[]},\\\"mobile\\\":{\\\"top\\\":[{\\\"x\\\":0,\\\"y\\\":1,\\\"width\\\":8,\\\"height\\\":1,\\\"id\\\":\\\"logo\\\"},{\\\"x\\\":8,\\\"y\\\":1,\\\"width\\\":4,\\\"height\\\":1,\\\"id\\\":\\\"nav-icon\\\"}],\\\"main\\\":[],\\\"bottom\\\":[],\\\"sidebar\\\":[{\\\"x\\\":0,\\\"y\\\":1,\\\"width\\\":8,\\\"height\\\":1,\\\"id\\\":\\\"primary-menu\\\"}]}}\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:52:33\"
    },
    \"neve::header_cart_icon_component_padding\": {
        \"value\": {
            \"mobile\": {
                \"top\": 0,
                \"right\": 10,
                \"bottom\": 0,
                \"left\": 10
            },
            \"tablet\": {
                \"top\": \"0\",
                \"right\": \"10\",
                \"bottom\": \"8\",
                \"left\": \"39\"
            },
            \"desktop\": {
                \"top\": 0,
                \"right\": 10,
                \"bottom\": 0,
                \"left\": 10
            },
            \"mobile-unit\": \"px\",
            \"tablet-unit\": \"px\",
            \"desktop-unit\": \"px\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:50:33\"
    },
    \"neve::logo_component_align\": {
        \"value\": {
            \"mobile\": \"right\",
            \"tablet\": \"right\",
            \"desktop\": \"left\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:52:33\"
    },
    \"neve::header_cart_icon_component_align\": {
        \"value\": {
            \"desktop\": \"left\",
            \"tablet\": \"left\",
            \"mobile\": \"left\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:50:33\"
    },
    \"neve::logo_component_padding\": {
        \"value\": {
            \"mobile\": {
                \"top\": 10,
                \"right\": 0,
                \"bottom\": 10,
                \"left\": 0
            },
            \"tablet\": {
                \"top\": \"10\",
                \"right\": 0,
                \"bottom\": \"2\",
                \"left\": 0
            },
            \"desktop\": {
                \"top\": 10,
                \"right\": 0,
                \"bottom\": 10,
                \"left\": 0
            },
            \"mobile-unit\": \"px\",
            \"tablet-unit\": \"px\",
            \"desktop-unit\": \"px\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:47:33\"
    },
    \"neve::nav-icon_component_padding\": {
        \"value\": {
            \"mobile\": {
                \"top\": 10,
                \"right\": 15,
                \"bottom\": 10,
                \"left\": 15
            },
            \"tablet\": {
                \"top\": 10,
                \"right\": 15,
                \"bottom\": 10,
                \"left\": 15
            },
            \"desktop\": {
                \"top\": 10,
                \"right\": 15,
                \"bottom\": 10,
                \"left\": 15
            },
            \"mobile-unit\": \"px\",
            \"tablet-unit\": \"px\",
            \"desktop-unit\": \"px\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:52:33\"
    },
    \"neve::nav-icon_component_margin\": {
        \"value\": {
            \"mobile\": {
                \"top\": 0,
                \"right\": 0,
                \"bottom\": 0,
                \"left\": 0
            },
            \"tablet\": {
                \"top\": \"10\",
                \"right\": \"10\",
                \"bottom\": \"10\",
                \"left\": \"10\"
            },
            \"desktop\": {
                \"top\": 0,
                \"right\": 0,
                \"bottom\": 0,
                \"left\": 0
            },
            \"mobile-unit\": \"px\",
            \"tablet-unit\": \"px\",
            \"desktop-unit\": \"px\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:49:33\"
    },
    \"neve::logo_component_margin\": {
        \"value\": {
            \"mobile\": {
                \"top\": 0,
                \"right\": 0,
                \"bottom\": 0,
                \"left\": 0
            },
            \"tablet\": {
                \"top\": \"3\",
                \"right\": \"3\",
                \"bottom\": \"3\",
                \"left\": \"3\"
            },
            \"desktop\": {
                \"top\": 0,
                \"right\": 0,
                \"bottom\": 0,
                \"left\": 0
            },
            \"mobile-unit\": \"px\",
            \"tablet-unit\": \"px\",
            \"desktop-unit\": \"px\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:48:33\"
    },
    \"neve::nav-icon_component_align\": {
        \"value\": {
            \"mobile\": \"right\",
            \"tablet\": \"right\",
            \"desktop\": \"right\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:49:33\"
    },
    \"neve::header_cart_icon_component_margin\": {
        \"value\": {
            \"mobile\": {
                \"top\": 0,
                \"right\": 0,
                \"bottom\": 0,
                \"left\": 0
            },
            \"tablet\": {
                \"top\": \"1\",
                \"right\": \"1\",
                \"bottom\": \"1\",
                \"left\": \"1\"
            },
            \"desktop\": {
                \"top\": 0,
                \"right\": 0,
                \"bottom\": 0,
                \"left\": 0
            },
            \"mobile-unit\": \"px\",
            \"tablet-unit\": \"px\",
            \"desktop-unit\": \"px\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:50:33\"
    },
    \"neve::header_search_responsive_open_type\": {
        \"value\": \"minimal\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:50:33\"
    },
    \"neve::header_search_responsive_component_align\": {
        \"value\": {
            \"desktop\": \"left\",
            \"tablet\": \"right\",
            \"mobile\": \"left\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:50:33\"
    },
    \"neve::header_search_responsive_component_padding\": {
        \"value\": {
            \"mobile\": {
                \"top\": 0,
                \"right\": 10,
                \"bottom\": 0,
                \"left\": 10
            },
            \"tablet\": {
                \"top\": 0,
                \"right\": \"10\",
                \"bottom\": 0,
                \"left\": \"30\"
            },
            \"desktop\": {
                \"top\": 0,
                \"right\": 10,
                \"bottom\": 0,
                \"left\": 10
            },
            \"mobile-unit\": \"px\",
            \"tablet-unit\": \"px\",
            \"desktop-unit\": \"px\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:51:33\"
    },
    \"neve::header_search_responsive_component_margin\": {
        \"value\": {
            \"mobile\": {
                \"top\": 0,
                \"right\": 0,
                \"bottom\": 0,
                \"left\": 0
            },
            \"tablet\": {
                \"top\": \"5\",
                \"right\": \"5\",
                \"bottom\": \"5\",
                \"left\": \"5\"
            },
            \"desktop\": {
                \"top\": 0,
                \"right\": 0,
                \"bottom\": 0,
                \"left\": 0
            },
            \"mobile-unit\": \"px\",
            \"tablet-unit\": \"px\",
            \"desktop-unit\": \"px\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:50:33\"
    },
    \"sidebars_widgets[blog-sidebar]\": {
        \"value\": [],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:51:33\"
    },
    \"neve::hfg_footer_layout\": {
        \"value\": \"{\\\"desktop\\\":{\\\"top\\\":[],\\\"bottom\\\":[{\\\"x\\\":0,\\\"y\\\":1,\\\"width\\\":12,\\\"height\\\":1,\\\"id\\\":\\\"footer_copyright\\\"}]}}\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:54:33\"
    },
    \"neve::hfg_footer_layout_bottom_layout\": {
        \"value\": \"layout-fullwidth\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:52:33\"
    },
    \"neve::footer_copyright_content\": {
        \"value\": \"<p>Design by <a href=\\\"http://streatsdesign.com\\\" rel=\\\"nofollow\\\">StreatsDesign</a></p>\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:55:33\"
    },
    \"neve::hfg_footer_layout_bottom_background\": {
        \"value\": {
            \"type\": \"color\",
            \"imageUrl\": \"\",
            \"focusPoint\": {
                \"x\": 0.5,
                \"y\": 0.5
            },
            \"colorValue\": \"#000000\",
            \"overlayColorValue\": \"\",
            \"overlayOpacity\": 50,
            \"fixed\": false,
            \"useFeatured\": false
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:55:33\"
    },
    \"neve::hfg_footer_layout_bottom_new_text_color\": {
        \"value\": \"#ffffff\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:55:33\"
    },
    \"sidebars_widgets[shop-sidebar]\": {
        \"value\": [],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:56:33\"
    },
    \"woocommerce_checkout_address_2_field\": {
        \"value\": \"optional\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:56:33\"
    },
    \"neve::neve_form_fields_spacing\": {
        \"value\": 3,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:58:33\"
    },
    \"neve::neve_form_fields_padding\": {
        \"value\": {
            \"top\": \"2\",
            \"right\": \"12\",
            \"bottom\": \"7\",
            \"left\": \"8\",
            \"unit\": \"px\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:58:33\"
    },
    \"neve::neve_form_fields_border_width\": {
        \"value\": {
            \"top\": \"0\",
            \"right\": \"1\",
            \"left\": \"1\",
            \"bottom\": \"1\",
            \"unit\": \"px\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:58:33\"
    },
    \"neve::neve_form_fields_border_radius\": {
        \"value\": {
            \"top\": \"5\",
            \"right\": \"5\",
            \"left\": \"5\",
            \"bottom\": \"5\",
            \"unit\": \"px\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:58:33\"
    },
    \"neve::neve_label_spacing\": {
        \"value\": 11,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:58:33\"
    },
    \"neve::neve_form_button_type\": {
        \"value\": \"secondary\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:57:33\"
    },
    \"neve::neve_label_typeface\": {
        \"value\": {
            \"textTransform\": \"capitalize\",
            \"flag\": true,
            \"lineHeight\": {
                \"suffix\": {
                    \"mobile\": \"em\",
                    \"tablet\": \"em\",
                    \"desktop\": \"em\"
                },
                \"mobile\": \"\",
                \"tablet\": \"\",
                \"desktop\": \"\"
            }
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:58:33\"
    },
    \"neve::neve_button_appearance\": {
        \"value\": {
            \"borderRadius\": {
                \"top\": 3,
                \"right\": 3,
                \"bottom\": 3,
                \"left\": 3
            },
            \"borderWidth\": {
                \"top\": 1,
                \"right\": 1,
                \"bottom\": 1,
                \"left\": 1
            },
            \"type\": \"fill\",
            \"background\": \"rgba(0, 0, 0, 0)\",
            \"backgroundHover\": \"#ffffff\",
            \"text\": \"#000000\",
            \"textHover\": \"#000000\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:59:33\"
    },
    \"neve::neve_button_padding\": {
        \"value\": {
            \"mobile\": {
                \"top\": \"5\",
                \"right\": 12,
                \"bottom\": 8,
                \"left\": 12
            },
            \"tablet\": {
                \"top\": 8,
                \"right\": 12,
                \"bottom\": 8,
                \"left\": 12
            },
            \"desktop\": {
                \"top\": 8,
                \"right\": 12,
                \"bottom\": 8,
                \"left\": 12
            },
            \"mobile-unit\": \"px\",
            \"tablet-unit\": \"px\",
            \"desktop-unit\": \"px\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:59:45\"
    },
    \"neve::neve_button_typeface\": {
        \"value\": {
            \"textTransform\": \"uppercase\",
            \"flag\": false,
            \"lineHeight\": {
                \"suffix\": {
                    \"mobile\": \"em\",
                    \"tablet\": \"em\",
                    \"desktop\": \"em\"
                },
                \"mobile\": 1.6,
                \"tablet\": 1.6,
                \"desktop\": 1.6
            }
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-01 10:59:33\"
    }
}","","","trash","closed","closed","","e99f6403-aa61-40db-ac43-3d52a48a4b91","","","2021-06-01 12:19:38","2021-06-01 12:19:38","","0","http://localhost:8888/?p=19","0","customize_changeset","","0"),
("20","1","2021-06-01 10:42:45","2021-06-01 10:42:45","","Disbranded_BG-02","","inherit","open","closed","","disbranded_bg-02","","","2021-06-01 10:42:45","2021-06-01 10:42:45","","0","http://localhost:8888/wp-content/uploads/2021/06/Disbranded_BG-02.png","0","attachment","image/png","0"),
("21","1","2021-06-01 10:42:53","2021-06-01 10:42:53","http://localhost:8888/wp-content/uploads/2021/06/cropped-Disbranded_BG-02.png","cropped-Disbranded_BG-02.png","","inherit","open","closed","","cropped-disbranded_bg-02-png","","","2021-06-01 10:42:53","2021-06-01 10:42:53","","0","http://localhost:8888/wp-content/uploads/2021/06/cropped-Disbranded_BG-02.png","0","attachment","image/png","0"),
("22","1","2021-06-01 12:07:36","2021-06-01 12:07:36","[woosw_list]","Wishlist","","inherit","closed","closed","","10-revision-v1","","","2021-06-01 12:07:36","2021-06-01 12:07:36","","10","http://localhost:8888/?p=22","0","revision","","0"),
("25","1","2021-06-01 12:10:30","2021-06-01 12:10:30","<!-- wp:spacer -->
<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph -->
<p>[woo{\"type\":\"inserter\",\"blocks\":[{\"clientId\":\"2afb6464-7d6c-48de-bfcf-07e5f6bbf927\",\"name\":\"core/spacer\",\"isValid\":true,\"attributes\":{\"height\":100},\"innerBlocks\":[]}]}sw_list]</p>
<!-- /wp:paragraph -->","Wishlist","","inherit","closed","closed","","10-revision-v1","","","2021-06-01 12:10:30","2021-06-01 12:10:30","","10","http://localhost:8888/?p=25","0","revision","","0"),
("27","1","2021-06-01 12:12:09","2021-06-01 12:12:09","<!-- wp:spacer -->
<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph -->
<p>[woosw_list]</p>
<!-- /wp:paragraph -->","Wishlist","","inherit","closed","closed","","10-revision-v1","","","2021-06-01 12:12:09","2021-06-01 12:12:09","","10","http://localhost:8888/?p=27","0","revision","","0"),
("28","1","2021-06-01 12:13:26","2021-06-01 12:13:26","<!-- wp:shortcode -->
[woocommerce_cart]
<!-- /wp:shortcode -->","Winkelmand","","inherit","closed","closed","","7-revision-v1","","","2021-06-01 12:13:26","2021-06-01 12:13:26","","7","http://localhost:8888/?p=28","0","revision","","0"),
("29","1","2021-06-01 12:15:16","2021-06-01 12:15:16","","Winkel","","inherit","closed","closed","","6-revision-v1","","","2021-06-01 12:15:16","2021-06-01 12:15:16","","6","http://localhost:8888/?p=29","0","revision","","0"),
("31","1","2021-06-01 12:17:43","2021-06-01 12:17:43","<!-- wp:woocommerce/handpicked-products /-->

<!-- wp:spacer {\"height\":113} -->
<div style=\"height:113px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer -->

<!-- wp:woocommerce/featured-product /-->

<!-- wp:media-text -->
<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\"><figure class=\"wp-block-media-text__media\"></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"placeholder\":\"Inhoud...\",\"fontSize\":\"large\"} -->
<p class=\"has-large-font-size\"></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:woocommerce/featured-product /-->

<!-- wp:woocommerce/product-top-rated {\"categories\":[],\"contentVisibility\":{\"title\":true,\"price\":true,\"rating\":true,\"button\":true}} /-->

<!-- wp:woocommerce/featured-category /-->

<!-- wp:woocommerce/product-best-sellers {\"categories\":[],\"contentVisibility\":{\"title\":true,\"price\":true,\"rating\":true,\"button\":true}} /-->","Winkel","","inherit","closed","closed","","6-revision-v1","","","2021-06-01 12:17:43","2021-06-01 12:17:43","","6","http://localhost:8888/?p=31","0","revision","","0"),
("34","1","2021-06-01 12:23:22","2021-06-01 12:23:22","","DISBRANDE-X-Happycheftv","","inherit","open","closed","","disbrande-x-happycheftv","","","2021-06-01 12:23:22","2021-06-01 12:23:22","","6","http://localhost:8888/wp-content/uploads/2021/06/DISBRANDE-X-Happycheftv.jpg","0","attachment","image/jpeg","0"),
("35","1","2021-06-01 12:26:26","2021-06-01 12:26:26","<!-- wp:woocommerce/handpicked-products /-->

<!-- wp:spacer {\"height\":113} -->
<div style=\"height:113px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer -->

<!-- wp:woocommerce/featured-product /-->

<!-- wp:media-text {\"mediaId\":34,\"mediaLink\":\"http://localhost:8888/winkel/disbrande-x-happycheftv/\",\"mediaType\":\"image\",\"mediaWidth\":36} -->
<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\" style=\"grid-template-columns:36% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost:8888/wp-content/uploads/2021/06/DISBRANDE-X-Happycheftv.jpg\" alt=\"\" class=\"wp-image-34 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":1} -->
<h1><strong>DISBRANDED X HAPPYCHEFtv</strong></h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Check out our amazing collab with the 1 and only <strong><a href=\"https://www.twitch.tv/happycheftv\">Happychef</a>,</strong> A lot of love from us to the <strong>FoodieFam</strong><br><strong>Happychef</strong> his socials:<br><strong><a href=\"https://www.twitch.tv/happycheftv\">Twitch</a>, <a href=\"https://discord.gg/gFSeRk5\">Discord</a>, <a href=\"https://twitter.com/happycheftv\">Twitter</a>, <a href=\"https://www.facebook.com/happycheftv\">Facebook</a><a href=\"https://www.instagram.com/happycheftv/\">, Instagram</a><a href=\"https://www.youtube.com/channel/UCUwkd0hqMVYFTL_GyOMxwQQ\">,</a><a href=\"https://www.youtube.com/channel/UCUwkd0hqMVYFTL_GyOMxwQQ\" target=\"_blank\" rel=\"noreferrer noopener\"> </a><a href=\"https://www.youtube.com/channel/UCUwkd0hqMVYFTL_GyOMxwQQ\"><em>Youtube</em></a></strong></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:woocommerce/featured-product /-->

<!-- wp:woocommerce/product-top-rated {\"categories\":[],\"contentVisibility\":{\"title\":true,\"price\":true,\"rating\":true,\"button\":true}} /-->

<!-- wp:woocommerce/featured-category /-->

<!-- wp:woocommerce/product-best-sellers {\"categories\":[],\"contentVisibility\":{\"title\":true,\"price\":true,\"rating\":true,\"button\":true}} /-->","Winkel","","inherit","closed","closed","","6-revision-v1","","","2021-06-01 12:26:26","2021-06-01 12:26:26","","6","http://localhost:8888/?p=35","0","revision","","0"),
("37","1","2021-06-01 12:28:20","2021-06-01 12:28:20","<!-- wp:woocommerce/handpicked-products /-->

<!-- wp:columns -->
<div class=\"wp-block-columns\"></div>
<!-- /wp:columns -->

<!-- wp:media-text {\"mediaId\":34,\"mediaLink\":\"http://localhost:8888/winkel/disbrande-x-happycheftv/\",\"mediaType\":\"image\",\"mediaWidth\":36} -->
<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\" style=\"grid-template-columns:36% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost:8888/wp-content/uploads/2021/06/DISBRANDE-X-Happycheftv.jpg\" alt=\"\" class=\"wp-image-34 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":1} -->
<h1><strong>DISBRANDED X HAPPYCHEFtv</strong></h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Check out our amazing collab with the 1 and only <strong><a href=\"https://www.twitch.tv/happycheftv\">Happychef</a>,</strong> A lot of love from us to the <strong>FoodieFam</strong><br><strong>Happychef</strong> his socials:<br><strong><a href=\"https://www.twitch.tv/happycheftv\">Twitch</a>, <a href=\"https://discord.gg/gFSeRk5\">Discord</a>, <a href=\"https://twitter.com/happycheftv\">Twitter</a>, <a href=\"https://www.facebook.com/happycheftv\">Facebook</a><a href=\"https://www.instagram.com/happycheftv/\">, Instagram</a><a href=\"https://www.youtube.com/channel/UCUwkd0hqMVYFTL_GyOMxwQQ\">,</a><a href=\"https://www.youtube.com/channel/UCUwkd0hqMVYFTL_GyOMxwQQ\" target=\"_blank\" rel=\"noreferrer noopener\"> </a><a href=\"https://www.youtube.com/channel/UCUwkd0hqMVYFTL_GyOMxwQQ\"><em>Youtube</em></a></strong></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:woocommerce/featured-product /-->

<!-- wp:woocommerce/product-top-rated {\"categories\":[],\"contentVisibility\":{\"title\":true,\"price\":true,\"rating\":true,\"button\":true}} /-->

<!-- wp:woocommerce/featured-category /-->

<!-- wp:woocommerce/product-best-sellers {\"categories\":[],\"contentVisibility\":{\"title\":true,\"price\":true,\"rating\":true,\"button\":true}} /-->","Winkel","","inherit","closed","closed","","6-revision-v1","","","2021-06-01 12:28:20","2021-06-01 12:28:20","","6","http://localhost:8888/?p=37","0","revision","","0");/*END*/




DROP TABLE IF EXISTS `webtoffee_term_relationships` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_term_relationships VALUES
("1","1","0"),
("12","16","0"),
("13","16","0"),
("15","16","0");/*END*/




DROP TABLE IF EXISTS `webtoffee_term_taxonomy` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_term_taxonomy VALUES
("1","1","category","","0","1"),
("2","2","product_type","","0","0"),
("3","3","product_type","","0","0"),
("4","4","product_type","","0","0"),
("5","5","product_type","","0","0"),
("6","6","product_visibility","","0","0"),
("7","7","product_visibility","","0","0"),
("8","8","product_visibility","","0","0"),
("9","9","product_visibility","","0","0"),
("10","10","product_visibility","","0","0"),
("11","11","product_visibility","","0","0"),
("12","12","product_visibility","","0","0"),
("13","13","product_visibility","","0","0"),
("14","14","product_visibility","","0","0"),
("15","15","product_cat","","0","0"),
("16","16","nav_menu","","0","3");/*END*/




DROP TABLE IF EXISTS `webtoffee_termmeta` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_termmeta VALUES
("1","15","product_count_product_cat","0");/*END*/




DROP TABLE IF EXISTS `webtoffee_terms` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_terms VALUES
("1","Geen categorie","geen-categorie","0"),
("2","simple","simple","0"),
("3","grouped","grouped","0"),
("4","variable","variable","0"),
("5","external","external","0"),
("6","exclude-from-search","exclude-from-search","0"),
("7","exclude-from-catalog","exclude-from-catalog","0"),
("8","featured","featured","0"),
("9","outofstock","outofstock","0"),
("10","rated-1","rated-1","0"),
("11","rated-2","rated-2","0"),
("12","rated-3","rated-3","0"),
("13","rated-4","rated-4","0"),
("14","rated-5","rated-5","0"),
("15","Geen categorie","geen-categorie","0"),
("16","Main","main","0");/*END*/




DROP TABLE IF EXISTS `webtoffee_usermeta` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_usermeta VALUES
("1","1","nickname","24046"),
("2","1","first_name",""),
("3","1","last_name",""),
("4","1","description",""),
("5","1","rich_editing","true"),
("6","1","syntax_highlighting","true"),
("7","1","comment_shortcuts","false"),
("8","1","admin_color","fresh"),
("9","1","use_ssl","0"),
("10","1","show_admin_bar_front","true"),
("11","1","locale",""),
("12","1","webtoffee_capabilities","a:1:{s:13:\"administrator\";b:1;}"),
("13","1","webtoffee_user_level","10"),
("14","1","dismissed_wp_pointers",""),
("15","1","show_welcome_panel","1"),
("16","1","session_tokens","a:1:{s:64:\"698f51537e4d5130c22f62b20124d7a2d149b569f3e2691a5c86b71228cb34bd\";a:4:{s:10:\"expiration\";i:1623753530;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:82:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:89.0) Gecko/20100101 Firefox/89.0\";s:5:\"login\";i:1622543930;}}"),
("17","1","webtoffee_dashboard_quick_press_last_post_id","16"),
("18","1","woosw_key","POD6KZ"),
("19","1","_woocommerce_tracks_anon_id","woo:/A8FCZWxKrwAR2fzX8rbBslX"),
("20","1","wp_yoast_notifications","a:2:{i:0;a:2:{s:7:\"message\";s:386:\"<p>Je kan je site versnellen en inzicht krijgen in je interne link-structuur door ons een paar optimalisaties te laten uitvoeren in de manier waarop SEO gegevens worden opgeslagen. </p><p>We schatten dat dit minder dan een minuut zal duren.</p><a class=\"button\" href=\"http://localhost:8888/wp-admin/admin.php?page=wpseo_tools&start-indexation=true\">SEO-gegevensoptimalisatie starten</a>\";s:7:\"options\";a:10:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:13:\"wpseo-reindex\";s:4:\"user\";O:7:\"WP_User\":8:{s:4:\"data\";O:8:\"stdClass\":10:{s:2:\"ID\";s:1:\"1\";s:10:\"user_login\";s:5:\"24046\";s:9:\"user_pass\";s:34:\"$P$BcW4INAclkluU8DWfSl2EKsrb2B61F0\";s:13:\"user_nicename\";s:5:\"24046\";s:10:\"user_email\";s:15:\"24046@ma-web.nl\";s:8:\"user_url\";s:21:\"http://localhost:8888\";s:15:\"user_registered\";s:19:\"2021-04-29 08:54:41\";s:19:\"user_activation_key\";s:0:\"\";s:11:\"user_status\";s:1:\"0\";s:12:\"display_name\";s:5:\"24046\";}s:2:\"ID\";i:1;s:4:\"caps\";a:1:{s:13:\"administrator\";b:1;}s:7:\"cap_key\";s:22:\"webtoffee_capabilities\";s:5:\"roles\";a:1:{i:0;s:13:\"administrator\";}s:7:\"allcaps\";a:116:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;s:20:\"wpseo_manage_options\";b:1;s:13:\"administrator\";b:1;}s:6:\"filter\";N;s:16:\"\0WP_User\0site_id\";i:1;}s:5:\"nonce\";N;s:8:\"priority\";d:0.8;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}i:1;a:2:{s:7:\"message\";s:455:\"Yoast SEO en WooCommerce werken veel beter samen als er een extra, ondersteunende plugin wordt gebruikt. Installeer Yoast WooCommerce SEO, daar wordt je leven makkelijker van. <a href=\"https://yoa.st/1o0?php_version=7.4&platform=wordpress&platform_version=5.7.2&software=free&software_version=16.4&days_active=31-90&user_language=nl_NL\" aria-label=\"Meer informatie over Yoast WooCommerce SEO\" target=\"_blank\" rel=\"noopener noreferrer\">Meer informatie</a>.\";s:7:\"options\";a:10:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:44:\"wpseo-suggested-plugin-yoast-woocommerce-seo\";s:4:\"user\";O:7:\"WP_User\":8:{s:4:\"data\";O:8:\"stdClass\":10:{s:2:\"ID\";s:1:\"1\";s:10:\"user_login\";s:5:\"24046\";s:9:\"user_pass\";s:34:\"$P$BcW4INAclkluU8DWfSl2EKsrb2B61F0\";s:13:\"user_nicename\";s:5:\"24046\";s:10:\"user_email\";s:15:\"24046@ma-web.nl\";s:8:\"user_url\";s:21:\"http://localhost:8888\";s:15:\"user_registered\";s:19:\"2021-04-29 08:54:41\";s:19:\"user_activation_key\";s:0:\"\";s:11:\"user_status\";s:1:\"0\";s:12:\"display_name\";s:5:\"24046\";}s:2:\"ID\";i:1;s:4:\"caps\";a:1:{s:13:\"administrator\";b:1;}s:7:\"cap_key\";s:22:\"webtoffee_capabilities\";s:5:\"roles\";a:1:{i:0;s:13:\"administrator\";}s:7:\"allcaps\";a:116:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;s:20:\"wpseo_manage_options\";b:1;s:13:\"administrator\";b:1;}s:6:\"filter\";N;s:16:\"\0WP_User\0site_id\";i:1;}s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";a:1:{i:0;s:15:\"install_plugins\";}s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}}"),
("21","1","dismissed_no_secure_connection_notice","1"),
("22","1","th_thunk_notice_ignore","true"),
("23","1","wc_last_active","1622505600"),
("24","1","_yoast_wpseo_profile_updated","1619687854"),
("25","1","managenav-menuscolumnshidden","a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}"),
("26","1","metaboxhidden_nav-menus","a:4:{i:0;s:21:\"add-post-type-product\";i:1;s:12:\"add-post_tag\";i:2;s:15:\"add-product_cat\";i:3;s:15:\"add-product_tag\";}"),
("27","1","_order_count","0"),
("29","1","_woocommerce_persistent_cart_1","a:1:{s:4:\"cart\";a:0:{}}"),
("30","1","community-events-location","a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}"),
("31","1","webtoffee_user-settings","libraryContent=browse"),
("32","1","webtoffee_user-settings-time","1622545240"),
("33","1","last_update","1622545309"),
("34","1","woocommerce_admin_activity_panel_inbox_last_read","1622545300849"),
("35","1","woocommerce_admin_homepage_layout","\"two_columns\""),
("36","1","closedpostboxes_","a:1:{i:0;s:25:\"neve-page-settings-notice\";}"),
("37","1","metaboxhidden_","a:0:{}"),
("38","1","meta-box-order_","a:3:{s:6:\"normal\";s:10:\"wpseo_meta\";s:4:\"side\";s:25:\"neve-page-settings-notice\";s:8:\"advanced\";s:0:\"\";}");/*END*/




DROP TABLE IF EXISTS `webtoffee_users` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_users VALUES
("1","24046","$P$BcW4INAclkluU8DWfSl2EKsrb2B61F0","24046","24046@ma-web.nl","http://localhost:8888","2021-04-29 08:54:41","","0","24046");/*END*/




DROP TABLE IF EXISTS `webtoffee_wc_admin_note_actions` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_wc_admin_note_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `note_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `query` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT '0',
  `actioned_text` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`action_id`),
  KEY `note_id` (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=340 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_wc_admin_note_actions VALUES
("1","1","connect","Koppelen","?page=wc-addons&section=helper","unactioned","0",""),
("2","2","yes-please","Ja, graag!","https://woocommerce.us8.list-manage.com/subscribe/post?u=2c1434dc56f9506bf3c3ecd21&amp;id=13860df971&amp;SIGNUPPAGE=plugin","actioned","0",""),
("37","19","visit-the-theme-marketplace","Bezoek de thema-marktplaats","https://woocommerce.com/product-category/themes/?utm_source=inbox","actioned","0",""),
("38","20","affirm-insight-first-product-and-payment","Ja","","actioned","0","Bedankt voor je feedback"),
("73","21","learn-more","Leer meer","https://woocommerce.com/mobile/","actioned","0",""),
("74","22","tracking-opt-in","Activeer gebruikerscontrole","","actioned","1",""),
("75","23","open-marketing-hub","Marketinghub openen","http://localhost:8888/wp-admin/admin.php?page=wc-admin&path=/marketing","actioned","0",""),
("76","24","share-feedback","Deel je feedback","https://automattic.survey.fm/store-setup-survey","actioned","0",""),
("77","25","affirm-insight-first-sale","Ja","","actioned","0","Bedankt voor je feedback"),
("78","25","deny-insight-first-sale","Nee","","actioned","0","Bedankt voor je feedback"),
("79","26","learn-more","Leer meer","https://docs.woocommerce.com/document/managing-products/?utm_source=inbox","actioned","0",""),
("320","3","open_wc_paypal_payments_product_page","Learn more","https://woocommerce.com/products/woocommerce-paypal-payments/","actioned","1",""),
("321","4","upgrade_now_facebook_pixel_api","Upgrade now","plugin-install.php?tab=plugin-information&plugin=&section=changelog","actioned","1",""),
("322","5","learn_more_facebook_ec","Learn more","https://woocommerce.com/products/facebook/","unactioned","1",""),
("323","6","set-up-concierge","Schedule free session","https://wordpress.com/me/concierge","actioned","1",""),
("324","7","learn-more","Learn more","https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox","unactioned","1",""),
("325","8","learn-more-ecomm-unique-shopping-experience","Learn more","https://docs.woocommerce.com/document/product-add-ons/?utm_source=inbox","actioned","1",""),
("326","9","watch-the-webinar","Watch the webinar","https://youtu.be/V_2XtCOyZ7o","actioned","1",""),
("327","10","learn-more","Learn more","https://woocommerce.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox","actioned","1",""),
("328","11","boost-sales-marketing-guide","See marketing guide","https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=square-boost-sales","actioned","1",""),
("329","12","grow-your-business-marketing-guide","See marketing guide","https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=square-grow-your-business","actioned","1",""),
("330","13","add-apple-pay","Add Apple Pay","/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments","actioned","1",""),
("331","13","learn-more","Learn more","https://docs.woocommerce.com/document/payments/apple-pay/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_applepay","actioned","1",""),
("332","14","boost-sales-marketing-guide","See marketing guide","https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=wcpay-boost-sales","actioned","1",""),
("333","15","grow-your-business-marketing-guide","See marketing guide","https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=wcpay-grow-your-business","actioned","1",""),
("334","16","optimizing-the-checkout-flow","Learn more","https://woocommerce.com/posts/optimizing-woocommerce-checkout?utm_source=inbox","actioned","1",""),
("335","17","learn-more","Learn more","https://woocommerce.com/posts/first-things-customize-woocommerce/?utm_source=inbox","unactioned","1",""),
("336","18","qualitative-feedback-from-new-users","Share feedback","https://automattic.survey.fm/wc-pay-new","actioned","1",""),
("337","27","share-feedback","Share feedback","http://automattic.survey.fm/paypal-feedback","unactioned","1",""),
("338","28","learn-more","Learn about Instant Deposits eligibility","https://docs.woocommerce.com/document/payments/instant-deposits/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_instant_deposits","actioned","1",""),
("339","29","update-wc-subscriptions-3-0-15","View latest version","http://localhost:8888/wp-admin/admin.php?page=wc-admin&page=wc-addons&section=helper","actioned","1","");/*END*/




DROP TABLE IF EXISTS `webtoffee_wc_admin_notes` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_wc_admin_notes` (
  `note_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `locale` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `title` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content_data` longtext COLLATE utf8mb4_unicode_520_ci,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_reminder` datetime DEFAULT NULL,
  `is_snoozable` tinyint(1) NOT NULL DEFAULT '0',
  `layout` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `image` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `icon` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'info',
  PRIMARY KEY (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_wc_admin_notes VALUES
("1","wc-admin-wc-helper-connection","info","en_US","Maak verbinding met WooCommerce.com","Maak verbinding om belangrijke productmeldingen en updates te ontvangen.","{}","unactioned","woocommerce-admin","2021-04-29 09:03:20","","0","plain","","1","info"),
("2","wc-admin-onboarding-email-marketing","info","en_US","Meld je aan voor tips, productupdates en inspiratie","Wij kunnen je helpen: ontvang tips, product-updates en inspiratie direct in je postvak.","{}","unactioned","woocommerce-admin","2021-04-29 09:03:24","","0","plain","","0","info"),
("3","paypal_ppcp_gtm_2021","marketing","en_US","Offer more options with the new PayPal","Get the latest PayPal extension for a full suite of payment methods with extensive currency and country coverage.","{}","pending","woocommerce.com","2021-04-29 09:03:24","","0","plain","","0","info"),
("4","facebook_pixel_api_2021","marketing","en_US","Improve the performance of your Facebook ads","Enable Facebook Pixel and Conversions API through the latest version of Facebook for WooCommerce for improved measurement and ad targeting capabilities.","{}","pending","woocommerce.com","2021-04-29 09:03:24","","0","plain","","0","info"),
("5","facebook_ec_2021","marketing","en_US","Sync your product catalog with Facebook to help boost sales","A single click adds all products to your Facebook Business Page shop. Product changes are automatically synced, with the flexibility to control which products are listed.","{}","pending","woocommerce.com","2021-04-29 09:03:24","","0","plain","","0","info"),
("6","ecomm-need-help-setting-up-your-store","info","en_US","Need help setting up your Store?","Schedule a free 30-min <a href=\"https://wordpress.com/support/concierge-support/\">quick start session</a> and get help from our specialists. We’re happy to walk through setup steps, show you around the WordPress.com dashboard, troubleshoot any issues you may have, and help you the find the features you need to accomplish your goals for your site.","{}","pending","woocommerce.com","2021-04-29 09:03:24","","0","plain","","0","info"),
("7","woocommerce-services","info","en_US","WooCommerce Shipping & Tax","WooCommerce Shipping &amp; Tax helps get your store “ready to sell” as quickly as possible. You create your products. We take care of tax calculation, payment processing, and shipping label printing! Learn more about the extension that you just installed.","{}","pending","woocommerce.com","2021-04-29 09:03:24","","0","plain","","0","info"),
("8","ecomm-unique-shopping-experience","info","en_US","For a shopping experience as unique as your customers","Product Add-Ons allow your customers to personalize products while they’re shopping on your online store. No more follow-up email requests—customers get what they want, before they’re done checking out. Learn more about this extension that comes included in your plan.","{}","pending","woocommerce.com","2021-04-29 09:03:24","","0","plain","","0","info"),
("9","wc-admin-getting-started-in-ecommerce","info","en_US","Getting Started in eCommerce - webinar","We want to make eCommerce and this process of getting started as easy as possible for you. Watch this webinar to get tips on how to have our store up and running in a breeze.","{}","pending","woocommerce.com","2021-04-29 09:03:24","","0","plain","","0","info"),
("10","your-first-product","info","en_US","Your first product","That\'s huge! You\'re well on your way to building a successful online store — now it’s time to think about how you\'ll fulfill your orders.<br /><br />Read our shipping guide to learn best practices and options for putting together your shipping strategy. And for WooCommerce stores in the United States, you can print discounted shipping labels via USPS with <a href=\"https://href.li/?https://woocommerce.com/shipping\" target=\"_blank\">WooCommerce Shipping</a>.","{}","pending","woocommerce.com","2021-04-29 09:03:24","","0","plain","","0","info"),
("11","wc-square-apple-pay-boost-sales","marketing","en_US","Boost sales with Apple Pay","Now that you accept Apple Pay® with Square you can increase conversion rates by letting your customers know that Apple Pay® is available. Here’s a marketing guide to help you get started.","{}","pending","woocommerce.com","2021-04-29 09:03:24","","0","plain","","0","info"),
("12","wc-square-apple-pay-grow-your-business","marketing","en_US","Grow your business with Square and Apple Pay ","Now more than ever, shoppers want a fast, simple, and secure online checkout experience. Increase conversion rates by letting your customers know that you now accept Apple Pay®.","{}","pending","woocommerce.com","2021-04-29 09:03:24","","0","plain","","0","info"),
("13","wcpay-apple-pay-is-now-available","marketing","en_US","Apple Pay is now available with WooCommerce Payments!","Increase your conversion rate by offering a fast and secure checkout with <a href=\"https://woocommerce.com/apple-pay/?utm_source=inbox&amp;utm_medium=product&amp;utm_campaign=wcpay_applepay\" target=\"_blank\">Apple Pay</a>®. It’s free to get started with <a href=\"https://woocommerce.com/payments/?utm_source=inbox&amp;utm_medium=product&amp;utm_campaign=wcpay_applepay\" target=\"_blank\">WooCommerce Payments</a>.","{}","pending","woocommerce.com","2021-04-29 09:03:24","","0","plain","","0","info"),
("14","wcpay-apple-pay-boost-sales","marketing","en_US","Boost sales with Apple Pay","Now that you accept Apple Pay® with WooCommerce Payments you can increase conversion rates by letting your customers know that Apple Pay® is available. Here’s a marketing guide to help you get started.","{}","pending","woocommerce.com","2021-04-29 09:03:24","","0","plain","","0","info"),
("15","wcpay-apple-pay-grow-your-business","marketing","en_US","Grow your business with WooCommerce Payments and Apple Pay","Now more than ever, shoppers want a fast, simple, and secure online checkout experience. Increase conversion rates by letting your customers know that you now accept Apple Pay®.","{}","pending","woocommerce.com","2021-04-29 09:03:24","","0","plain","","0","info"),
("16","wc-admin-optimizing-the-checkout-flow","info","en_US","Optimizing the checkout flow","It\'s crucial to get your store\'s checkout as smooth as possible to avoid losing sales. Let\'s take a look at how you can optimize the checkout experience for your shoppers.","{}","pending","woocommerce.com","2021-04-29 09:03:24","","0","plain","","0","info"),
("17","wc-admin-first-five-things-to-customize","info","en_US","The first 5 things to customize in your store","Deciding what to start with first is tricky. To help you properly prioritize, we\'ve put together this short list of the first few things you should customize in WooCommerce.","{}","pending","woocommerce.com","2021-04-29 09:03:24","","0","plain","","0","info"),
("18","wc-payments-qualitative-feedback","info","en_US","WooCommerce Payments setup - let us know what you think","Congrats on enabling WooCommerce Payments for your store. Please share your feedback in this 2 minute survey to help us improve the setup process.","{}","pending","woocommerce.com","2021-04-29 09:03:24","","0","plain","","0","info"),
("19","wc-admin-choosing-a-theme","marketing","en_US","Kies je een thema?","Bekijk de thema\'s die compatibel zijn met WooCommerce en kies er een die aansluit op je merk en bedrijfsbehoeften.","{}","unactioned","woocommerce-admin","2021-04-30 09:34:52","","0","plain","","0","info"),
("20","wc-admin-insight-first-product-and-payment","survey","en_US","Inzicht","Meer dan 80% van nieuwe verkopers voegt in de eerste week het eerste product toe en configureert minimaal één betaalmethode. Wij helpen je bedrijf succesvol te zijn! Vind je dit soort informatie nuttig?","{}","unactioned","woocommerce-admin","2021-04-30 09:34:52","","0","plain","","0","info"),
("21","wc-admin-mobile-app","info","en_US","Installeer de Woo-app voor mobiel","Installeer de WooCommerce-app voor mobiel om overal waar je bent bestellingen te beheren, verkoopmeldingen te ontvangen en belangrijke meetgegevens te bekijken.","{}","unactioned","woocommerce-admin","2021-06-01 09:29:41","","0","plain","","0","info"),
("22","wc-admin-usage-tracking-opt-in","info","en_US","Help WooCommerce de gebruikerscontrole verbeteren","Door gebruiksgegevens te verzamelen, kunnen we WooCommerce verbeteren. Je winkel komt in aanmerking wanneer we nieuwe functies testen, de kwaliteit van een update beoordelen of bepalen of een verbetering zinvol is. Je kunt altijd naar de <a href=\"http://localhost:8888/wp-admin/admin.php?page=wc-settings&#038;tab=advanced&#038;section=woocommerce_com\" target=\"_blank\">Instellingen</a> gaan en ervoor kiezen geen gegevens meer te delen. <a href=\"https://woocommerce.com/usage-tracking\" target=\"_blank\">Meer informatie</a> over de gegevens die we verzamelen.","{}","unactioned","woocommerce-admin","2021-06-01 09:29:41","","0","plain","","0","info"),
("23","wc-admin-marketing-intro","info","en_US","Verbind je met je doelgroep","Breid je klantenbestand uit en verhoog je omzet met marketingtools voor WooCommerce.","{}","unactioned","woocommerce-admin","2021-06-01 09:29:41","","0","plain","","0","info"),
("24","wc-admin-store-notice-giving-feedback-2","info","en_US","Je bent uitgenodigd om je ervaring te delen","Nu je ons hebt gekozen als partner is het ons doel om te zorgen dat wij je van de juiste tools kunnen voorzien om aan je behoeften te voldoen. We kijken ernaar uit om je feedback over de winkelconfiguratie te lezen, zodat we deze in de toekomst kunnen verbeteren.","{}","unactioned","woocommerce-admin","2021-06-01 09:29:41","","0","plain","","0","info"),
("25","wc-admin-insight-first-sale","survey","en_US","Wist je dat?","Een winkel waarop WooCommerce wordt uitgevoerd, verkoopt zijn eerste product gemiddeld binnen 31 dagen. Je bent op de goede weg! Vind je dit soort informatie nuttig?","{}","unactioned","woocommerce-admin","2021-06-01 09:29:41","","0","plain","","0","info"),
("26","wc-admin-adding-and-managing-products","info","en_US","Producten toevoegen en beheren","Bekijk meer informatie over het configureren van producten in WooCommerce in onze nuttige documenten over het toevoegen en beheren van producten.","{}","unactioned","woocommerce-admin","2021-06-01 09:29:41","","0","plain","","0","info"),
("27","share-your-feedback-on-paypal","info","en_US","Share your feedback on PayPal","Share your feedback in this 2 minute survey about how we can make the process of accepting payments more useful for your store.","{}","pending","woocommerce.com","2021-06-01 09:29:41","","0","plain","","0","info"),
("28","wcpay_instant_deposits_gtm_2021","marketing","en_US","Get paid within minutes – Instant Deposits for WooCommerce Payments","Stay flexible with immediate access to your funds when you need them – including nights, weekends, and holidays. With <a href=\"https://woocommerce.com/products/woocommerce-payments/?utm_source=inbox&amp;utm_medium=product&amp;utm_campaign=wcpay_instant_deposits\">WooCommerce Payments\'</a> new Instant Deposits feature, you’re able to transfer your earnings to a debit card within minutes.","{}","pending","woocommerce.com","2021-06-01 09:29:41","","0","plain","","0","info"),
("29","wc-subscriptions-security-update-3-0-15","info","en_US","WooCommerce Subscriptions security update!","We recently released an important security update to WooCommerce Subscriptions. To ensure your site\'s data is protected, please upgrade <strong>WooCommerce Subscriptions to version 3.0.15</strong> or later.<br /><br />Click the button below to view and update to the latest Subscriptions version, or log in to <a href=\"https://woocommerce.com/my-dashboard\">WooCommerce.com Dashboard</a> and navigate to your <strong>Downloads</strong> page.<br /><br />We recommend always using the latest version of WooCommerce Subscriptions, and other software running on your site, to ensure maximum security.<br /><br />If you have any questions we are here to help — just <a href=\"https://woocommerce.com/my-account/create-a-ticket/\">open a ticket</a>.","{}","pending","woocommerce.com","2021-06-01 09:29:41","","0","plain","","0","info");/*END*/




DROP TABLE IF EXISTS `webtoffee_wc_category_lookup` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_wc_category_lookup` (
  `category_tree_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`category_tree_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_wc_category_lookup VALUES
("15","15");/*END*/




DROP TABLE IF EXISTS `webtoffee_wc_customer_lookup` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_wc_customer_lookup` (
  `customer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `username` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_last_active` timestamp NULL DEFAULT NULL,
  `date_registered` timestamp NULL DEFAULT NULL,
  `country` char(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `postcode` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_wc_download_log` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`),
  CONSTRAINT `fk_webtoffee_wc_download_log_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `webtoffee_woocommerce_downloadable_product_permissions` (`permission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_wc_order_coupon_lookup` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_wc_order_coupon_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `coupon_id` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `discount_amount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`,`coupon_id`),
  KEY `coupon_id` (`coupon_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_wc_order_product_lookup` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_wc_order_product_lookup` (
  `order_item_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `variation_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_qty` int(11) NOT NULL,
  `product_net_revenue` double NOT NULL DEFAULT '0',
  `product_gross_revenue` double NOT NULL DEFAULT '0',
  `coupon_amount` double NOT NULL DEFAULT '0',
  `tax_amount` double NOT NULL DEFAULT '0',
  `shipping_amount` double NOT NULL DEFAULT '0',
  `shipping_tax_amount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `customer_id` (`customer_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_wc_order_stats` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_wc_order_stats` (
  `order_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `num_items_sold` int(11) NOT NULL DEFAULT '0',
  `total_sales` double NOT NULL DEFAULT '0',
  `tax_total` double NOT NULL DEFAULT '0',
  `shipping_total` double NOT NULL DEFAULT '0',
  `net_total` double NOT NULL DEFAULT '0',
  `returning_customer` tinyint(1) DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `date_created` (`date_created`),
  KEY `customer_id` (`customer_id`),
  KEY `status` (`status`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_wc_order_tax_lookup` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_wc_order_tax_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shipping_tax` double NOT NULL DEFAULT '0',
  `order_tax` double NOT NULL DEFAULT '0',
  `total_tax` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`,`tax_rate_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_wc_product_meta_lookup` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT '0',
  `downloadable` tinyint(1) DEFAULT '0',
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT '0',
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT '0',
  `average_rating` decimal(3,2) DEFAULT '0.00',
  `total_sales` bigint(20) DEFAULT '0',
  `tax_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'taxable',
  `tax_class` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`product_id`),
  KEY `virtual` (`virtual`),
  KEY `downloadable` (`downloadable`),
  KEY `stock_status` (`stock_status`),
  KEY `stock_quantity` (`stock_quantity`),
  KEY `onsale` (`onsale`),
  KEY `min_max_price` (`min_price`,`max_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_wc_reserved_stock` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_wc_reserved_stock` (
  `order_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `stock_quantity` double NOT NULL DEFAULT '0',
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `expires` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_wc_tax_rate_classes` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_wc_tax_rate_classes` (
  `tax_rate_class_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_class_id`),
  UNIQUE KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_wc_tax_rate_classes VALUES
("1","Gereduceerd tarief","gereduceerd-tarief"),
("2","Nultarief","nultarief");/*END*/




DROP TABLE IF EXISTS `webtoffee_wc_webhooks` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_woocommerce_api_keys` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_woocommerce_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_520_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_woocommerce_attribute_taxonomies` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_woocommerce_downloadable_product_permissions` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`),
  KEY `user_order_remaining_expires` (`user_id`,`order_id`,`downloads_remaining`,`access_expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_woocommerce_log` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_woocommerce_order_itemmeta` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_woocommerce_order_items` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_woocommerce_payment_tokenmeta` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_woocommerce_payment_tokens` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_woocommerce_payment_tokens` (
  `token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_woocommerce_sessions` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `session_key` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_woocommerce_sessions VALUES
("2","1","a:8:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:729:\"a:26:{s:2:\"id\";s:1:\"1\";s:13:\"date_modified\";s:25:\"2021-06-01T11:01:49+00:00\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"NL\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"NL\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:15:\"24046@ma-web.nl\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";s:21:\"chosen_payment_method\";s:0:\"\";}","1622718312");/*END*/




DROP TABLE IF EXISTS `webtoffee_woocommerce_shipping_zone_locations` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) unsigned NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_woocommerce_shipping_zone_methods` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) unsigned NOT NULL,
  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `method_order` bigint(20) unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_woocommerce_shipping_zones` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_woocommerce_shipping_zones` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `zone_order` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_woocommerce_tax_rate_locations` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_woocommerce_tax_rates` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) unsigned NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) unsigned NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_wt_mgdp_ftp` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_wt_mgdp_ftp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `server` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `port` int(11) NOT NULL DEFAULT '21',
  `export_path` varchar(255) NOT NULL,
  `import_path` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/*END*/






DROP TABLE IF EXISTS `webtoffee_wtmgdp_log` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_wtmgdp_log` (
  `id_wtmgdp_log` int(11) NOT NULL AUTO_INCREMENT,
  `log_name` varchar(200) NOT NULL,
  `log_data` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `log_type` varchar(200) NOT NULL,
  `created_at` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_wtmgdp_log`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;/*END*/


INSERT INTO webtoffee_wtmgdp_log VALUES
("1","2021-06-01 04:20:09 PM","{\"tables\":[\"wp_actionscheduler_actions\",\"wp_actionscheduler_claims\",\"wp_actionscheduler_groups\",\"wp_actionscheduler_logs\",\"wp_commentmeta\",\"wp_comments\",\"wp_links\",\"wp_mollie_pending_payment\",\"wp_options\",\"wp_postmeta\",\"wp_posts\",\"wp_term_relationships\",\"wp_term_taxonomy\",\"wp_termmeta\",\"wp_terms\",\"wp_usermeta\",\"wp_users\",\"wp_wc_admin_note_actions\",\"wp_wc_admin_notes\",\"wp_wc_category_lookup\",\"wp_wc_customer_lookup\",\"wp_wc_download_log\",\"wp_wc_order_coupon_lookup\",\"wp_wc_order_product_lookup\",\"wp_wc_order_stats\",\"wp_wc_order_tax_lookup\",\"wp_wc_product_meta_lookup\",\"wp_wc_reserved_stock\",\"wp_wc_tax_rate_classes\",\"wp_wc_webhooks\",\"wp_woocommerce_api_keys\",\"wp_woocommerce_attribute_taxonomies\",\"wp_woocommerce_downloadable_product_permissions\",\"wp_woocommerce_log\",\"wp_woocommerce_order_itemmeta\",\"wp_woocommerce_order_items\",\"wp_woocommerce_payment_tokenmeta\",\"wp_woocommerce_payment_tokens\",\"wp_woocommerce_sessions\",\"wp_woocommerce_shipping_zone_locations\",\"wp_woocommerce_shipping_zone_methods\",\"wp_woocommerce_shipping_zones\",\"wp_woocommerce_tax_rate_locations\",\"wp_woocommerce_tax_rates\",\"wp_wt_mgdp_ftp\",\"wp_wtmgdp_log\",\"wp_yoast_indexable\",\"wp_yoast_indexable_hierarchy\",\"wp_yoast_migrations\",\"wp_yoast_primary_term\",\"wp_yoast_seo_links\"],\"files\":[\"index.php\"],\"dirs\":[\"languages\",\"migrator_database\",\"plugins\",\"themes\",\"upgrade\",\"uploads\"],\"find\":[\"\",\"webtoffee_capabilities\",\"webtoffee_user_level\",\"webtoffee_user-settings\",\"webtoffee_user-settings-time\",\"webtoffee_dashboard_quick_press_last_post_id\",\"webtoffee_user_roles\"],\"replace\":[\"\",\"webtoffee_capabilities\",\"webtoffee_user_level\",\"webtoffee_user-settings\",\"webtoffee_user-settings-time\",\"webtoffee_dashboard_quick_press_last_post_id\",\"webtoffee_user_roles\"],\"backup_file\":\"2021-06-01-04-20-09pm.zip\"}","2","export","1622564409","1622564409");/*END*/




DROP TABLE IF EXISTS `webtoffee_yoast_indexable` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_yoast_indexable` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `permalink` longtext COLLATE utf8mb4_unicode_520_ci,
  `permalink_hash` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `object_id` bigint(20) DEFAULT NULL,
  `object_type` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `object_sub_type` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `post_parent` bigint(20) DEFAULT NULL,
  `title` text COLLATE utf8mb4_unicode_520_ci,
  `description` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `breadcrumb_title` text COLLATE utf8mb4_unicode_520_ci,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `is_protected` tinyint(1) DEFAULT '0',
  `has_public_posts` tinyint(1) DEFAULT NULL,
  `number_of_pages` int(11) unsigned DEFAULT NULL,
  `canonical` longtext COLLATE utf8mb4_unicode_520_ci,
  `primary_focus_keyword` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `primary_focus_keyword_score` int(3) DEFAULT NULL,
  `readability_score` int(3) DEFAULT NULL,
  `is_cornerstone` tinyint(1) DEFAULT '0',
  `is_robots_noindex` tinyint(1) DEFAULT '0',
  `is_robots_nofollow` tinyint(1) DEFAULT '0',
  `is_robots_noarchive` tinyint(1) DEFAULT '0',
  `is_robots_noimageindex` tinyint(1) DEFAULT '0',
  `is_robots_nosnippet` tinyint(1) DEFAULT '0',
  `twitter_title` text COLLATE utf8mb4_unicode_520_ci,
  `twitter_image` longtext COLLATE utf8mb4_unicode_520_ci,
  `twitter_description` longtext COLLATE utf8mb4_unicode_520_ci,
  `twitter_image_id` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `twitter_image_source` text COLLATE utf8mb4_unicode_520_ci,
  `open_graph_title` text COLLATE utf8mb4_unicode_520_ci,
  `open_graph_description` longtext COLLATE utf8mb4_unicode_520_ci,
  `open_graph_image` longtext COLLATE utf8mb4_unicode_520_ci,
  `open_graph_image_id` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `open_graph_image_source` text COLLATE utf8mb4_unicode_520_ci,
  `open_graph_image_meta` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `link_count` int(11) DEFAULT NULL,
  `incoming_link_count` int(11) DEFAULT NULL,
  `prominent_words_version` int(11) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `blog_id` bigint(20) NOT NULL DEFAULT '1',
  `language` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `region` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schema_page_type` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schema_article_type` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `has_ancestors` tinyint(1) DEFAULT '0',
  `estimated_reading_time_minutes` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `object_type_and_sub_type` (`object_type`,`object_sub_type`),
  KEY `object_id_and_type` (`object_id`,`object_type`),
  KEY `permalink_hash_and_object_type` (`permalink_hash`,`object_type`),
  KEY `subpages` (`post_parent`,`object_type`,`post_status`,`object_id`),
  KEY `prominent_words` (`prominent_words_version`,`object_type`,`object_sub_type`,`post_status`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_yoast_indexable VALUES
("1","http://localhost:8888/author/24046/","35:cb863ecc0f2e568c65a916d79626a99f","1","user","","","","","","","","","0","","","","","","","0","0","","","","","","https://2.gravatar.com/avatar/509251f745529db09d6e7f297cb4536f?s=500&d=mm&r=g","","","gravatar-image","","","https://2.gravatar.com/avatar/509251f745529db09d6e7f297cb4536f?s=500&d=mm&r=g","","gravatar-image","","","","","2021-04-29 09:03:19","2021-06-01 12:28:21","1","","","","","0",""),
("2","http://localhost:8888/wishlist/","31:1a19e01b43b22876f846a8a9c8551b06","10","post","page","1","0","","","Wishlist","publish","","0","","","","","","30","0","","0","","","","","","","","","","","","","","","0","","","2021-04-29 09:03:19","2021-06-01 12:12:36","1","","","","","0","1"),
("3","http://localhost:8888/","22:5991fe0fb17fbdb8f3dbac786f3793b6","","home-page","","","","%%sitename%% %%page%% %%sep%% %%sitedesc%%","","Home","","","0","","","","","","","0","0","0","0","0","0","","","","","","","","","","","","","","","2021-04-29 09:03:50","2021-06-01 10:40:42","1","","","","","0",""),
("4","http://localhost:8888/wp-content/uploads/woocommerce-placeholder.png","68:24cfecc1fb4354dcf1643e9ab7621926","5","post","attachment","1","0","","","woocommerce-placeholder","inherit","0","0","0","","","","","0","0","","0","","","","","http://localhost:8888/wp-content/uploads/woocommerce-placeholder.png","","5","attachment-image","","","http://localhost:8888/wp-content/uploads/woocommerce-placeholder.png","5","attachment-image","{
    \"width\": 1200,
    \"height\": 1200,
    \"url\": \"http://localhost:8888/wp-content/uploads/woocommerce-placeholder.png\",
    \"path\": \"/Applications/MAMP/htdocs/wordpress/wp-content/uploads/woocommerce-placeholder.png\",
    \"size\": \"full\",
    \"id\": 5,
    \"alt\": \"\",
    \"pixels\": 1440000,
    \"type\": \"image/png\"
}","","","","2021-04-29 09:07:21","2021-04-29 09:07:21","1","","","","","0",""),
("5","http://localhost:8888/?page_id=3","32:94f60c762b4e2019caf5e8dd991deaf2","3","post","page","1","0","","","Privacybeleid","draft","0","0","","","","","","0","0","","0","","","","","","","","","","","","","","","","","","2021-04-29 09:07:21","2021-04-29 09:07:21","1","","","","","0",""),
("6","http://localhost:8888/voorbeeld-pagina/","39:9f7b40885f0010b5a07e14fe7029f3db","2","post","page","1","0","","","Voorbeeld pagina","publish","","0","","","","","","0","0","","0","","","","","","","","","","","","","","","1","","","2021-04-29 09:07:21","2021-04-29 09:07:21","1","","","","","0",""),
("7","http://localhost:8888/winkel/","29:43e380dc2828043db4abdea066e47ec4","6","post","page","1","0","","","Winkel","publish","","0","","","","","","90","0","","0","","","","","http://localhost:8888/wp-content/uploads/2021/06/DISBRANDE-X-Happycheftv.jpg","","","first-content-image","","","http://localhost:8888/wp-content/uploads/2021/06/DISBRANDE-X-Happycheftv.jpg","","first-content-image","","0","","","2021-04-29 09:07:21","2021-06-01 12:28:21","1","","","","","0","1"),
("8","http://localhost:8888/winkelwagen/","34:480c4431b734b8f920e7ec545d31449c","7","post","page","1","0","","","Winkelmand","publish","","0","","","","","","30","0","","0","","","","","","","","","","","","","","","0","","","2021-04-29 09:07:21","2021-06-01 12:14:43","1","","","","","0","1"),
("9","http://localhost:8888/afrekenen/","32:5dce0a1d211ceac4e9958ec642821208","8","post","page","1","0","","","Afrekenen","publish","","0","","","","","","0","0","","0","","","","","","","","","","","","","","","0","","","2021-04-29 09:07:21","2021-04-29 09:07:22","1","","","","","0",""),
("10","http://localhost:8888/mijn-account/","35:d72b64f008a768126288a47da2fd7394","9","post","page","1","0","","","Mijn account","publish","","0","","","","","","0","0","","0","","","","","","","","","","","","","","","0","","","2021-04-29 09:07:21","2021-04-29 09:07:22","1","","","","","0",""),
("12","http://localhost:8888/2021/04/29/hallo-wereld/","46:dd802b1dde8a2b8a556639ef4b9dc231","1","post","post","1","0","","","Hallo wereld!","publish","","0","","","","","","0","0","","0","","","","","","","","","","","","","","","0","","","2021-04-29 09:07:21","2021-04-29 09:07:34","1","","","","","0",""),
("13","http://localhost:8888/category/geen-categorie/","46:5da1d007f885947d086aa4791c207d90","1","term","category","","","","","Geen categorie","","","0","","","","","","","0","","","","","","","","","","","","","","","","","0","","","2021-04-29 09:07:21","2021-04-29 09:07:22","1","","","","","0",""),
("14","http://localhost:8888/product-categorie/geen-categorie/","55:bc86ec0d072d3edfe214157a32aeef75","15","term","product_cat","","","","","Geen categorie","","","0","","","","","","","0","","","","","","","","","","","","","","","","","0","","","2021-04-29 09:07:21","2021-04-29 09:07:22","1","","","","","0",""),
("15","","","","system-page","404","","","Pagina niet gevonden %%sep%% %%sitename%%","","404-fout: pagina niet gevonden","","","0","","","","","","","0","1","0","0","0","0","","","","","","","","","","","","","","","2021-04-29 09:07:21","2021-04-29 09:07:21","1","","","","","0",""),
("16","","","","system-page","search-result","","","Je hebt gezocht naar %%searchphrase%% %%page%% %%sep%% %%sitename%%","","","","","0","","","","","","","0","1","0","0","0","0","","","","","","","","","","","","","","","2021-04-29 09:07:21","2021-04-29 09:07:21","1","","","","","0",""),
("17","","","","date-archive","","","","%%date%% %%page%% %%sep%% %%sitename%%","","","","0","0","","","","","","","0","1","0","0","0","0","","","","","","","","","","","","","","","2021-04-29 09:07:21","2021-04-29 09:07:21","1","","","","","0",""),
("18","http://localhost:8888/winkel/","29:43e380dc2828043db4abdea066e47ec4","","post-type-archive","product","","","Archief %%pt_plural%% %%page%% %%sep%% %%sitename%%","","Producten","","1","0","","","","","","","0","0","0","0","0","0","","","","","","","","","","","","","","","2021-04-29 09:07:21","2021-04-29 09:07:21","1","","","","","0",""),
("19","http://localhost:8888/2021/04/29/12/","36:91564c6b290b4ba003ec39e28ebdd52e","12","post","nav_menu_item","1","0","","","","publish","","0","","","","","","0","0","","0","","","","","","","","","","","","","","","0","","","2021-04-29 09:27:07","2021-04-29 09:27:56","1","","","","","0",""),
("20","http://localhost:8888/2021/04/29/13/","36:63dddc0a117998894b49cfc403fd1d38","13","post","nav_menu_item","1","0","","","","publish","","0","","","","","","0","0","","0","","","","","","","","","","","","","","","0","","","2021-04-29 09:27:07","2021-04-29 09:27:56","1","","","","","0",""),
("21","http://localhost:8888/?p=14","27:b8303f7ce5fc26ae9bf7e1c76a559605","14","post","nav_menu_item","1","0","","","","draft","0","0","","","","","","0","0","","0","","","","","","","","","","","","","","","","","","2021-04-29 09:27:07","2021-04-29 09:27:07","1","","","","","0",""),
("22","http://localhost:8888/2021/04/29/15/","36:10a28c6c5c941e5adacbae37ae8cb0c1","15","post","nav_menu_item","1","0","","","","publish","","0","","","","","","0","0","","0","","","","","","","","","","","","","","","0","","","2021-04-29 09:27:07","2021-04-29 09:27:56","1","","","","","0",""),
("23","http://localhost:8888/wp-content/uploads/2021/06/Disbranded_BG-01.jpg","69:7b29ad50c44a7f62e084fbc9d5b1b9ba","17","post","attachment","1","0","","","Disbranded_BG-01","inherit","0","0","0","","","","","0","0","","0","","","","","http://localhost:8888/wp-content/uploads/2021/06/Disbranded_BG-01.jpg","","17","attachment-image","","","","17","attachment-image","","","","","2021-06-01 10:42:08","2021-06-01 10:42:08","1","","","","","0",""),
("24","http://localhost:8888/wp-content/uploads/2021/06/cropped-Disbranded_BG-01.jpg","77:54409dd8405f5e8e5f45ab84bddc2f85","18","post","attachment","1","0","","","cropped-Disbranded_BG-01.jpg","inherit","0","0","0","","","","","0","0","","0","","","","","http://localhost:8888/wp-content/uploads/2021/06/cropped-Disbranded_BG-01.jpg","","18","attachment-image","","","","18","attachment-image","","","","","2021-06-01 10:42:13","2021-06-01 10:42:13","1","","","","","0",""),
("25","http://localhost:8888/wp-content/uploads/2021/06/Disbranded_BG-02.png","69:cfb89321c112b717d4deda3f1d1577ea","20","post","attachment","1","0","","","Disbranded_BG-02","inherit","0","0","0","","","","","0","0","","0","","","","","http://localhost:8888/wp-content/uploads/2021/06/Disbranded_BG-02.png","","20","attachment-image","","","","20","attachment-image","","","","","2021-06-01 10:42:45","2021-06-01 10:42:45","1","","","","","0",""),
("26","http://localhost:8888/wp-content/uploads/2021/06/cropped-Disbranded_BG-02.png","77:68215bc7b1705d260fe1bf9bee3b3360","21","post","attachment","1","0","","","cropped-Disbranded_BG-02.png","inherit","0","0","0","","","","","0","0","","0","","","","","http://localhost:8888/wp-content/uploads/2021/06/cropped-Disbranded_BG-02.png","","21","attachment-image","","","","21","attachment-image","","","","","2021-06-01 10:42:53","2021-06-01 10:42:53","1","","","","","0",""),
("27","http://localhost:8888/?p=19","27:edd3f83b221088c5ab6e79534038847d","19","post","customize_changeset","1","0","","","","trash","0","0","","","","","","0","0","","0","","","","","","","","","","","","","","","","","","2021-06-01 10:59:45","2021-06-01 12:19:38","1","","","","","0",""),
("28","http://localhost:8888/wp-content/uploads/2021/06/DISBRANDE-X-Happycheftv.jpg","76:e2ff59d4716e348fd95768586055fcfe","34","post","attachment","1","6","","","DISBRANDE-X-Happycheftv","inherit","","0","","","","","","0","0","","0","","","","","http://localhost:8888/wp-content/uploads/2021/06/DISBRANDE-X-Happycheftv.jpg","","34","attachment-image","","","","34","attachment-image","","","1","","2021-06-01 12:23:22","2021-06-01 14:26:26","1","","","","","0","");/*END*/




DROP TABLE IF EXISTS `webtoffee_yoast_indexable_hierarchy` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_yoast_indexable_hierarchy` (
  `indexable_id` int(11) unsigned NOT NULL,
  `ancestor_id` int(11) unsigned NOT NULL,
  `depth` int(11) unsigned DEFAULT NULL,
  `blog_id` bigint(20) NOT NULL DEFAULT '1',
  PRIMARY KEY (`indexable_id`,`ancestor_id`),
  KEY `indexable_id` (`indexable_id`),
  KEY `ancestor_id` (`ancestor_id`),
  KEY `depth` (`depth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_yoast_indexable_hierarchy VALUES
("1","0","0","1"),
("2","0","0","1"),
("3","0","0","1"),
("4","0","0","1"),
("5","0","0","1"),
("6","0","0","1"),
("7","0","0","1"),
("8","0","0","1"),
("9","0","0","1"),
("10","0","0","1"),
("12","0","0","1"),
("13","0","0","1"),
("14","0","0","1"),
("18","0","0","1"),
("19","0","0","1"),
("20","0","0","1"),
("21","0","0","1"),
("22","0","0","1"),
("23","0","0","1"),
("24","0","0","1"),
("25","0","0","1"),
("26","0","0","1"),
("27","0","0","1"),
("28","7","1","1");/*END*/




DROP TABLE IF EXISTS `webtoffee_yoast_migrations` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_yoast_migrations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `webtoffee_yoast_migrations_version` (`version`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO webtoffee_yoast_migrations VALUES
("1","20171228151840"),
("2","20171228151841"),
("3","20190529075038"),
("4","20191011111109"),
("5","20200408101900"),
("6","20200420073606"),
("7","20200428123747"),
("8","20200428194858"),
("9","20200429105310"),
("10","20200430075614"),
("11","20200430150130"),
("12","20200507054848"),
("13","20200513133401"),
("14","20200609154515"),
("15","20200616130143"),
("16","20200617122511"),
("17","20200702141921"),
("18","20200728095334"),
("19","20201202144329"),
("20","20201216124002"),
("21","20201216141134");/*END*/




DROP TABLE IF EXISTS `webtoffee_yoast_primary_term` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_yoast_primary_term` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) DEFAULT NULL,
  `term_id` bigint(20) DEFAULT NULL,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `blog_id` bigint(20) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `post_taxonomy` (`post_id`,`taxonomy`),
  KEY `post_term` (`post_id`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_yoast_seo_links` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress`
--




CREATE TABLE `webtoffee_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `target_post_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(8) DEFAULT NULL,
  `indexable_id` int(11) unsigned DEFAULT NULL,
  `target_indexable_id` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `size` int(11) unsigned DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `region` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`),
  KEY `indexable_link_direction` (`indexable_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;/*END*/


INSERT INTO webtoffee_yoast_seo_links VALUES
("1","http://localhost:8888/wp-admin/","2","","internal","6","","","","","",""),
("32","https://www.twitch.tv/happycheftv","6","","external","7","","","","","",""),
("33","https://www.twitch.tv/happycheftv","6","","external","7","","","","","",""),
("34","https://discord.gg/gFSeRk5","6","","external","7","","","","","",""),
("35","https://twitter.com/happycheftv","6","","external","7","","","","","",""),
("36","https://www.facebook.com/happycheftv","6","","external","7","","","","","",""),
("37","https://www.instagram.com/happycheftv/","6","","external","7","","","","","",""),
("38","https://www.youtube.com/channel/UCUwkd0hqMVYFTL_GyOMxwQQ","6","","external","7","","","","","",""),
("39","https://www.youtube.com/channel/UCUwkd0hqMVYFTL_GyOMxwQQ","6","","external","7","","","","","",""),
("40","https://www.youtube.com/channel/UCUwkd0hqMVYFTL_GyOMxwQQ","6","","external","7","","","","","",""),
("41","http://localhost:8888/wp-content/uploads/2021/06/DISBRANDE-X-Happycheftv.jpg","6","34","image-in","7","28","284","565","723737","","");/*END*/


